# Genes cochlear noise reanalysis version 1.0.0

This package accompanies an exploratory, retrospective public-data reanalysis.
It does not contain new experimental observations or claim independent validation
of a causal oxidative stress to synapse injury mechanism. The external analysis
did NOT replicate the discovery gene signature. Read the manuscript limitations.

## Analysis entry points

Use Python 3.12. Create a virtual environment in the extracted package folder:

```text
python -m venv .venv
# Windows
.venv\Scripts\python -m pip install -r requirements-lock.txt
.venv\Scripts\python work/scripts/genes_reproduce.py --output rerun --smoke
# macOS or Linux
.venv/bin/python -m pip install -r requirements-lock.txt
.venv/bin/python work/scripts/genes_reproduce.py --output rerun --smoke
```

The smoke test reruns the complete principal SGN PyDESeq2 model from the included
integer pseudobulk counts. It writes results into a NEW output folder and compares
log2 fold changes with the distributed results. Never use the same output folder
twice. Remove `--smoke` for all 19 eligible primary/sensitivity models plus the
external analysis, enrichment and figure generation. This can take substantially
longer. The package must be extracted fully; run commands from its root.
The exact installed dependency inventory is provided. Some platform-specific
transitive packages may require an equivalent compatible build on another OS.

## Independent raw-count verification

```text
python work/scripts/genes_verify_raw.py --download
```

This downloads the 607 MB GSE168041 archive only when absent, extracts the original
Matrix Market matrices and reaggregates all saved sample-by-stratum counts using
the frozen per-cell annotations. The original verification passed all 157 matrices
with zero absolute difference. This is stronger than checking matrix dimensions.
It verifies aggregation, not biological truth of annotation or every model assumption.
The archive itself is not redistributed because of its size. GEO URL:
https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168041/suppl/GSE168041_RAW.tar

## Optional rebuilding of the reference atlas

```text
python work/scripts/genes_build_cache.py
python work/scripts/genes_prepare.py
python work/scripts/genes_celltypes.py
```

These commands require the raw archive to have been extracted. They rebuild
initial quality filtering, log normalization, highly variable genes, PCA, UMAP,
Leiden clusters, Scrublet and cell-type aggregation. They need several GB of RAM.
Run them in a separate copy, because they replace derived metadata and annotations.
The initial cache builder follows the computation used for the frozen atlas but
has not been retested in a fresh installation. Stochastic clustering and cluster
numbers can vary by platform/version. If cluster numbers change, REVIEW markers
and update `MAP` in genes_celltypes.py; do not blindly reuse cluster-number labels.
The directly tested reproducibility route uses the distributed frozen identities
and verifies their raw counts against GEO.

## Source of each result

- `work/scripts/genes_celltypes.py`: sample-level PyDESeq2, effect intervals and
  descriptive omitted-sample effect directions. Conditions are `naive` and `noise`.
- `work/scripts/genes_external.py`: continuous deposited external expression,
  log2(value + 1), Welch tests and external BH correction. Never round these values
  into integer counts; normalization units were not confidently resolved.
- `work/scripts/genes_enrichment.py`: mouse-native ORA, focused preranked GSEA,
  sample-level module sensitivity and external concordance. GSEA nominal zeroes
  are finite permutation resolution, not exact zero probabilities. Empirical GSEA
  FDR and BH-adjusted nominal P values are different columns. Preranking requires
  finite gene-level P values and statistics, excluding Cook-filtered estimates.
- `work/scripts/genes_network.py`: original STRING v12 functional association
  query. The returned TSV, query parameters and checksum are frozen in `network/`.
  Figure regeneration uses that cache rather than querying a changing database.
- `work/scripts/genes_figures.py`: six main and four supplementary figures.
  It uses frozen UMAP coordinates, annotation and dot-plot source summaries. Raw
  cell-count H5AD caches are optional, not required when those summaries exist.

All integer pseudobulk counts, sample metadata, normalized counts and DE results
are in `work/genes/celltypes/`. `*_strict_*` are primary analyses; SGN and glial
`*_liberal_*` are sensitivity analyses. The unfortunately named `primary_keep`
column in frozen cell metadata means the LESS STRINGENT non-doublet filter;
`strict_keep` is the actual primary analysis filter. This naming is documented
explicitly to prevent accidental selection of the wrong analysis population.

Global gene-level correction covers 17 stringent contrasts, including three
overlapping SGN strata. Fourteen are broad cell types. Only lateral-wall myeloid
cells have 3 control versus 4 exposed eligible samples; other tested contrasts
have 4 versus 4. Neural mural cells were not tested (4 versus 2).

## Provenance and limitations

GSE168041 was accessed 27 September 2026. GSE312476 and external candidate metadata
were accessed 28 September 2026. Primary count provenance and input SHA256 values
are in `provenance.json`; external download metadata are in `sources/`.
The audit-only large SOFT files for unselected cohorts are not redistributed;
their parsed sample metadata and download checksums are provided. GEO remains
the authoritative source. Gene-set source URLs and SHA256 values are provided in
`work/revision/sources/gene_set_manifest.json`. Four frozen GMT libraries are
included for reproducible research, subject to their original providers' terms.
Original data, annotations and referenced database content retain their original
attribution and applicable terms; no new license is asserted for third-party data.

Reproducibility here means published input/output provenance, executable scripts,
a local core-model rerun and independently verified raw aggregation. It does NOT
mean a clean-room container rerun, automatic biological validation or guaranteed
bitwise identical outputs across platforms. No new repository upload was made.
Before submission, the human authors must review and approve the methods, outputs,
references, code license and disclosures and create a persistent versioned release.

## Manuscript and journal preparation

Genes free-format initial-submission requirements were checked on 28 September 2026:
https://www.mdpi.com/journal/genes/instructions
The manuscript includes a structured abstract, sequential numeric citations,
embedded main figures, numeric result tables and required declaration sections.
Items marked AUTHOR_INPUT_NEEDED, AUTHOR_CONFIRM or AUTHOR_ACTION require genuine
author information/approval and must be resolved before upload. The cover letter
is a draft, not an assertion that all authors have approved or that the manuscript
is not under consideration elsewhere. Nothing has been submitted externally.

`Supplementary_Index.md` maps manuscript supplement names to exact files.
`SHA256SUMS.csv` checks the delivered files. `qa/` includes figure alignment,
collision and font audits and document rendering checks where generated.
