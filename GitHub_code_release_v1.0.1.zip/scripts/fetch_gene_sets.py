from pathlib import Path
import json, hashlib, urllib.request, datetime

out = Path('work/revision/sources')
log=[]
urls={
 'GO_BP_mouse_2025.1.gmt':'https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2025.1.Mm/m5.go.bp.v2025.1.Mm.symbols.gmt',
 'GO_CC_mouse_2025.1.gmt':'https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2025.1.Mm/m5.go.cc.v2025.1.Mm.symbols.gmt',
 'Reactome_mouse_2025.1.gmt':'https://data.broadinstitute.org/gsea-msigdb/msigdb/release/2025.1.Mm/m2.cp.reactome.v2025.1.Mm.symbols.gmt',
 'KEGG_2019_Mouse.gmt':'https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName=KEGG_2019_Mouse'
}
for name,url in urls.items():
    try:
        p=out/name
        if not p.exists():
            req=urllib.request.Request(url,headers={'User-Agent':'CochlearReanalysis/1.0'})
            with urllib.request.urlopen(req,timeout=100) as r: p.write_bytes(r.read())
        data=p.read_bytes()
        log.append({'file':name,'url':url,'access_date':str(datetime.date.today()),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        print(name,len(data),data[:140],flush=True)
    except Exception as e: print(name,repr(e),flush=True)
(out/'gene_set_manifest.json').write_text(json.dumps(log,indent=2),encoding='utf-8')
