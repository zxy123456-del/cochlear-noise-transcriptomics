"""Independent validation on deposited continuous expression, not raw counts."""
from pathlib import Path
import gzip, io, json
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT=Path('work/genes')
OUT=ROOT/'external'
OUT.mkdir(exist_ok=True)
samples=json.loads((ROOT/'sources/GSE312476_samples.json').read_text(encoding='utf8'))
series=[]
meta=[]
for s in samples:
    p=ROOT/'sources'/s['supplementary_file_1'][0].split('/')[-1]
    lines=gzip.open(p,'rt',encoding='utf8').read().splitlines()
    start=next(i for i,x in enumerate(lines) if x.startswith('gene_symbol\tgene_id'))
    df=pd.read_csv(io.StringIO('\n'.join(lines[start:])),sep='\t',usecols=[0,1,2])
    df.columns=['gene','ensembl','value']
    df['value']=pd.to_numeric(df.value,errors='raise')
    df=df.dropna(subset=['gene'])
    # Gene-symbol duplicates are collapsed without selecting on treatment response.
    expr=df.groupby('gene').value.mean().rename(s['gsm'])
    series.append(expr)
    title=s['title'][0]
    group='naive' if 'mock' in title else '8h' if '8h post' in title else '4h' if '4h post' in title else '0h'
    meta.append({'sample':s['gsm'],'group':group,'title':title,'sex':'male','age_weeks':16})
X=pd.concat(series,axis=1,join='inner')
meta=pd.DataFrame(meta).set_index('sample')
X.to_csv(OUT/'deposited_expression.csv.gz')
meta.to_csv(OUT/'metadata.csv')
noninteger=float(np.mean(np.abs(X.to_numpy()-np.round(X.to_numpy()))>1e-6))
summary=[]
Y=np.log2(X+1)
Y.to_csv(OUT/'log2_expression.csv.gz')
for time in ['0h','4h','8h']:
    cols=meta.index[meta.group.isin(['naive',time])]
    keep=(X[cols]>=1).sum(axis=1)>=3
    y=Y.loc[keep,cols]
    n=y.loc[:,meta.loc[cols].group.eq(time)].to_numpy()
    c=y.loc[:,meta.loc[cols].group.eq('naive')].to_numpy()
    test=stats.ttest_ind(n,c,axis=1,equal_var=False)
    effect=n.mean(1)-c.mean(1)
    se=np.sqrt(n.var(1,ddof=1)/n.shape[1]+c.var(1,ddof=1)/c.shape[1])
    crit=stats.t.ppf(.975,test.df)
    res=pd.DataFrame({'gene':y.index,'log2_difference':effect,'SE':se,'df':test.df,'stat':test.statistic,'pvalue':test.pvalue,'CI_low':effect-crit*se,'CI_high':effect+crit*se})
    finite=np.isfinite(res.pvalue)
    res['padj']=np.nan
    res.loc[finite,'padj']=multipletests(res.loc[finite,'pvalue'],method='fdr_bh')[1]
    res.to_csv(OUT/f'DE_{time}.csv',index=False)
    summary.append({'time':time,'genes_tested':int(finite.sum()),'FDR_lt_05':int(res.padj.lt(.05).sum()),'n_control':3,'n_noise':3})
pd.DataFrame(summary).to_csv(OUT/'summary.csv',index=False)
(OUT/'matrix_audit.json').write_text(json.dumps({'rows':len(X),'samples':len(meta),'noninteger_fraction':noninteger,'analysis':'Welch tests on log2(deposited value + 1); no rounding, no count model; deposited normalization units not resolved; exploratory validation','primary_time':'8h (closest deposited time to discovery 24h), selected before effect inspection','other_times':'0h and 4h; reported in full'},indent=2))
print(pd.DataFrame(summary).to_string(index=False),flush=True)
