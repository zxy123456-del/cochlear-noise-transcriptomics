"""Prepare accessibility assets, audit the revision, and assemble release 1.0.1."""
from pathlib import Path
import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile
from datetime import datetime, timezone
from PIL import Image, ImageChops
from docx import Document
from docx.shared import Pt, Inches
from docx.oxml.ns import qn

ROOT = Path.cwd()
DATA = ROOT / 'work/genes'
REV = DATA / 'revision_v2'
OUT = ROOT / 'outputs'
AUTHOR_IDS = {
    'Xiongyue Zai': '0009-0002-5749-1632',
    'Yao Kong': '0009-0006-3819-7429',
    'Jiazhi Yin': '0009-0003-6856-2659',
    'Yong Tang': '0009-0008-9976-3708',
}
ALT = {
    'Figure1_workflow': 'Flowchart separating discovery in GSE168041 from the independent GSE312476 comparison. Discovery proceeds through cell quality control, annotation, animal-level pseudobulk analysis, functional enrichment and sensitivity checks. External whole-cochlea data are analyzed separately; no external cells enter the discovery embedding.',
    'Figure2_cell_atlas': 'Two UMAP panels show 25,983 neural-enriched cells and 31,040 lateral-wall cells retained after stringent quality control. Colors distinguish marker-based cell labels, including neural, glial, vascular, stromal, epithelial and immune groups. These reference embeddings show cell identity rather than treatment effect size.',
    'Figure3_celltype_effects': 'Dot matrix compares selected gene effects across 14 eligible broad cell types. Color encodes noise-versus-control log2 fold change and dot size distinguishes global false discovery rate below 0.05. Blank cells lack a tested estimate. SGN examples include decreased Snap25 and Syt2 and increased Syn1, Gpx2, Gpx4 and Hmox1.',
    'Figure4_focus_enrichment': 'Bubble matrix displays three focused gene sets across 17 stringent cell strata. Color encodes normalized enrichment score and bubble area encodes adjusted permutation significance. SGNs show negative synapse organization and positive oxidative stress response enrichment. None of the separate animal-level module comparisons survives multiple-testing correction.',
    'Figure5_independent_validation': 'Two-panel external comparison: a scatterplot compares shared discovery SGN and independent whole-cochlea effects, and a forest plot shows six illustrative genes with 95 percent confidence intervals. The global effect correlation is near zero, and none of these genes is independently significant after genome-wide correction.',
    'Figure6_evidence_summary': 'Evidence diagram distinguishes observed SGN transcriptional associations from untested injury mechanisms. Synaptic and antioxidant transcripts change in discovery, but the independent comparison does not replicate the nominated signature. Synapse loss, reactive oxygen species and causal rescue were not measured in this reanalysis.',
    'FigureS1_annotation': 'Marker dot plots summarize neural-enriched and lateral-wall cell annotations. Dot area gives the fraction of cells with detected expression and color gives relative mean normalized expression within each tissue. The panels support exploratory identities and are not animal-level statistical tests.',
    'FigureS2_SGN_volcano': 'SGN volcano plot shows noise-versus-control log2 fold change against minus log10 adjusted P value, capped at 100. Increased and decreased significant genes appear on opposite sides of zero, with nonsignificant genes also shown. The biological sample size is four animals per condition.',
    'FigureS3_SGN_heatmap': 'Heatmap shows row-standardized log2 normalized counts for the top 24 discovery SGN genes across four control and four noise-exposed samples. Color represents relative expression within each gene. Selection and display use the same discovery cohort and do not constitute independent classifier validation.',
    'FigureS4_functional_network': 'STRING functional association network includes all 20 differentially expressed SGN genes shared by synapse and oxidative stress annotations, including isolated nodes. Twelve edges meet the 0.700 score threshold. Node color gives discovery fold change; edges do not establish direct physical binding or causal cochlear mechanisms.',
}


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf8')


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def checksum_valid(orcid):
    digits = orcid.replace('-', '')
    total = 0
    for digit in digits[:15]:
        total = (total + int(digit)) * 2
    result = (12 - total % 11) % 11
    return ('X' if result == 10 else str(result)) == digits[-1]


def prepare():
    (REV / 'figures').mkdir(parents=True, exist_ok=True)
    write_json(REV / 'figure_alt_text.json', ALT)
    rows = []
    for name, alt in ALT.items():
        source = DATA / 'figures' / (name + '.png')
        with Image.open(source) as original:
            alpha = original.getchannel('A').getextrema() if original.mode == 'RGBA' else None
            assert alpha is None or alpha == (255, 255), (name, alpha)
            rgb = original.convert('RGB')
            target = REV / 'figures' / source.name
            rgb.save(target, dpi=original.info.get('dpi', (600, 600)))
            with Image.open(target) as saved:
                assert ImageChops.difference(rgb, saved).getbbox() is None
                rows.append({'figure': name, 'width_px': saved.width, 'height_px': saved.height,
                    'source_mode': original.mode, 'output_mode': saved.mode,
                    'dpi_x': saved.info['dpi'][0], 'dpi_y': saved.info['dpi'][1],
                    'RGB_pixels_unchanged': True, 'resampled': False, 'alt_text': alt})
    write_csv(REV / 'figure_asset_audit.csv', rows)
    write_json(REV / 'author_verification.json', {
        'checked_on': '2026-10-07',
        'orcid_checks': [{'name': n, 'orcid': o, 'checksum_valid': checksum_valid(o),
                          'identity_verified': False} for n, o in AUTHOR_IDS.items()],
        'orcid_limit': 'Checksum only; public identity endpoints could not be verified in this session.',
        'yin_email': '467025380@qq.com; visible user text retained instead of conflicting mailto target.',
        'romanization': 'Standard pinyin; author confirmation requested.',
        'hospital_translation': 'Northeast Yunnan Central Hospital is a working translation, not independently verified official branding.',
        'kunming_postcode': '650032, supported by hospital-issued 2024 training notice at https://www.ynwsjkrc.cn/temp/1720074520555051174.pdf ; replaces generic 650000.',
        'funding_basis': 'Explicit user-supplied awarded funding statement on 2026-10-07; no independent official grant record located.',
        'grant': 'National Natural Science Foundation of China 82260220',
        'project_title_zh': '\u8109\u51b2\u566a\u97f3\u81f4\u53ef\u9006\u6027\u8033\u804b\u8033\u8717\u6162\u6027\u635f\u4f24\u673a\u5236\u7814\u7a76',
        'journal_rules_checked': '2026-10-07 via official browser-rendered instructions and reference guide',
        'journal_url': 'https://www.mdpi.com/journal/genes/instructions',
        'reference_guide': 'https://www.mdpi.com/authors/references',
        'render_backend': 'Packaged render_docx.py explicitly selects installed native soffice.exe on Windows; no bundled Windows LibreOffice is supplied.',
    })
    print('Prepared', len(rows), 'RGB assets; no pixel values changed or images resampled.')


def audit():
    path = OUT / 'Genes_Manuscript_English_v2.docx'
    doc = Document(path)
    source = (DATA / 'manuscript_en.md').read_text(encoding='utf8')
    abstract = source.split('## Abstract\n\n')[1].split('\n\nKeywords:')[0].replace('**', '')
    body_abstract = re.sub(r'\b(?:Background/Objectives|Methods|Results|Conclusions):\s*', '', abstract)
    paras = [p.text for p in doc.paragraphs]
    ref_start = paras.index('References')
    ref_lines = [p for p in paras[ref_start+1:] if p.strip()]
    cited = []
    for match in re.finditer(r'\[(\d+(?:,\s*\d+)*)\]', '\n'.join(paras[:ref_start])):
        cited.extend(int(v.strip()) for v in match[1].split(','))
    seen = list(dict.fromkeys(cited))
    assert seen == list(range(1,29)), seen
    assert len(ref_lines) == 28
    assert all(re.search(r'https://doi.org/10\.', t) for t in ref_lines)
    assert len(doc.tables) == 3 and len(doc.inline_shapes) == 6
    empty = sum(not c.text.strip() for t in doc.tables for row in t.rows for c in row.cells)
    assert empty == 0
    figures = []
    for n, shape in enumerate(doc.inline_shapes, 1):
        rid = shape._inline.graphic.graphicData.pic.blipFill.blip.embed
        with Image.open(io.BytesIO(doc.part.related_parts[rid].blob)) as img:
            dpi_x, dpi_y = img.width / shape.width.inches, img.height / shape.height.inches
            alt = shape._inline.docPr.get('descr', '')
            assert alt and min(dpi_x, dpi_y) >= 599.9
            assert img.mode == 'RGB'
            figures.append({'figure': n, 'width_inches': shape.width.inches,
                'height_inches': shape.height.inches, 'effective_dpi_x': dpi_x,
                'effective_dpi_y': dpi_y, 'alt_text': alt, 'mode': img.mode})
    write_csv(REV / 'word_figure_audit.csv', figures)
    xml = doc.part.element
    links = []
    for h in xml.iter(qn('w:hyperlink')):
        rid = h.get(qn('r:id'))
        label = ''.join(t.text or '' for t in h.iter(qn('w:t')))
        target = doc.part.rels[rid].target_ref
        if target.startswith('mailto:'):
            assert target == 'mailto:' + label
        links.append({'label': label, 'target': target})
    result = {'version': '1.0.1', 'date': '2026-10-07',
        'abstract_words_whitespace_with_headings': len(abstract.split()),
        'abstract_words_whitespace_without_headings': len(body_abstract.split()),
        'abstract_words_regex_with_headings': len(re.findall(r"\b[\w'-]+\b", abstract)),
        'keyword_count': len(source.split('Keywords:')[1].split('\n')[0].split(';')),
        'references': len(ref_lines), 'reference_order': seen, 'all_28_have_doi': True,
        'tables': 3, 'empty_table_cells': empty, 'inline_figures': 6,
        'nonempty_alt_text': len(figures), 'minimum_word_effective_dpi': min(min(f['effective_dpi_x'], f['effective_dpi_y']) for f in figures),
        'hyperlinks': links, 'author_review_still_required': False,
        'render_review': 'See render_review.json after the page-image inspection.'}
    write_json(REV / 'revision_audit.json', result)
    print(json.dumps({k:v for k,v in result.items() if k != 'hyperlinks'}, indent=2))
    report(result)


def report(a):
    import genes_build_documents as b
    d = Document(); b.setup(d, 'Genes | Revision verification | 7 October 2026')
    for name in ['Normal', 'Title', 'Heading 1', 'Heading 2']:
        style = d.styles[name]
        style.font.name = 'Microsoft YaHei'
        style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    d.styles['Normal'].font.size = Pt(10)
    b.p(d, 'Genes 投稿信息核查与修订说明', 'Title')
    b.p(d, '核查日期：2026年10月7日。本文档用于作者终审，不随稿件作为研究结果发表。v2更新作者、基金、文献排版和图件可访问性；原始数据、统计结果及未能独立复现的结论未改变。')
    b.p(d, '已完成的修订', 'Heading 1')
    items = [
        '署名顺序：Xiongyue Zai、Yao Kong、Jiazhi Yin、Yong Tang。前两位以同一上标标记共同第一作者，Yong Tang为通讯作者；三组科室隶属关系、全体作者邮箱和ORCID已补入。',
        '殷家志邮箱采用所提供的显示文字467025380@qq.com，纠正原链接误指向孔瑶邮箱的问题。英文署名需与作者惯用署名一致。',
        '昆医大附一院西昌路295号邮编改为650032。依据为医院发布的2024年住培通知；原650000是较笼统的昆明邮编。请通讯作者核对本部门实际收件邮编。',
        '滇东北中心医院暂译Northeast Yunnan Central Hospital，尚未独立核实其官方英文名称。若科研管理部门有统一名称，应全文同步替换，不混用其他译名。',
        '基金声明已写入National Natural Science Foundation of China，grant number 82260220。依据为本次作者明确提供的资助信息；未找到可独立核验该项目号及项目名称的官方公开记录，不能标为已获官网确认。',
        '性别、出生年月和非通讯作者个人电话未放入论文。未将“硕士”推定为MD，也未将“博士”推定为特定博士学位缩写；学位及科主任职务不是本稿署名所需字段。通讯作者电话仅列入投稿信。',
    ]
    for text in items: b.p(d, text)
    b.p(d, '结构和图件核查', 'Heading 1')
    b.p(d, f"摘要保留Background/Objectives、Methods、Results、Conclusions四项结构。按空白分词，含小标题为{a['abstract_words_whitespace_with_headings']}词，不含小标题为{a['abstract_words_whitespace_without_headings']}词；另一正则分词算法为{a['abstract_words_regex_with_headings']}词。239词不能作为本版统一口径，差异可来自分词规则或稿件版本；以提交系统复核为准，当前长度符合约250词的建议。")
    b.p(d, '关键词7个，符合3–10个建议。参考文献28条，正文首次出现顺序为1–28，无遗漏引用，28条均带DOI。文献元数据沿用上次Crossref/Europe PMC核查记录，本次重查编号、字段和链接结构，不将其表述为28条DOI已在本次逐一实时解析。期刊名采用完整名称，避免将NLM缩写误当作ISO 4缩写；Genes初投接受一致的自由格式。')
    b.p(d, '正文6图、3表；所有表格单元格均有内容。6幅正文图已写入有实际描述的Word替代文字，另附4幅补充图的替代文字清单。10幅原始PNG的DPI元数据约599.9988（PNG像素每米整数编码造成，与600等效）；已无损移除完全不透明的alpha通道并保存为8-bit RGB，没有上采样，也未改变RGB像素。')
    b.p(d, f"Word中的图件按不超过原生600 dpi尺寸插入，最低有效DPI为{a['minimum_word_effective_dpi']:.2f}。原始PNG及可缩放PDF保留在完整资料包中；投稿应使用这些原图，而不是截图。Word渲染和逐页检查结果在最终交付时另行说明。")
    b.p(d, '仍需作者确认', 'Heading 1')
    for text in [
        'ORCID：4个号码均通过ISO 7064 MOD 11-2校验，但公开页面或接口未能完成身份核对。校验位正确不等于账号归属验证；每位作者应登录ORCID确认姓名与编号。',
        '贡献与批准：已按作者确认的信息写入CRediT角色、共同第一作者安排、全体作者批准及责任声明。投稿前仍应由作者逐字核对角色是否准确。',
        '利益冲突与基金作用：已写入无利益冲突及基金方未参与研究设计、分析、解释、写作和投稿决定的声明；如存在任何例外，必须在投稿系统和稿件中同步更正。',
        '伦理与AI：已写入公开数据二次分析不涉及新动物程序，因此伦理审查不适用；AI使用范围及作者实质审查责任已披露。若本单位要求备案或认定，请补充对应文件或表述。',
        '投稿信：已写入全体作者批准、同意投稿及无一稿多投声明。请通讯作者在系统提交前确认该承诺真实有效。',
        '代码归档：资料包版本为1.0.1，尚未公开发布仓库或DOI。作者批准后再上传获准共享的分析代码和数据，填写实际永久链接；旧的数据获取日期2026年9月27日至28日保持不变。',
        '科研结论：基金项目名称涉及“脉冲噪音、可逆性耳聋”，但本次GEO模型并不支持这两个限定，不能据基金名称改写数据来源或论文题目。独立数据未重复验证候选基因，必须保留此结果。',
    ]: b.p(d, text)
    b.p(d, '核查来源', 'Heading 1')
    for text in [
        'Genes Instructions for Authors（2026年10月7日浏览器读取）：https://www.mdpi.com/journal/genes/instructions',
        'MDPI Reference List and Citations Style Guide（2026年10月7日浏览器读取）：https://www.mdpi.com/authors/references',
        '第12条文献已复核出版商页面，当前为In-Press Preview，故注明in press，未虚构卷期或页码：https://insight.jci.org/articles/view/203285',
        '昆明医科大学第一附属医院2024年住培通知：https://www.ynwsjkrc.cn/temp/1720074520555051174.pdf（检索摘要列明西昌路295号及邮编650032；本次PDF下载超时，需作者复核原件）。',
    ]: b.p(d, text)
    d.save(OUT / 'Genes_Revision_Report_Chinese_v2.docx')


def package():
    source = OUT / 'Genes_submission_package_v1'
    target = OUT / 'Genes_submission_package_v2'
    target.mkdir(exist_ok=True)
    exclude = {'SHA256SUMS.csv', 'Genes_Manuscript_English.docx', 'Genes_Cover_Letter_English.docx'}
    for p in source.rglob('*'):
        if not p.is_file() or p.name in exclude: continue
        dest = target / p.relative_to(source)
        dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dest)
    for name in ['Genes_Manuscript_English_v2.docx', 'Genes_Cover_Letter_English_v2.docx', 'Genes_Revision_Report_Chinese_v2.docx']:
        shutil.copy2(OUT / name, target / name)
    for p in REV.rglob('*'):
        if p.is_file():
            dest = target / p.relative_to(ROOT); dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dest)
    for name in ALT:
        shutil.copy2(REV / 'figures' / (name+'.png'), target / 'work/genes/figures' / (name+'.png'))
    for name in ['manuscript_en.md', 'document_content_audit.json', 'reference_order.json']:
        shutil.copy2(DATA / name, target / 'work/genes' / name)
    release = target / 'repository_release'
    release.mkdir(parents=True, exist_ok=True)
    shutil.copy2(DATA / 'repository_release' / 'CITATION.cff', release / 'CITATION.cff')
    for name in ['genes_build_documents.py', 'genes_revision_v2.py']:
        shutil.copy2(ROOT / 'work/scripts' / name, target / 'work/scripts' / name)
    (target / 'VERSION').write_text('1.0.1\n', encoding='utf8')
    provpath = target / 'provenance.json'
    prov = json.loads(provpath.read_text(encoding='utf8'))
    prov.update(release='1.0.1', document_revision_date='2026-10-07',
        biological_analyses_rerun_in_v2=False,
        revision_scope='Author and funding information; accessibility; lossless RGB assets; Word sizing; references and layout')
    write_json(provpath, prov)
    unchanged = []
    for subdir in ['celltypes', 'enrichment', 'external', 'network']:
        for old in (source / 'work/genes' / subdir).rglob('*'):
            if old.is_file():
                new = target / old.relative_to(source)
                assert hashlib.sha256(old.read_bytes()).digest() == hashlib.sha256(new.read_bytes()).digest()
                unchanged.append(old.relative_to(source).as_posix())
    write_json(target / 'analysis_unchanged_v2.json', {'unchanged_files': len(unchanged), 'files': unchanged})
    # Existing v1 instructions remain for analytical provenance but are visibly superseded for submission status.
    notice = ('Revision 1.0.1, 7 October 2026. Use the v2 DOCX files and Chinese revision report. '
              'Author and grant fields are populated and author approval is recorded; only the final public repository URL/DOI remains to be inserted. '
              'Analytical results are unchanged. Figure assets are lossless RGB with alternative text supplied.\n\n')
    for name in ['README.md', '\u6295\u7a3f\u524d\u5fc5\u8bfb.md', 'work/genes/README_reproducibility.md', 'work/genes/submission_readiness_zh.md']:
        f = target / name
        f.write_text(notice + f.read_text(encoding='utf8'), encoding='utf8')
    rows = []
    for f in sorted(target.rglob('*')):
        if f.is_file() and f.name != 'SHA256SUMS.csv':
            rows.append({'file': f.relative_to(target).as_posix(), 'bytes': f.stat().st_size,
                         'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
    write_csv(target / 'SHA256SUMS.csv', rows)
    dest = OUT / 'Genes_analysis_and_submission_package_v2.zip'
    with zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in target.rglob('*'):
            if f.is_file(): z.write(f, f.relative_to(target.parent))
    with zipfile.ZipFile(dest) as z: assert z.testzip() is None
    for row in rows:
        assert hashlib.sha256((target / row['file']).read_bytes()).hexdigest() == row['sha256']
    print('Verified package:', len(rows), 'files;', round(dest.stat().st_size / 1e6, 2), 'MB')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('action', choices=['prepare', 'audit', 'package'])
    args = parser.parse_args(); globals()[args.action]()
