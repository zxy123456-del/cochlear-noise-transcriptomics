from pathlib import Path
import gzip
import re
import sys

import numpy as np
import pandas as pd
import scanpy as sc
from scipy import io, sparse
from anndata import AnnData
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = Path("work/geo_reanalysis/extracted/GSE168041")
RES = Path("work/geo_reanalysis/results")
FIG = Path("outputs/figures")
RES.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)
sc.settings.figdir = str(FIG)
sc.settings.verbosity = 2
sc.settings.set_figure_params(dpi=120, dpi_save=300, frameon=False)


def log(msg):
    print(msg, flush=True)


def load_sample(matrix_path):
    base = str(matrix_path).replace("_matrix.mtx.gz", "")
    genes_path, barcodes_path = Path(base + "_genes.tsv.gz"), Path(base + "_barcodes.tsv.gz")
    with gzip.open(matrix_path, "rb") as handle:
        matrix = io.mmread(handle).tocsr().T.tocsr()
    genes = pd.read_csv(genes_path, sep="\t", header=None, names=["gene_id", "gene_symbol"])
    barcodes = pd.read_csv(barcodes_path, sep="\t", header=None, names=["barcode"])["barcode"].astype(str)
    ad = AnnData(X=matrix)
    ad.var_names = pd.Index(genes.gene_id.astype(str))
    ad.var["gene_symbol"] = genes.gene_symbol.astype(str).values
    ad.obs_names = barcodes.values
    match = re.search(r"GSM\d+_MouseCochlea(?P<tissue>Neurons|Stria)_(?P<condition>naive|noise)(?P<rep>\d+)", matrix_path.name)
    if not match:
        raise ValueError(f"Sample name did not match: {matrix_path.name}")
    ad.obs["sample"] = matrix_path.name.split("_Mouse")[0]
    ad.obs["tissue"] = match.group("tissue")
    ad.obs["condition"] = match.group("condition")
    ad.obs["replicate"] = int(match.group("rep"))
    ad.obs_names = [f"{ad.obs['sample'].iloc[0]}_{b}" for b in ad.obs_names]
    return ad


def run_tissue(tissue):
    files = sorted(BASE.glob(f"*MouseCochlea{tissue}_*_matrix.mtx.gz"))
    if len(files) != 8:
        raise RuntimeError(f"Expected 8 samples for {tissue}, found {len(files)}")
    pieces = []
    for i, path in enumerate(files, 1):
        log(f"Loading {tissue} sample {i}/8: {path.name}")
        pieces.append(load_sample(path))
    ad = sc.concat(pieces, join="inner", merge="same", index_unique=None)
    ad.var["gene_symbol"] = pieces[0].var["gene_symbol"].values
    ad.var["mt"] = ad.var.gene_symbol.str.upper().str.startswith("MT-")
    sc.pp.calculate_qc_metrics(ad, qc_vars=["mt"], percent_top=None, log1p=False, inplace=True)
    ad.obs["pass_qc"] = (ad.obs.n_genes_by_counts >= 200) & (ad.obs.total_counts >= 500) & (ad.obs.pct_counts_mt < 20)
    qc = ad.obs.groupby("sample", observed=True).agg(
        tissue=("tissue", "first"), condition=("condition", "first"), replicate=("replicate", "first"),
        cells_before=("sample", "size"), cells_after=("pass_qc", "sum"),
        median_genes=("n_genes_by_counts", "median"), median_UMI=("total_counts", "median"),
        median_mito_pct=("pct_counts_mt", "median"),
    ).reset_index()
    qc.to_csv(RES / f"GSE168041_{tissue}_cell_qc.csv", index=False, encoding="utf-8-sig")
    ad = ad[ad.obs.pass_qc].copy()
    log(f"{tissue}: retained {ad.n_obs:,} / {sum(qc.cells_before):,} cells")

    ad.raw = ad.copy()
    sc.pp.normalize_total(ad, target_sum=1e4)
    sc.pp.log1p(ad)
    sc.pp.highly_variable_genes(ad, flavor="cell_ranger", n_top_genes=2000, batch_key="sample")
    ad = ad[:, ad.var.highly_variable].copy()
    sc.pp.scale(ad, max_value=10)
    sc.tl.pca(ad, n_comps=30, svd_solver="arpack")
    sc.pp.neighbors(ad, n_neighbors=15, n_pcs=30)
    sc.tl.umap(ad, random_state=1)
    try:
        sc.tl.leiden(ad, resolution=0.5, key_added="cluster", random_state=1, flavor="igraph", n_iterations=2)
    except Exception as e:
        log(f"Leiden skipped: {e}")
        ad.obs["cluster"] = "unclustered"
    sc.pl.umap(ad, color=["condition", "sample", "cluster"], ncols=3, show=False, save=f"_{tissue}_umap.png")

    marker_sets = {
        "neuronal": ["Tubb3", "Snap25", "Syt1", "Nefl", "Nefm", "Prph", "Calb2", "Pou4f1", "Isl1"],
        "glial": ["Sox10", "Plp1", "Mpz", "S100b", "Fabp7"],
        "vascular": ["Pecam1", "Cldn5", "Kdr", "Rgs5", "Pdgfrb"],
        "fibroblast": ["Col1a1", "Col1a2", "Dcn", "Pdgfra", "S100a4"],
        "strial_epithelial": ["Kcnj10", "Kcnq1", "Slc12a2", "Atp1a1", "Atp1b1", "Gjb2"],
        "immune": ["Ptprc", "Lyz2", "Csf1r", "C1qa", "Tyrobp"],
    }
    sym_to_id = pd.Series(ad.var_names, index=ad.var.gene_symbol).to_dict()
    available = {group: [sym_to_id[g] for g in genes if g in sym_to_id] for group, genes in marker_sets.items()}
    available = {g: genes for g, genes in available.items() if genes}
    if available:
        sc.pl.dotplot(ad, available, groupby="cluster", use_raw=False, standard_scale="var", show=False, save=f"_{tissue}_markers.png")
        sc.pl.umap(ad, color=[g for gs in available.values() for g in gs[:3]], ncols=3, show=False, save=f"_{tissue}_marker_features.png")
    ad.write_h5ad(RES / f"GSE168041_{tissue}_processed.h5ad", compression="gzip")
    if "cluster" in ad.obs:
        sc.tl.rank_genes_groups(ad, "cluster", method="wilcoxon", use_raw=False)
        markers = sc.get.rank_genes_groups_df(ad, group=None)
        symbols = dict(zip(ad.var_names, ad.var.gene_symbol))
        markers["gene_symbol"] = markers.names.map(symbols)
        markers.to_csv(RES / f"GSE168041_{tissue}_cluster_markers.csv", index=False, encoding="utf-8-sig")

    # Pseudobulk each biological sample; cells are subsamples, not replicates.
    raw = ad.raw.to_adata()
    raw.obs["sample"] = ad.obs["sample"].values
    raw.obs["condition"] = ad.obs["condition"].values
    sample_ids = list(pd.unique(raw.obs["sample"]))
    symbols = raw.var.gene_symbol.astype(str).values
    symbol_order = pd.Index(pd.unique(symbols))
    bulk = []
    for sid in sample_ids:
        rows = np.flatnonzero(raw.obs["sample"].to_numpy() == sid)
        sums = np.asarray(raw.X[rows].sum(axis=0)).ravel()
        temp = pd.DataFrame({"gene": symbols, "count": sums}).groupby("gene", sort=False).count.sum()
        bulk.append(temp.reindex(symbol_order, fill_value=0).to_numpy())
    counts = pd.DataFrame(np.asarray(bulk, dtype=np.int64).T, index=symbol_order, columns=sample_ids)
    counts.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_counts.csv", encoding="utf-8-sig")
    sample_meta = raw.obs.drop_duplicates("sample").set_index("sample")[["condition", "replicate"]].loc[sample_ids]
    sample_meta.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_metadata.csv", encoding="utf-8-sig")
    try:
        from pydeseq2.dds import DeseqDataSet
        from pydeseq2.ds import DeseqStats
        dds = DeseqDataSet(counts=counts.T, metadata=sample_meta, design="~condition", refit_cooks=True, n_cpus=2)
        dds.deseq2()
        stat = DeseqStats(dds, contrast=("condition", "noise", "naive"), n_cpus=2)
        stat.summary()
        result = stat.results_df.reset_index().rename(columns={"index": "gene"})
        result.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_deseq2.csv", index=False, encoding="utf-8-sig")
        log(f"{tissue}: DESeq2 pseudobulk complete")
    except Exception as e:
        log(f"{tissue}: DESeq2 pseudobulk failed: {type(e).__name__}: {e}")
    log(f"Saved {tissue} annotated object and plots")


if __name__ == "__main__":
    for tissue_name in (sys.argv[1:] or ["Neurons", "Stria"]):
        run_tissue(tissue_name)
