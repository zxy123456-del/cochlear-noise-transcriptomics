from pathlib import Path
import numpy as np
import pandas as pd
import sys
sys.path.insert(0, r"C:\Users\宰雄跃\.codex\skills\nature-figure\scripts")
from audit_panel_alignment import require_matplotlib_panel_alignment
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RES = Path("work/geo_reanalysis/results")
FIG = Path("outputs/figures")
plt.rcParams.update({"font.family": "Arial", "font.size": 8, "axes.spines.top": False,
                     "axes.spines.right": False, "pdf.fonttype": 42, "svg.fonttype": "none"})

fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.3), constrained_layout=True)
targets = {
    "Neurons": {"Gclc": (-28, 9), "Gpx2": (7, 9), "Gpx4": (8, -15)},
    "Stria": {"Gpx1": (8, 8), "Gpx3": (-26, -16)},
}
for ax, tissue in zip(axes, ["Neurons", "Stria"]):
    d = pd.read_csv(RES / f"GSE168041_{tissue}_pseudobulk_deseq2.csv")
    d["padj"] = d.padj.fillna(1.0).clip(lower=1e-300)
    sig = d.padj < .05
    ax.scatter(d.loc[~sig, "log2FoldChange"], -np.log10(d.loc[~sig, "padj"]), s=4, c="#9AA6B2", alpha=.35, linewidths=0, rasterized=True)
    ax.scatter(d.loc[sig, "log2FoldChange"], -np.log10(d.loc[sig, "padj"]), s=5, c="#2D7594", alpha=.65, linewidths=0, rasterized=True)
    chosen = d[d.gene.isin(targets[tissue]) & (d.padj < .05)]
    ax.scatter(chosen.log2FoldChange, -np.log10(chosen.padj), s=18, c="#C95E53", edgecolors="white", linewidths=.35, zorder=3)
    for _, r in chosen.iterrows():
        ax.annotate(r.gene, (r.log2FoldChange, -np.log10(r.padj)), xytext=targets[tissue][r.gene],
                    textcoords="offset points", fontsize=6, clip_on=True,
                    arrowprops={"arrowstyle": "-", "lw": .45, "color": "#596773"})
    ax.axhline(-np.log10(.05), color="#64727E", lw=.7, ls="--")
    ax.set(title="Neural tissue" if tissue == "Neurons" else "Cochlear lateral wall", xlabel="log2 fold change (noise vs control)", ylabel="-log10 adjusted P")
    ax.set_ylim(0, 15)
    ax.text(.98, .97, "values above 15 are clipped", transform=ax.transAxes, ha="right", va="top", fontsize=5.5, color="#596773")
fig.suptitle("GSE168041 sample-level pseudobulk differential expression", fontsize=10)
fig.canvas.draw()
require_matplotlib_panel_alignment(fig, json_out=FIG / "GSE168041_pseudobulk_volcano.alignment.json",
                                   overlay_svg=FIG / "GSE168041_pseudobulk_volcano.alignment.svg", strict=True)
fig.savefig(FIG / "GSE168041_pseudobulk_volcano.pdf", bbox_inches="tight")
fig.savefig(FIG / "GSE168041_pseudobulk_volcano.png", dpi=600, bbox_inches="tight")
fig.savefig(FIG / "GSE168041_pseudobulk_volcano.tiff", dpi=600, bbox_inches="tight")
plt.close(fig)
