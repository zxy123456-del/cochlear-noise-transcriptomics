
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request, time, os, sys

ROOT = Path('work/geo_reanalysis')
RAW = ROOT / 'raw'
RAW.mkdir(parents=True, exist_ok=True)
BASE_URLS = {
    'GSE168041': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168041/suppl/',
    'GSE167078': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE167nnn/GSE167078/suppl/',
    'GSE168973': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168973/suppl/',
}

def parse_filelist(acc):
    path = ROOT / f'{acc}_filelist.txt'
    out=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('File\t'):
            continue
        parts=line.split('\t')
        if len(parts) >= 5:
            name, size = parts[1], int(parts[3])
            out.append((name,size))
    return out

def download_one(acc, name, size):
    sub = RAW / acc
    sub.mkdir(parents=True, exist_ok=True)
    out = sub / name
    if out.exists() and out.stat().st_size == size:
        return f'SKIP {acc}/{name}'
    tmp = out.with_suffix(out.suffix + '.part')
    url = BASE_URLS[acc] + name
    req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=120) as r, open(tmp, 'wb') as f:
        while True:
            chunk = r.read(1024*1024)
            if not chunk:
                break
            f.write(chunk)
    if tmp.stat().st_size != size:
        raise RuntimeError(f'size mismatch {name}: {tmp.stat().st_size} != {size}')
    tmp.replace(out)
    return f'DONE {acc}/{name} {size/1e6:.1f} MB'

def main():
    tasks=[]
    # GSE168973 is small bulk TPM, download all files.
    tasks += [('GSE168973', name, size) for name,size in parse_filelist('GSE168973')]
    # GSE167078 is small immune scRNA/HTO, download all files.
    tasks += [('GSE167078', name, size) for name,size in parse_filelist('GSE167078')]
    # GSE168041: prioritize MouseCochleaNeurons for synapse-focused single-cell analysis.
    tasks += [('GSE168041', name, size) for name,size in parse_filelist('GSE168041') if 'MouseCochleaNeurons' in name]
    print(f'TASKS {len(tasks)} files, total {sum(t[2] for t in tasks)/1e6:.1f} MB', flush=True)
    started = time.time()
    with ThreadPoolExecutor(max_workers=10) as ex:
        futs=[ex.submit(download_one,*t) for t in tasks]
        for i,fut in enumerate(as_completed(futs),1):
            try:
                print(f'[{i}/{len(futs)}] {fut.result()} elapsed={time.time()-started:.1f}s', flush=True)
            except Exception as e:
                print(f'ERROR {e}', flush=True)
                raise
if __name__ == '__main__':
    main()
