from pathlib import Path
import json,re,zipfile,xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import pymupdf
from PIL import Image

root=Path('work/genes');report={}
a=pd.read_csv(root/'celltypes/Neurons_SGN_strict_DE.csv').set_index('gene')
b=pd.read_csv('work/genes_smoke/work/genes/celltypes/Neurons_SGN_strict_DE.csv').set_index('gene')
report['core_rerun']={'max_log2FC_difference':float((a.log2FoldChange-b.log2FoldChange).abs().max()),'max_pvalue_difference':float((a.pvalue-b.pvalue).abs().max()),'max_FDR_difference':float((a.padj-b.padj).abs().max()),'same_FDR_decisions':bool((a.padj.lt(.05)==b.padj.lt(.05)).all())}
assert report['core_rerun']['max_log2FC_difference']<1e-10
assert report['core_rerun']['same_FDR_decisions']
raw=pd.read_csv(root/'raw_reaggregation_verification.csv')
assert len(raw)==157 and raw['pass'].all() and raw.max_absolute_difference.max()==0
report['raw_aggregation']={'matrices':len(raw),'all_exact':True}
report['figures']=[]
for f in sorted((root/'figures').glob('*.png')):
    im=Image.open(f);dpi=im.info.get('dpi')
    assert dpi and min(dpi)>599
    report['figures'].append({'name':f.name,'mode':im.mode,'dpi':dpi,'pixels':im.size})
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile('outputs/Genes_Manuscript_English.docx') as z:
    doc=ET.fromstring(z.read('word/document.xml'))
    txt='\n'.join(''.join(p.itertext()) for p in doc.findall('.//w:p',ns))
    assert '[[' not in txt and '[@' not in txt
    tables=doc.findall('.//w:tbl',ns)
    assert len(tables)==3
    assert all(''.join(c.itertext()).strip() for t in tables for c in t.findall('.//w:tc',ns))
    seen=[]
    body=txt.split('\nReferences\n')[0]
    for hit in re.findall(r'\[(\d+(?:, \d+)*)\]',body):
        for s in hit.split(', '):
            if int(s) not in seen:seen.append(int(s))
    assert seen==list(range(1,29)),seen
    assert len([s for s in z.namelist() if s.startswith('word/media/')])==6
    styles=ET.fromstring(z.read('word/styles.xml'))
    assert not styles.findall('.//w:pBdr',ns)
report['document_structure']={'numeric_citations_sequential':True,'references':28,'main_tables_filled':3,'embedded_figures':6,'title_border_removed':True,'author_confirmation_items_remain':True}
report['pdf_pages']={}
for name in ['Genes_Manuscript_English','Genes_Cover_Letter_English']:
    d=pymupdf.open(Path('work/genes_docx_qa')/name/(name+'.pdf'))
    assert all(len(p.get_text().strip())>20 for p in d)
    assert all('\ufffd' not in p.get_text() for p in d)
    report['pdf_pages'][name]=len(d)
report['limitations']=['Human scientific review pending','External gene signature not replicated','Animal-level module tests not FDR significant','External expression units unresolved','Fresh environment full rerun not performed','Persistent code repository not created']
(root/'qa/final_consistency_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
