"""Cross-check deposited bibliographic metadata with Europe PMC core records."""
from pathlib import Path
import requests,json,time
root=Path('work/genes')
refs=json.loads(Path('work/revision/sources/references/verified.json').read_text(encoding='utf8'))
records={};audit=[]
session=requests.Session()
for key,r in refs.items():
    response=session.get('https://www.ebi.ac.uk/europepmc/webservices/rest/search',params={'query':'DOI:"'+r['DOI']+'"','format':'json','resultType':'core','pageSize':1},timeout=45)
    response.raise_for_status();results=response.json().get('resultList',{}).get('result',[])
    if results:
        record=results[0]
        if record.get('doi','').lower()!=r['DOI'].lower():raise ValueError('Unexpected DOI')
        records[key]=record
    audit.append({'key':key,'doi':r['DOI'],'crossref_authors':len(r.get('author',[])),'europepmc_authors':len(records.get(key,{}).get('authorList',{}).get('author',[])),'matched':key in records})
    print(audit[-1],flush=True)
    (root/'reference_metadata_core.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf8')
    (root/'reference_crosscheck.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
    time.sleep(.2)
