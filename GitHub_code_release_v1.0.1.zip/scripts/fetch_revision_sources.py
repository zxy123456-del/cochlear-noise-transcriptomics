from pathlib import Path
import gzip
import hashlib
import json
import urllib.request
import datetime
import csv

ROOT = Path('work/revision')
SRC = ROOT / 'sources'
SRC.mkdir(parents=True, exist_ok=True)
log = []

def fetch(url, name):
    p = SRC / name
    if not p.exists():
        req = urllib.request.Request(url, headers={'User-Agent': 'CochlearTranscriptomeReanalysis/1.0'})
        with urllib.request.urlopen(req, timeout=90) as r:
            p.write_bytes(r.read())
    log.append({'url': url, 'file': name, 'access_date': str(datetime.date.today()),
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size})
    print(name, p.stat().st_size, flush=True)
    return p

def parse_soft(p):
    samples = []
    current = None
    with gzip.open(p, 'rt', encoding='utf-8') as f:
        for line in f:
            if line.startswith('^SAMPLE = '):
                current = {'gsm': line.strip().split(' = ', 1)[1]}
                samples.append(current)
            elif current is not None and line.startswith('!Sample_') and ' = ' in line:
                k, v = line.strip().split(' = ', 1)
                k = k.removeprefix('!Sample_')
                if k == 'characteristics_ch1' and ': ' in v:
                    k, v = v.split(': ', 1)
                current[k] = (current[k] + ' | ' + v) if k in current else v
    return samples

for acc in ['GSE168973', 'GSE168041', 'GSE167078']:
    p = fetch(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/soft/{acc}_family.soft.gz', acc + '_family.soft.gz')
    samples = parse_soft(p)
    (SRC / (acc + '_samples.json')).write_text(json.dumps(samples, ensure_ascii=False, indent=2), encoding='utf-8')
    cols = sorted(set().union(*(s.keys() for s in samples)))
    with (SRC / (acc + '_samples.csv')).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader(); w.writerows(samples)
    for s in samples:
        print({k:s.get(k) for k in ['gsm','title','cell type','genotype','age','treatment','time point','source_name_ch1']}, flush=True)

for url,name in [
    ('https://www.ebi.ac.uk/europepmc/webservices/rest/PMC8709734/fullTextXML','Milon_2021.xml'),
    ('https://maayanlab.cloud/MouseEnrichr/datasetStatistics','mouse_enrichr_libraries.json'),
    ('https://maayanlab.cloud/Enrichr/datasetStatistics','enrichr_libraries.json')]:
    try: fetch(url,name)
    except Exception as e: print(name,repr(e),flush=True)
(SRC / 'download_manifest.json').write_text(json.dumps(log, indent=2), encoding='utf-8')
