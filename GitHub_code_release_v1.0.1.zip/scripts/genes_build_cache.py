"""Optional raw-matrix preprocessing matching the frozen reference atlas.

Run genes_verify_raw.py --download first to obtain and unpack the GEO archive.
Fresh embeddings can vary with platform; published inference uses frozen cell
identities, whose counts are independently verifiable against the GEO matrices.
"""
from pathlib import Path
import gzip, re, os
os.environ.setdefault('MPLCONFIGDIR', str(Path('work/mplconfig').resolve()))
import pandas as pd
import scanpy as sc
from anndata import AnnData
from scipy import io

BASE=Path('work/geo_reanalysis/extracted/GSE168041')
OUT=Path('work/geo_reanalysis/results')

def load(path):
    base=str(path).replace('_matrix.mtx.gz','')
    with gzip.open(path,'rb') as f: matrix=io.mmread(f).T.tocsr()
    genes=pd.read_csv(base+'_genes.tsv.gz',sep='\t',header=None)
    barcodes=pd.read_csv(base+'_barcodes.tsv.gz',sep='\t',header=None)[0]
    ad=AnnData(matrix)
    ad.var_names=pd.Index(genes[0].astype(str))
    ad.var['gene_symbol']=genes[1].astype(str).to_numpy()
    m=re.search(r'GSM\d+_MouseCochlea(?P<tissue>Neurons|Stria)_(?P<condition>naive|noise)(?P<rep>\d+)',path.name)
    if not m: raise ValueError(path)
    sid=path.name.split('_')[0]
    ad.obs_names=[sid+'_'+str(b) for b in barcodes]
    ad.obs['sample']=sid
    ad.obs['tissue']=m['tissue'];ad.obs['condition']=m['condition'];ad.obs['replicate']=int(m['rep'])
    return ad

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    for tissue in ['Neurons','Stria']:
        target=OUT/f'GSE168041_{tissue}_processed.h5ad'
        if target.exists(): raise FileExistsError(f'Will not overwrite existing cache: {target}')
        files=sorted(BASE.glob(f'*MouseCochlea{tissue}_*_matrix.mtx.gz'))
        if len(files)!=8: raise ValueError('Expected eight GEO libraries per tissue')
        pieces=[load(p) for p in files]
        ad=sc.concat(pieces,join='inner',merge='same',index_unique=None)
        ad.var['gene_symbol']=pieces[0].var.gene_symbol.to_numpy()
        ad.var['mt']=ad.var.gene_symbol.str.upper().str.startswith('MT-')
        sc.pp.calculate_qc_metrics(ad,qc_vars=['mt'],percent_top=None,log1p=False,inplace=True)
        ad=ad[(ad.obs.n_genes_by_counts>=200)&(ad.obs.total_counts>=500)&(ad.obs.pct_counts_mt<20)].copy()
        ad.raw=ad.copy()
        sc.pp.normalize_total(ad,target_sum=10000);sc.pp.log1p(ad)
        sc.pp.highly_variable_genes(ad,flavor='cell_ranger',n_top_genes=2000,batch_key='sample')
        ad=ad[:,ad.var.highly_variable].copy()
        sc.pp.scale(ad,max_value=10);sc.tl.pca(ad,n_comps=30,svd_solver='arpack',random_state=0)
        sc.pp.neighbors(ad,n_neighbors=15,n_pcs=30,random_state=0)
        sc.tl.umap(ad,random_state=1)
        sc.tl.leiden(ad,resolution=.5,key_added='cluster',random_state=1,flavor='igraph',n_iterations=2)
        ad.write_h5ad(target,compression='gzip')
        print('BUILT',target,flush=True)

if __name__=='__main__':main()
