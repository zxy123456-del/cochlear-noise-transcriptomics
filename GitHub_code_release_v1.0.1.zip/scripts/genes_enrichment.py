"""Mouse-native enrichment, multiplicity accounting and external concordance."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR',str(Path('work/mplconfig').resolve()))
import json
from collections import Counter
import numpy as np
import pandas as pd
from scipy.stats import hypergeom, ttest_ind, spearmanr
from statsmodels.stats.multitest import multipletests
import gseapy as gp

ROOT=Path('work/genes')
OUT=ROOT/'enrichment'
OUT.mkdir(exist_ok=True)
SOURCE=Path('work/revision/sources')
FOCUS=['GOBP_SYNAPSE_ORGANIZATION','GOBP_SYNAPTIC_VESICLE_CYCLE','GOBP_RESPONSE_TO_OXIDATIVE_STRESS']

def readgmt(path):
    return {x[0]:set(g for g in x[2:] if g) for x in (l.strip().split('\t') for l in path.read_text().splitlines())}

LIBS={k:readgmt(SOURCE/f) for k,f in {'GO_BP':'GO_BP_mouse_2025.1.gmt','GO_CC':'GO_CC_mouse_2025.1.gmt','Reactome':'Reactome_mouse_2025.1.gmt','KEGG':'KEGG_2019_Mouse.gmt'}.items()}
SETS={k:LIBS['GO_BP'][k] for k in FOCUS}

def adjust(p):
    p=np.asarray(p,dtype=float)
    out=np.full(p.shape,np.nan)
    mask=np.isfinite(p)
    out[mask]=multipletests(p[mask],method='fdr_bh')[1]
    return out

def ora(df,name):
    background=set(df.loc[df.pvalue.notna(),'gene'])
    rows=[]
    for label,lib in LIBS.items():
        # The mouse-specific Enrichr library stores mouse symbols in uppercase.
        # Unique case-normalization is NOT a human-to-mouse orthology conversion.
        lookup={g.upper():g for g in background}
        frequency=Counter(g.upper() for g in background)
        ambiguous={u for u,n in frequency.items() if n>1} if label=='KEGG' else set()
        mapped={k:{lookup[g] for g in v if g in lookup and g not in ambiguous} for k,v in lib.items()} if label=='KEGG' else {k:v & background for k,v in lib.items()}
        for direction in ['up','down']:
            q=set(df.loc[df.padj.lt(.05) & (df.log2FoldChange.gt(0) if direction=='up' else df.log2FoldChange.lt(0)),'gene'])
            family=[]
            for term,members in mapped.items():
                if not 10<=len(members)<=2000:
                    continue
                overlap=members & q
                p=float(hypergeom.sf(len(overlap)-1,len(background),len(members),len(q))) if q else 1.
                family.append({'analysis':name,'library':label,'direction':direction,'term':term,'overlap':len(overlap),'query_size':len(q),'term_size':len(members),'background':len(background),'pvalue':p,'genes':';'.join(sorted(overlap))})
            if family:
                f=pd.DataFrame(family)
                f['padj']=adjust(f.pvalue)
                rows.append(f)
    return pd.concat(rows,ignore_index=True)

def gsea(df,name):
    ranked=df.loc[df.pvalue.notna(),['gene','stat']].replace([np.inf,-np.inf],np.nan).dropna().sort_values(['stat','gene'],ascending=[False,True])
    r=gp.prerank(rnk=ranked,gene_sets={k:sorted(v) for k,v in SETS.items()},min_size=10,max_size=2000,permutation_num=10000,seed=2026,threads=1,outdir=None,verbose=False)
    f=r.res2d.copy()
    f.insert(0,'analysis',name)
    return f

def main():
    files=sorted((ROOT/'celltypes').glob('*_strict_DE.csv'))
    all_de=[]; oras=[]; gseas=[]; scores=[]; score_tests=[]
    for p in files:
        name=p.stem.removesuffix('_DE')
        df=pd.read_csv(p)
        df.insert(0,'analysis',name)
        all_de.append(df)
        print('ENRICH',name,flush=True)
        o=OUT/f'{name}_ORA.csv.gz'
        oras.append(pd.read_csv(o) if o.exists() else ora(df,name))
        if not o.exists(): oras[-1].to_csv(o,index=False)
        gs=OUT/f'{name}_GSEA.csv'
        gseas.append(pd.read_csv(gs) if gs.exists() else gsea(df,name))
        if not gs.exists(): gseas[-1].to_csv(gs,index=False)
        counts=pd.read_csv(ROOT/'celltypes'/f'{name}_normalized.csv.gz',index_col=0)
        meta=pd.read_csv(ROOT/'celltypes'/f'{name}_metadata.csv',index_col=0)
        y=np.log2(counts+1)
        z=y.sub(y.mean(1),axis=0).div(y.std(1).replace(0,np.nan),axis=0)
        for term,genes in SETS.items():
            common=sorted(set(z.index)&genes)
            s=z.loc[common].mean(0)
            a=s.loc[meta.condition.eq('noise')]; b=s.loc[meta.condition.eq('naive')]
            test=ttest_ind(a,b,equal_var=False)
            score_tests.append({'analysis':name,'term':term,'genes':len(common),'mean_difference':a.mean()-b.mean(),'pvalue':test.pvalue})
            scores.extend({'analysis':name,'term':term,'sample':sid,'condition':meta.loc[sid,'condition'],'score':v} for sid,v in s.items())
    de=pd.concat(all_de,ignore_index=True)
    de['padj_global']=adjust(de.pvalue)
    de.to_csv(OUT/'all_celltype_DE_globalFDR.csv.gz',index=False)
    pd.concat(oras).to_csv(OUT/'all_ORA.csv.gz',index=False)
    gs=pd.concat(gseas,ignore_index=True)
    gs['BH_across_focus_tests']=adjust(gs['NOM p-val'])
    gs.to_csv(OUT/'all_focus_GSEA.csv',index=False)
    st=pd.DataFrame(score_tests)
    st['padj_across_celltypes_and_sets']=adjust(st.pvalue)
    st.to_csv(OUT/'sample_level_module_tests.csv',index=False)
    pd.DataFrame(scores).to_csv(OUT/'sample_level_module_scores.csv',index=False)
    intersection=SETS[FOCUS[0]] & SETS[FOCUS[2]]
    synapse=LIBS['GO_CC']['GOCC_SYNAPSE']
    union=synapse|SETS[FOCUS[2]]
    genes=pd.DataFrame({'gene':sorted(union)})
    genes['synapse_CC']=genes.gene.isin(synapse)
    genes['synapse_organization']=genes.gene.isin(SETS[FOCUS[0]])
    genes['oxidative_stress_response']=genes.gene.isin(SETS[FOCUS[2]])
    genes.to_csv(OUT/'gene_set_membership.csv',index=False)
    de[de.gene.isin(synapse & SETS[FOCUS[2]])].to_csv(OUT/'synapse_oxidative_intersection_DE.csv',index=False)
    external=[]; corr=[]; egsea=[]
    sgn=de[de.analysis.eq('Neurons_SGN_strict')].set_index('gene')
    for time in ['0h','4h','8h']:
        e=pd.read_csv(ROOT/'external'/f'DE_{time}.csv').set_index('gene')
        common=sgn.index.intersection(e.index)
        merged=sgn.loc[common].join(e.loc[common],lsuffix='_discovery',rsuffix='_external')
        merged['same_direction']=merged.log2FoldChange*merged.log2_difference>0
        merged['time']=time
        eligible=merged.padj_discovery.lt(.05)&merged.index.isin(union)
        subset=merged.loc[eligible].copy()
        subset['validation_FDR_nominated_family']=adjust(subset.pvalue_external)
        external.append(subset.reset_index())
        valid=merged[['log2FoldChange','log2_difference']].dropna()
        rho=spearmanr(valid.iloc[:,0],valid.iloc[:,1]).statistic
        corr.append({'time':time,'shared_genes':len(valid),'effect_spearman_descriptive':rho,'nominated_genes':len(subset),'same_direction':int(subset.same_direction.sum()),'external_FDR05_concordant':int((subset.same_direction & subset.padj_external.lt(.05)).sum()),'nominated_family_FDR05_concordant':int((subset.same_direction & subset.validation_FDR_nominated_family.lt(.05)).sum())})
        egsea.append(gsea(e.reset_index(),f'GSE312476_{time}'))
    pd.concat(external).to_csv(OUT/'independent_gene_validation.csv',index=False)
    pd.DataFrame(corr).to_csv(OUT/'independent_validation_summary.csv',index=False)
    eg=pd.concat(egsea,ignore_index=True)
    eg['BH_across_time_and_sets']=adjust(eg['NOM p-val'])
    eg.to_csv(OUT/'independent_focus_GSEA.csv',index=False)
    (OUT/'parameters.json').write_text(json.dumps({'GO_MSigDB':'2025.1.Mm','KEGG':'2019_Mouse, exact uppercase normalization with ambiguous mappings excluded','ORA':'hypergeometric; all size-eligible terms including zero overlaps; BH per contrast/library/direction; tested-gene universe','GSEA':'GSEApy prerank; 10000 gene-set permutations; seed 2026; Wald or Welch t ranking; GSEA empirical FDR is NOT BH; additional BH of nominal P values across focus tests; zero nominal P is finite permutation resolution','module_score':'mean across available genes of across-sample z scores of log2(DESeq2 normalized counts+1); Welch; BH across all primary cell types and three sets','focus_sets':FOCUS,'design':'retrospective exploratory; not preregistered; 8h primary external time based on proximity to discovery24h'},indent=2))
    print('ENRICHMENT COMPLETE',flush=True)

if __name__=='__main__':
    main()
