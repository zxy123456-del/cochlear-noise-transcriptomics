"""Assemble the user-facing reproducibility package without old draft outputs."""
from pathlib import Path
import shutil, json, hashlib, subprocess, sys, zipfile, argparse
import pandas as pd

ROOT=Path.cwd(); OUT=ROOT/'outputs/Genes_submission_package_v1'

def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)

def deliverable(p):
    return p.is_file() and '__pycache__' not in p.parts and 'mplconfig' not in p.parts and not (p.parent.name=='qa' and p.suffix in ['.png','.pdf'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--zip',action='store_true');args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    for p in (ROOT/'work/genes').rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:continue
        if p.parent.name=='sources' and p.name.endswith('_family.soft.gz') and not p.name.startswith('GSE312476'):continue
        if p.name=='GSE312476_Table_S1.xlsx':continue
        if p.parent.name=='qa' and p.suffix in ['.png','.pdf']:continue
        copy(p,OUT/p.relative_to(ROOT))
    for p in (ROOT/'work/scripts').glob('genes_*.py'):
        if p.name in ['genes_package.py','genes_build_documents.py','genes_audit_figures.py','genes_render_documents.py','genes_final_audit.py','genes_refresh_gsea.py']:continue
        copy(p,OUT/'work/scripts'/p.name)
    helper=Path.home()/'.codex/skills/nature-figure/scripts/audit_panel_alignment.py'
    copy(helper,OUT/'work/scripts'/helper.name)
    source=ROOT/'work/revision/sources'
    for p in [*source.glob('*.gmt'),source/'gene_set_manifest.json',source/'references/verified.json']:
        copy(p,OUT/p.relative_to(ROOT))
    copy(ROOT/'work/genes/README_reproducibility.md',OUT/'README.md')
    copy(ROOT/'work/genes/submission_readiness_zh.md',OUT/'投稿前必读.md')
    copy(ROOT/'work/genes/submission_readiness_zh.md',ROOT/'outputs/Genes_投稿前必读.md')
    freeze=subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,check=True).stdout
    (OUT/'requirements-lock.txt').write_bytes(freeze)
    (OUT/'VERSION').write_text('1.0.0\n')
    audit=[
        ['GSE168041','Discovery','16 libraries; 4 controls and 4 exposed per tissue','24 h; replicated single cell counts'],
        ['GSE312476','External comparison','12 samples; n=3 per group','0,4,8 h; deposited noninteger continuous values'],
        ['GSE167078','Not independent validation','Same source study as discovery','Pooled CD45-enriched design; no animal-replicated intended contrast'],
        ['GSE168973','Not independent validation','Same source study as discovery','Distinct RiboTag targeting and IP/input design'],
        ['GSE100365','Not selected','24 h contrast','Control female versus exposed male confounds sex and treatment'],
        ['GSE85290','Not selected','Pooled array design','Insufficient independent replicate libraries'],
        ['GSE8342','Not selected','Two strains and early time','Less matched strain/time than selected external study'],
        ['GSE12810','Not selected','Chronic post-exposure interval','Time mismatch and sex imbalance'],
        ['GSE312646','Not selected','51 GeoMx ROIs and 10 animals','Animal-to-ROI linkage unresolved; time metadata inconsistent']]
    pd.DataFrame(audit,columns=['accession','role','design','reason_or_notes']).to_csv(OUT/'Supplementary_Table_S1_dataset_audit.csv',index=False)
    cells=[]
    for t in ['Neurons','Stria']:
        f=pd.read_csv(ROOT/f'work/genes/{t}_QC.csv');f.insert(0,'tissue',t);cells.append(f)
    pd.concat(cells).to_csv(OUT/'Supplementary_Table_S2_QC.csv',index=False)
    provenance={'release':'1.0.0','accessed_primary':'2026-09-27','accessed_external':'2026-09-28','raw_archive':{'url':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168041/suppl/GSE168041_RAW.tar','sha256':hashlib.file_digest((ROOT/'work/geo_reanalysis/raw/GSE168041_RAW.tar').open('rb'),'sha256').hexdigest()},'primary_data_url':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE168041','external_data_url':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE312476','raw_verification':'157 matrices; all counts identical','clean_environment_rerun':'not performed','public_repository':'not created; human approval required','journal_instructions':'https://www.mdpi.com/journal/genes/instructions'}
    (OUT/'provenance.json').write_text(json.dumps(provenance,indent=2))
    index='''# Supplementary Index

All paths are relative to the extracted package root. CSV.gz files are gzip-compressed CSV.
The analysis outputs contain all tested genes/terms, including nonsignificant values.

| Item | Exact file or file family |
|---|---|
| Table S1 dataset audit | Supplementary_Table_S1_dataset_audit.csv |
| Table S2 cell QC | Supplementary_Table_S2_QC.csv; work/genes/*_QC.csv |
| Table S3 sample coverage and identities | work/genes/celltypes/*_summary.csv; *_metadata.csv; *_annotated_cells.csv.gz; work/genes/*_marker_audit.csv |
| Table S4 gene level primary results | work/genes/enrichment/all_celltype_DE_globalFDR.csv.gz; work/genes/celltypes/*_strict_DE.csv |
| Table S5 ORA | work/genes/enrichment/all_ORA.csv.gz |
| Table S6 focused GSEA and sample modules | work/genes/enrichment/all_focus_GSEA.csv; sample_level_module_tests.csv; sample_level_module_scores.csv |
| Table S7 set membership and network | work/genes/enrichment/gene_set_membership.csv; synapse_oxidative_intersection_DE.csv; work/genes/network/* |
| Table S8 independent comparison | work/genes/external/DE_0h.csv; DE_4h.csv; DE_8h.csv; work/genes/enrichment/independent_*.csv |
| Table S9 sensitivity | work/genes/celltypes/Neurons_SGN_liberal_DE.csv; Neurons_Glia_liberal_DE.csv; leave_one_out_direction_fraction in each DE file |
| Table S10 raw verification | work/genes/raw_reaggregation_verification.csv; qa/rerun_checks.json when included |
| Figures 1 to 6 | work/genes/figures/Figure1_*.png/pdf through Figure6_*.png/pdf |
| Figure S1 marker annotation | work/genes/figures/FigureS1_annotation.png/pdf |
| Figure S2 SGN volcano | work/genes/figures/FigureS2_SGN_volcano.png/pdf |
| Figure S3 sample heatmap | work/genes/figures/FigureS3_SGN_heatmap.png/pdf |
| Figure S4 functional network | work/genes/figures/FigureS4_functional_network.png/pdf |
| Code S1 | This entire package; scripts in work/scripts; README.md; requirements-lock.txt |

## Supplementary Figure Legends

Figure S1. Canonical marker audit of the stringent retained cells. Dot area is the
fraction of cells with detected expression; color is the cell-type mean log1p
normalized expression divided by the maximum mean for that gene within the tissue.
Panels show neural-enriched and lateral-wall preparations. These are descriptive
cell summaries, not replicate-level hypothesis tests. Mixed populations are retained
in the display but excluded from differential expression.

Figure S2. SGN pseudobulk volcano plot. Each point is a tested gene. The x axis is
the unshrunk noise/control log2 fold change; the y axis is -log10 within-comparison
BH-adjusted P, capped at 100 for display. Red and blue denote increased and decreased
genes at FDR < 0.05; gray denotes nonsignificant genes. n=4 animals per condition.

Figure S3. Top 24 SGN genes ranked by within-comparison adjusted P. Values are row
z scores of log2(DESeq2 normalized counts + 1), with color limits -2 and 2. C1-C4
are GSM5124291-GSM5124294 and N1-N4 are GSM5124295-GSM5124298. This discovery-selected
display is not an independently validated classifier.

Figure S4. STRING version 12 functional associations among the 20 SGN differential
genes shared by the synapse and oxidative stress annotations. All queried nodes,
including isolates, are displayed; 12 undirected edges meet score >=0.700. No extra
interactors were added. Node color indicates discovery log2 fold change (limits
-1.5 to 1.5). Edges need not be physical protein interactions and do not imply
cochlea-specific activity, directionality or causation.
'''
    (OUT/'Supplementary_Index.md').write_text(index,encoding='utf8')
    for p in (ROOT/'outputs').glob('Genes_*_English.docx'):copy(p,OUT/p.name)
    q=ROOT/'work/genes_smoke/rerun_checks.json'
    if q.exists():copy(q,OUT/'qa/rerun_checks.json')
    rows=[]
    for p in sorted(OUT.rglob('*')):
        if deliverable(p) and p.name!='SHA256SUMS.csv':
            rows.append({'file':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()})
    pd.DataFrame(rows).to_csv(OUT/'SHA256SUMS.csv',index=False)
    if args.zip:
        dest=ROOT/'outputs/Genes_analysis_and_submission_package_v1.zip'
        with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in OUT.rglob('*'):
                if deliverable(p):z.write(p,p.relative_to(OUT.parent))
        print('ZIP',dest,round(dest.stat().st_size/1e6,2),'MB',flush=True)
    print('FILES',len(rows),flush=True)

if __name__=='__main__':main()
