"""Download public metadata and independent count data; retain provenance."""
from pathlib import Path
import gzip
import hashlib
import json
from datetime import datetime, timezone
import requests
import pandas as pd

ROOT = Path('work/genes')
SRC = ROOT / 'sources'
SRC.mkdir(parents=True, exist_ok=True)
manifest = []

def fetch(url, filename=None):
    url = url.replace('ftp://', 'https://')
    path = SRC / (filename or url.rsplit('/',1)[-1])
    if not path.exists():
        r=requests.get(url,timeout=120)
        r.raise_for_status()
        path.write_bytes(r.content)
    manifest.append(dict(url=url,file=path.name,download_date_utc=datetime.now(timezone.utc).isoformat(),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    return path

def soft(accession):
    p=fetch(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{accession[:-3]}nnn/{accession}/soft/{accession}_family.soft.gz')
    txt=gzip.open(p,'rt',encoding='utf-8').read()
    samples=[]
    current=None
    for line in txt.splitlines():
        if line.startswith('^SAMPLE = '):
            current={'gsm':line.split(' = ',1)[1]}
            samples.append(current)
        elif current is not None and line.startswith('!Sample_') and ' = ' in line:
            key,value=line.split(' = ',1)
            key=key[8:]
            current.setdefault(key,[]).append(value)
    (SRC/f'{accession}_samples.json').write_text(json.dumps(samples,indent=2,ensure_ascii=False),encoding='utf-8')
    return samples

if __name__=='__main__':
    for acc in ['GSE312476','GSE312646','GSE100365','GSE8342','GSE12810','GSE85290']:
        samples=soft(acc)
        print(acc,len(samples),flush=True)
        if acc=='GSE312476':
            for sample in samples:
                for k,v in sample.items():
                    if k.startswith('supplementary_file'):
                        for url in v:
                            p=fetch(url)
                            print(p.name,flush=True)
            fetch('https://ftp.ncbi.nlm.nih.gov/geo/series/GSE312nnn/GSE312476/suppl/GSE312476_Table_S1.xlsx')
    (SRC/'download_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
