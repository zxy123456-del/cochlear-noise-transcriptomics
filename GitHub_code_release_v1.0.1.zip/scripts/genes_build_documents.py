"""Build the Genes author-review manuscript and conditional cover letter."""
from pathlib import Path
import re, json, html
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT=Path.cwd(); DATA=ROOT/'work/genes'; OUT=ROOT/'outputs'
OUT.mkdir(exist_ok=True)
REFERENCES=json.loads((ROOT/'work/revision/sources/references/verified.json').read_text(encoding='utf8'))
REF_OVERRIDES=ROOT/'work/genes/reference_metadata_core.json'
REF_CORE=json.loads(REF_OVERRIDES.read_text(encoding='utf8')) if REF_OVERRIDES.exists() else {}
SOURCE=(DATA/'manuscript_en.md').read_text(encoding='utf8')
ORDER=[]
REVISION=DATA/'revision_v2'
AUTHORS=[
    ('Xiongyue Zai','1,\u2020','0009-0002-5749-1632','2895002815@qq.com'),
    ('Yao Kong','2,\u2020','0009-0006-3819-7429','1916230481@qq.com'),
    ('Jiazhi Yin','3','0009-0003-6856-2659','467025380@qq.com'),
    ('Yong Tang','3,*','0009-0008-9976-3708','yongtang0929@sina.com'),
]

def cite(m):
    ids=[]
    for key in m.group(1).split(';'):
        if key not in REFERENCES:raise KeyError(key)
        if key not in ORDER:ORDER.append(key)
        ids.append(str(ORDER.index(key)+1))
    return '['+', '.join(ids)+']'

SOURCE=re.sub(r'\[@([^\]]+)\]',cite,SOURCE)
GENES=['Snap25','Syt2','Syn1','Gpx2','Gpx4','Hmox1','Sox10','Plp1','Mpz','Lyz2','C1qa','Tyrobp','Cldn5','Pecam1','Rgs5','Pdgfrb','Dcn','Col1a1','Epcam','Dct','Kcnj10','Kcne1','Kcnq1','Slc12a2','Cldn11','Calb2','Lypd1','Tubb3']
GENERE=re.compile(r'\b('+'|'.join(GENES)+r')\b')

def rich(p,text):
    for i,part in enumerate(re.split(r'\*\*(.*?)\*\*',text)):
        start=0
        for m in GENERE.finditer(part):
            r=p.add_run(part[start:m.start()]);r.bold=True if i%2 else None
            r=p.add_run(m.group());r.italic=True;r.bold=True if i%2 else None
            start=m.end()
        r=p.add_run(part[start:]);r.bold=True if i%2 else None

def setup(doc,label):
    s=doc.sections[0];s.page_width=Inches(8.5);s.page_height=Inches(11)
    s.top_margin=Inches(.8);s.bottom_margin=Inches(.8)
    s.left_margin=Inches(1);s.right_margin=Inches(1)
    s.header_distance=Inches(.3);s.footer_distance=Inches(.3)
    for el in list(doc.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
    for el in doc.styles.element.iter(qn('w:rFonts')):
        for key in list(el.attrib):
            if 'theme' in key.lower():del el.attrib[key]
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
        style=doc.styles[name];style.font.name='Times New Roman';style.font.color.rgb=RGBColor(0,0,0)
        style.paragraph_format.space_after=Pt(6)
        if name=='Normal':style.font.size=Pt(11);style.paragraph_format.line_spacing=1.15
        if name=='Title':style.font.size=Pt(17);style.font.bold=True;style.paragraph_format.space_after=Pt(9)
        if name.startswith('Heading'):
            style.font.size=Pt(12 if name=='Heading 1' else 11);style.font.bold=True
            style.paragraph_format.space_before=Pt(10);style.paragraph_format.keep_with_next=True
        if name=='Caption':
            style.font.size=Pt(9);style.font.italic=False;style.font.bold=False;style.paragraph_format.line_spacing=1.05
            style.paragraph_format.keep_together=True
    header=s.header.paragraphs[0];header.text=label
    for r in header.runs:r.font.name='Times New Roman';r.font.size=Pt(8)
    footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');footer._p.append(f)
    doc.core_properties.title=label;doc.core_properties.author='; '.join(a[0] for a in AUTHORS)

def p(doc,text,style=None):
    par=doc.add_paragraph(style=style);rich(par,text);return par

def caption(doc,text):
    par=p(doc,text,'Caption');return par

def link(par,text,url):
    h=OxmlElement('w:hyperlink')
    h.set(qn('r:id'),par.part.relate_to(url,RT.HYPERLINK,is_external=True))
    r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);par._p.append(h)

def author_block(doc):
    par=doc.add_paragraph()
    for i,(name,symbol,orcid,email) in enumerate(AUTHORS):
        if i:par.add_run(', ' if i<3 else ' and ')
        par.add_run(name).bold=True
        par.add_run(symbol).font.superscript=True
    affiliations=[
        ('1','Department of Otolaryngology, Northeast Yunnan Central Hospital, 617 Ludian Road, Zhaoyang District, Zhaotong 657000, Yunnan, China; ',AUTHORS[0][3]),
        ('2','Department of Radiation Oncology, Northeast Yunnan Central Hospital, 617 Ludian Road, Zhaoyang District, Zhaotong 657000, Yunnan, China; ',AUTHORS[1][3]),
        ('3','Department of Otolaryngology-Head and Neck Surgery, The First Affiliated Hospital of Kunming Medical University, 295 Xichang Road, Wuhua District, Kunming 650032, Yunnan, China; ',AUTHORS[2][3]),
    ]
    for symbol,text,email in affiliations:
        par=doc.add_paragraph(style='Author Details');par.add_run(symbol+' ').font.superscript=True
        par.add_run(text);link(par,email,'mailto:'+email)
        if symbol=='3':par.add_run(' (J.Y.); ');link(par,AUTHORS[3][3],'mailto:'+AUTHORS[3][3]);par.add_run(' (Y.T.)')
    par=doc.add_paragraph(style='Author Details');par.add_run('* Correspondence: ')
    link(par,AUTHORS[3][3],'mailto:'+AUTHORS[3][3]);par.add_run(' (Yong Tang)')
    par=doc.add_paragraph(style='Author Details');par.add_run('\u2020 These authors contributed equally to this work.').italic=True
    for name,symbol,orcid,email in AUTHORS:
        par=doc.add_paragraph(style='Author Details');par.add_run(name+' ORCID: ');link(par,orcid,'https://orcid.org/'+orcid)

def table(doc,headers,rows,widths):
    t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    props=t._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    props.append(borders)
    for j,w in enumerate(widths):t.columns[j].width=Inches(w)
    for j,h in enumerate(headers):t.rows[0].cells[j].text=h
    repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
    for row in rows:
        cells=t.add_row().cells
        for j,value in enumerate(row):cells[j].text=str(value)
    for i,row in enumerate(t.rows):
        cannot=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cannot)
        for j,c in enumerate(row.cells):
            c.width=Inches(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tc=c._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
            for edge in ['top','bottom','left','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');mar.append(e)
            tc.append(mar)
            if i==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E6E6E6');tc.append(sh)
            for par in c.paragraphs:
                par.paragraph_format.line_spacing=1.05
                par.paragraph_format.space_after=Pt(1);par.paragraph_format.space_before=Pt(1)
                par.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
                for r in par.runs:
                    r.font.size=Pt(9);r.bold=i==0
                    if headers[0]=='Gene' and j==0 and i>0:r.italic=True
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t

def table1(doc):
    cap=caption(doc,'Table 1. Datasets used for discovery and independent comparison.');cap.paragraph_format.keep_with_next=True
    table(doc,['Dataset','Compartment','Design','Exposure and collection'],[
      ['GSE168041','Neural enriched; lateral wall','4 controls and 4 exposed per tissue; 16 libraries','105 dB SPL for 2 h; collected at 24 h'],
      ['GSE312476','Whole cochlea','3 controls and 3 at each post-noise time; 12 samples','100 dB SPL for 2 h; 0, 4 and 8 h']],[1.0,1.3,2.0,2.2])
    caption(doc,'Both datasets used male CBA/CaJ mice, with different ages and noise levels. GSE168041 is a single-cell count dataset; GSE312476 supplies continuous deposited expression of unresolved normalization units. External 8 h is the primary comparison, not a time-matched validation cohort.')

def table2(doc):
    cap=caption(doc,'Table 2. Eligible broad cell-type analyses after stringent cell filtering.');cap.paragraph_format.keep_with_next=True
    d=pd.concat([pd.read_csv(DATA/f'celltypes/{t}_summary.csv') for t in ['Neurons','Stria']])
    d=d[d.QC.eq('strict')&d.eligible&~d.cell_type.str.startswith('SGN_')]
    rows=[]
    for r in d.itertuples():
        rows.append([('Neural / ' if r.tissue=='Neurons' else 'Wall / ')+r.cell_type.replace('_',' '),f'{r.n_naive}/{r.n_noise}',f'{r.cells:,}',f'{int(r.tested):,}',f'{int(r.up):,}',f'{int(r.down):,}'])
    table(doc,['Compartment and cell type','n C/N','Cells','Tested genes','Higher','Lower'],rows,[2.25,.6,.85,1,.9,.9])
    caption(doc,'C, control; N, noise; n is biological sample number, not cell number. Higher and lower refer to within-comparison BH FDR < 0.05. Secondary SGN strata and the ineligible neural mural population are fully reported in Supplementary Table S3. Differences in discovery counts are not formal cell-type interaction tests.')

def table3(doc):
    cap=caption(doc,'Table 3. Selected SGN effects and independent 8 h comparison.');cap.paragraph_format.keep_with_next=True
    d=pd.read_csv(DATA/'enrichment/all_celltype_DE_globalFDR.csv.gz')
    d=d[d.analysis.eq('Neurons_SGN_strict')].set_index('gene')
    e=pd.read_csv(DATA/'external/DE_8h.csv').set_index('gene')
    rows=[]
    for g in ['Snap25','Syt2','Syn1','Gpx2','Gpx4','Hmox1']:
        a,b=d.loc[g],e.loc[g]
        rows.append([g,f'{a.log2FoldChange:.3f}\n({a.CI_low:.3f}, {a.CI_high:.3f})',f'{a.padj_global:.2e}',f'{b.log2_difference:.3f}\n({b.CI_low:.3f}, {b.CI_high:.3f})',f'{b.padj:.3f}'])
    t=table(doc,['Gene','SGN log2 FC\n(95% CI)','Global FDR','External effect\n(95% CI)','External FDR'],rows,[.75,1.7,1.0,1.9,1.15])
    for row in t.rows:
        for c in row.cells:
            for par in c.paragraphs:par.paragraph_format.keep_with_next=True
    doc.paragraphs[-1].paragraph_format.keep_with_next=True
    caption(doc,'SGN estimates use four samples per condition; external estimates use three per condition. SGN intervals are Wald intervals. External effects are differences in mean log2(deposited expression + 1), with Welch intervals; they are not directly comparable count-model fold changes. Global FDR covers 183,548 finite gene-by-stratum tests; external FDR covers all 14,815 tested genes at 8 h. The six genes are illustrative, not a preregistered panel.')

FIGURES={
1:('Figure1_workflow','Figure 1. Study workflow. Discovery analysis preserves the animal as the inferential unit. The independent dataset is analyzed separately because its exposure, collection interval and tissue mixture differ. No external sample is integrated into the discovery embedding.'),
2:('Figure2_cell_atlas','Figure 2. Reference UMAP of stringent retained cells in (a) neural-enriched and (b) lateral-wall preparations. The panels contain 25,983 and 31,040 cells, respectively, from four control and four exposed samples per tissue. Colors show marker-based broad labels. Initial-filter reference coordinates were frozen before stringent filtering; distances do not represent treatment effect sizes. Mixed/unassigned populations are displayed but excluded from differential-expression inference.'),
3:('Figure3_celltype_effects','Figure 3. Selected gene effects across 14 eligible broad cell types. Color indicates unshrunk noise/control log2 fold change, clipped to -1.5 to 1.5 for display. Larger dots indicate global BH FDR < 0.05 across all 17 stringent gene-by-stratum analyses; smaller dots do not pass that threshold. A blank position indicates no tested estimate. Significance in one cell type but not another is not a statistical interaction test.'),
4:('Figure4_focus_enrichment','Figure 4. Focused preranked enrichment across the 17 stringent strata. Color represents normalized enrichment score, with limits -3 to 3. Dot area reflects -log10 of the BH-adjusted nominal permutation P value across 51 tests, truncated to 0.1-4 for display. GSEA uses gene-set permutations, not animal-label permutations. Critically, none of the complementary 51 animal-level module tests met FDR < 0.05; these results are provided in Supplementary Table S6.'),
5:('Figure5_independent_validation','Figure 5. Independent 8 h comparison. (a) All shared gene effects in discovery SGNs and external whole-cochlea expression. (b) Six selected illustrative genes, with point estimates and 95% confidence intervals. Discovery intervals use Wald estimates with n=4 per condition; external intervals use Welch estimates with n=3 per condition. The two axes/effect definitions are not equivalent measurement scales. No illustrated gene achieved genome-wide external FDR < 0.05.'),
6:('Figure6_evidence_summary','Figure 6. Evidence summary, not a validated mechanism diagram. The displayed changes were observed at the transcript level in discovery SGNs. Structural synapse loss, reactive oxygen species and rescue effects were not measured in this reanalysis. The independent comparison did not confirm the nominated gene signature, and animal-level module tests did not provide multiplicity-adjusted pathway support.')}

def figure(doc,n):
    name,legend=FIGURES[n];file=REVISION/'figures'/f'{name}.png'
    w,h=Image.open(file).size
    width=min(6.0 if n==2 else 6.5,5.1*w/h,w/600)
    par=doc.add_paragraph();par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    par.paragraph_format.keep_with_next=True
    shape=par.add_run().add_picture(str(file),width=Inches(width))
    alt=json.loads((REVISION/'figure_alt_text.json').read_text(encoding='utf8'))[name]
    shape._inline.docPr.set('descr',alt)
    shape._inline.docPr.set('title','Figure '+str(n))
    caption(doc,legend)

def reference(key):
    r=REFERENCES[key];authors=r.get('author',[])
    core=REF_CORE.get(key,{})
    if core.get('authorList',{}).get('author'):
        authors=[{'family':a.get('lastName',a.get('collectiveName','')),'given':a.get('firstName','')} for a in core['authorList']['author']]
    names=[]
    for a in authors[:10]:
        initials=''.join(x[0]+'.' for x in re.split(r'[\s-]+',a.get('given','')) if x)
        names.append(a.get('family',a.get('name',''))+(', '+initials if initials else ''))
    if len(authors)>10:names.append('et al.')
    title=html.unescape(re.sub('<[^>]*>','',r['title'][0])).rstrip('.')
    # Full journal titles are permitted when an ISO 4 abbreviation is uncertain.
    journal=html.unescape((r.get('container-title') or [''])[0])
    date=r.get('published-print') or r.get('published-online') or r.get('published') or r['issued']
    year=date['date-parts'][0][0]
    volume=str(r.get('volume',''));pages=str(r.get('page',r.get('article-number','')))
    details=', '.join(x for x in [str(year),volume,pages] if x)
    if key=='Yu2026' and not volume and not pages:
        details+=', in press'
    return '; '.join(names).rstrip('.')+f'. {title}. {journal} {details}. https://doi.org/'+r['DOI']

def manuscript():
    d=Document();setup(d,'Genes | Research Article | Author review draft')
    style=d.styles.add_style('Author Details',1);style.base_style=d.styles['Normal']
    style.font.size=Pt(9);style.paragraph_format.line_spacing=1.0;style.paragraph_format.space_after=Pt(3)
    for block in SOURCE.split('\n\n'):
        block=block.strip()
        if not block:continue
        if block.startswith('# '):p(d,block[2:],'Title')
        elif block.startswith('### '):p(d,block[4:],'Heading 2')
        elif block.startswith('## '):p(d,block[3:],'Heading 1')
        elif re.fullmatch(r'\[\[TABLE\d\]\]',block):{1:table1,2:table2,3:table3}[int(block[7])](d)
        elif re.fullmatch(r'\[\[FIGURE\d\]\]',block):figure(d,int(block[8]))
        elif block=='[[AUTHORS]]':author_block(d)
        elif block=='[[REFERENCES]]':
            for i,k in enumerate(ORDER,1):
                par=p(d,f'{i}. '+reference(k));par.paragraph_format.line_spacing=1.05
                par.paragraph_format.left_indent=Inches(.24);par.paragraph_format.first_line_indent=Inches(-.24)
                for run in par.runs:run.font.size=Pt(10)
        else:p(d,block.replace('\n',' '))
    path=OUT/'Genes_Manuscript_English_v2.docx';d.save(path)
    (DATA/'reference_order.json').write_text(json.dumps({i+1:k for i,k in enumerate(ORDER)},indent=2))
    abstract=SOURCE.split('## Abstract\n\n')[1].split('\n\nKeywords:')[0]
    audit={'references':len(ORDER),'abstract_words':len(re.findall(r"\b[\w'-]+\b",abstract)),'main_figures':len(FIGURES),'tables':3,'unresolved_author_markers':sum(SOURCE.count(x) for x in ['AUTHOR_INPUT_NEEDED','AUTHOR_CONFIRM','AUTHOR_ACTION']),'main_text_words_approx':len(re.findall(r'\b\w+\b',SOURCE.split('## 1 Introduction')[1].split('## Supplementary Materials')[0]))}
    (DATA/'document_content_audit.json').write_text(json.dumps(audit,indent=2))
    print(path,audit)

def cover():
    d=Document();setup(d,'Genes | Cover letter draft')
    p(d,'Cover Letter for Genes','Title')
    p(d,'7 October 2026')
    p(d,'Dear Editors of Genes,')
    title=SOURCE.splitlines()[0][2:]
    p(d,f'Please consider our Research Article, "{title}", for publication in Genes. The manuscript presents an exploratory reanalysis of public mouse cochlear transcriptomic data using cell-type stratification, animal-level pseudobulk inference and an independently generated comparison dataset.')
    p(d,'The work addresses how synaptic and oxidative stress transcript associations depend on cell identity and whether they generalize across studies. We analyzed 57,023 quality-controlled cells, carried out gene- and pathway-level sensitivity analyses, and independently verified 157 sample-by-stratum count matrices against the original GEO files. The accompanying code package provides inputs, parameters, result tables and figure-generation scripts.')
    p(d,'Importantly, the independent dataset did not reproduce the nominated signature, and the animal-level module tests did not provide multiplicity-adjusted pathway support. These results are disclosed in the abstract, results and discussion. We do not claim a newly proven injury mechanism, experimental validation or a reversible hearing-loss model. The contribution is the transparent assessment of cell-resolved associations and their limits of generalization, building on and crediting the original data-generating studies.')
    p(d,'The manuscript may be relevant to readers interested in functional genomics, public-data reanalysis and the statistical interpretation of single-cell studies. No new animal experiments or human participant data are reported. Support from the National Natural Science Foundation of China (grant 82260220) and AI assistance are disclosed in the manuscript. Xiongyue Zai and Yao Kong share first authorship.')
    p(d,'We confirm that neither the manuscript nor any parts of its content are currently under consideration for publication with or published in another journal. All authors have approved the manuscript and agree with its submission to Genes. No related manuscript, preprint or prior MDPI submission is being disclosed in this letter.')
    p(d,'Thank you for considering this work.')
    p(d,'Sincerely,\nYong Tang\nDepartment of Otolaryngology-Head and Neck Surgery\nThe First Affiliated Hospital of Kunming Medical University\n295 Xichang Road, Wuhua District, Kunming 650032, Yunnan, China\nEmail: yongtang0929@sina.com\nTelephone: +86-13577102741\nORCID: 0009-0008-9976-3708')
    path=OUT/'Genes_Cover_Letter_English_v2.docx';d.save(path);print(path)

if __name__=='__main__':manuscript();cover()
