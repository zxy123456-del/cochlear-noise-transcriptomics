
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request, time, math, os

RAW=Path('work/geo_reanalysis/raw')
RAW.mkdir(parents=True, exist_ok=True)
ITEMS={
 'GSE168041_RAW.tar':('https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168041/suppl/GSE168041_RAW.tar',607303680),
}
def get_range(url, start, end, part):
    if part.exists() and part.stat().st_size == end-start+1:
        return part.stat().st_size
    exp=end-start+1
    for attempt in range(1, 5):
        if part.exists() and part.stat().st_size != exp:
            part.unlink()
        try:
            req=urllib.request.Request(url, headers={'Range': f'bytes={start}-{end}', 'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=240) as r, open(part,'wb') as f:
                while True:
                    data=r.read(1024*1024)
                    if not data: break
                    f.write(data)
            sz=part.stat().st_size
            if sz == exp:
                return sz
            print(f'  retry {attempt} for {part.name}: size {sz} != {exp}', flush=True)
        except Exception as e:
            print(f'  retry {attempt} for {part.name}: {e}', flush=True)
    raise RuntimeError(f'{part} failed after retries')

def ranged_download(name, url, size, workers=12):
    out=RAW/name
    if out.exists() and out.stat().st_size == size:
        print(f'SKIP {name}', flush=True); return
    partdir=RAW/(name+'.parts')
    partdir.mkdir(exist_ok=True)
    chunk=math.ceil(size/workers)
    ranges=[]
    for i in range(workers):
        start=i*chunk
        if start>=size: break
        end=min(size-1,(i+1)*chunk-1)
        ranges.append((i,start,end,partdir/f'part_{i:03d}'))
    print(f'DOWNLOAD {name}: {size/1e6:.1f} MB in {len(ranges)} parts', flush=True)
    t0=time.time(); done=0
    with ThreadPoolExecutor(max_workers=len(ranges)) as ex:
        futs=[ex.submit(get_range,url,s,e,p) for i,s,e,p in ranges]
        for fut in as_completed(futs):
            done += fut.result()
            print(f'  {name}: {done/1e6:.1f}/{size/1e6:.1f} MB elapsed={time.time()-t0:.1f}s', flush=True)
    tmp=out.with_suffix(out.suffix+'.join')
    with open(tmp,'wb') as w:
        for i,s,e,p in ranges:
            with open(p,'rb') as r:
                while True:
                    data=r.read(1024*1024)
                    if not data: break
                    w.write(data)
    if tmp.stat().st_size != size:
        raise RuntimeError(f'joined size mismatch {tmp.stat().st_size} != {size}')
    tmp.replace(out)
    print(f'DONE {name}: {out.stat().st_size/1e6:.1f} MB total_elapsed={time.time()-t0:.1f}s', flush=True)

for name,(url,size) in ITEMS.items():
    ranged_download(name,url,size,workers=12 if size>100_000_000 else 4)
