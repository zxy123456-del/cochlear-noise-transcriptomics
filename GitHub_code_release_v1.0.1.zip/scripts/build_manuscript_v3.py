from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import pandas as pd

OUT = Path("outputs/噪音性耳蜗损伤公开转录组再分析_修订稿_v3.docx")
RES = Path("work/geo_reanalysis/results")
FIG = Path("outputs/figures")
doc = Document()
sec = doc.sections[0]
sec.top_margin = Cm(2.1); sec.bottom_margin = Cm(2.0); sec.left_margin = Cm(2.3); sec.right_margin = Cm(2.3)
normal = doc.styles["Normal"]
normal.font.name = "宋体"; normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体"); normal.font.size = Pt(10.5)
normal.paragraph_format.line_spacing = 1.25; normal.paragraph_format.space_after = Pt(5)
for stylename, size, color in [("Title",18,"17324D"),("Heading 1",14,"17324D"),("Heading 2",11.5,"245B78")]:
    s=doc.styles[stylename]; s.font.name="Arial"; s._element.rPr.rFonts.set(qn("w:eastAsia"),"黑体"); s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color)
    s.paragraph_format.space_before=Pt(10); s.paragraph_format.space_after=Pt(4)

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement("w:shd"); shd.set(qn("w:fill"),fill); tcPr.append(shd)

def set_cell(cell,text,bold=False,color=None,size=8.2):
    cell.text=""; p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.bold=bold; r.font.name="Arial"; r._element.rPr.rFonts.set(qn("w:eastAsia"),"宋体"); r.font.size=Pt(size)
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style="Table Grid"
    for j,h in enumerate(headers): set_cell(t.rows[0].cells[j],h,True,"FFFFFF"); shade(t.rows[0].cells[j],"245B78")
    for i,row in enumerate(rows):
        cells=t.add_row().cells
        for j,val in enumerate(row):
            set_cell(cells[j],val)
            if i%2: shade(cells[j],"F2F6F8")
    doc.add_paragraph().paragraph_format.space_after=Pt(1)

def caption(text):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(7)
    r=p.add_run(text); r.italic=True; r.font.size=Pt(9)

def body(text):
    p=doc.add_paragraph(text); p.paragraph_format.first_line_indent=Cm(.74); return p

def fig(path,cap):
    doc.add_picture(str(path),width=Inches(6.25)); caption(cap)

p=doc.add_paragraph(style="Title"); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.add_run("公开单细胞与RiboTag转录组揭示噪声性耳蜗损伤中的突触与氧化还原表达特征")
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run("中文研究论文修订稿（基于公开数据再分析）"); r.font.size=Pt(10); r.font.color.rgb=RGBColor(95,108,120)
body("研究范围说明：所纳入公开数据主要来自小鼠高强度宽带噪声暴露模型，不能直接代表脉冲噪声或可逆性听阈改变。本稿据此限定研究对象为噪声性耳蜗损伤相关转录改变。")

doc.add_heading("摘要",1)
body("目的：整合公开单细胞与RiboTag转录组数据，描述噪声性耳蜗损伤后不同组织中与突触功能及氧化还原稳态相关的表达改变，并评估其对脉冲噪声研究的可迁移性。")
body("方法：主要分析GEO数据集GSE168041的耳蜗神经组织与外侧壁10x单细胞RNA测序矩阵。按细胞阈值进行质控后，分别进行归一化、高变基因筛选、PCA、UMAP与Leiden聚类，并依据标记基因作暂定注释。将原始UMI计数按生物学样本聚合，采用DESeq2进行样本级pseudobulk差异分析。另对GSE168973的RiboTag TPM数据按细胞类型、分级及时间点重新分组；GSE167078因每个处理条件只有一个混合文库，不用于条件间推断。")
body("结果：GSE168041神经组织质控后保留32,440/34,776个细胞，外侧壁保留32,151/36,967个细胞。神经组织与外侧壁分别识别出26个和22个转录簇。样本级pseudobulk比较（每组4个样本）分别检出3,152个和3,103个FDR<0.05的基因。神经组织中多个突触及氧化还原候选基因达到FDR阈值；外侧壁中Gpx1上调、Gpx3下调。三库ORA一致提示神经组织下调基因涉及轴突导向和突触相关过程。Hallmark ROS基因集在神经组织和外侧壁均未显著富集。GSE168973按细胞类型分层的8项探索性比较中，预设候选基因均未达FDR<0.05。")
body("结论：公开数据提示噪声暴露后耳蜗神经组织存在轴突/突触相关转录程序下调，并伴组织依赖的氧化还原候选基因变化；但整体ROS基因集未显著富集。结果支持进一步开展细胞类型特异性验证，不能证明氧化应激导致突触损伤，也不能外推为脉冲噪声所致可逆性耳聋机制。")
body("关键词：噪声性耳蜗损伤；单细胞RNA测序；pseudobulk；突触；氧化还原稳态；耳蜗")

doc.add_heading("1 引言",1)
body("噪声暴露可引起耳蜗多组织损伤，涉及感觉上皮、螺旋神经节、外侧壁及免疫细胞。动物研究显示，即使听阈部分恢复，内毛细胞带状突触和听神经纤维仍可能发生持久改变，因此听阈恢复不能简单等同于耳蜗结构和编码功能完全恢复[2,3]。氧化还原失衡、线粒体应激及炎症信号亦被认为参与噪声相关耳蜗损伤[4,5]。")
body("单细胞RNA测序与RiboTag可分别提供细胞组成层面和细胞类型富集转录信息。Milon等建立了噪声创伤后小鼠内耳的细胞类型转录图谱，并公开了GSE168041、GSE167078和GSE168973等数据[1]。这些数据来自既有声学创伤模型，并非针对脉冲噪声或可逆性耳聋设计。")
body("本研究以GSE168041为主要分析集，按样本保留生物学重复进行pseudobulk差异分析，并检查突触及氧化应激候选基因；同时对GSE168973重新按RiboTag细胞类型分层。研究目的是形成可复核的候选分子框架，为后续脉冲噪声动物实验提供假设，而非替代目标噪声模型的直接实验验证。")

doc.add_heading("2 材料与方法",1)
doc.add_heading("2.1 数据来源与纳入原则",2)
body("GSE168041包含小鼠耳蜗神经组织和外侧壁的10x单细胞RNA测序处理矩阵，设置未暴露对照及噪声暴露组，每种组织每组4个样本；公开样本注释显示噪声为105 dB SPL、8–16 kHz宽带噪声、持续2 h，组织于暴露后24 h采集[1,6]。该模型为强声学创伤模型，不是脉冲噪声模型。")
body("GSE168973提供PrestinCreERT2;RiboTag与Sox2CreERT2;RiboTag小鼠的IP及input TPM矩阵，噪声暴露为105 dB SPL、2 h，采样时间为6 h或24 h；另有未暴露对照样本。所有比较在细胞类型、分级及时间点内进行[1,7]。GSE167078为CD45阳性耳蜗免疫细胞数据，处理组细胞由多个动物混合后进入单个10x文库；由于每个条件缺少独立文库重复，未用于组间差异推断[1,8]。")
table(["数据集","材料/设计","本稿用途"],[
 ["GSE168041","神经组织、外侧壁；10x单细胞；每组织每组n=4","主要单细胞质控、聚类、样本级pseudobulk"],
 ["GSE168973","Prestin/Sox2 RiboTag；IP与input；6 h/24 h及未暴露对照","按细胞类型重分组的探索性差异分析"],
 ["GSE167078","CD45+免疫细胞；多个动物混合至单个文库","设计评估；不作处理组差异检验"]])
caption("表1 | 公开数据集及其在本研究中的分析用途。")

doc.add_heading("2.2 单细胞质控、归一化与聚类",2)
body("GSE168041各样本矩阵分别读取后按组织整合。细胞保留阈值为检测基因数≥200、总UMI≥500、线粒体转录本比例<20%。过滤后按每细胞总计数归一化至10,000并进行log1p转换；按样本批次识别2,000个高变基因，计算30个主成分，基于15个近邻构建邻居图，以Leiden分辨率0.5聚类并用UMAP展示[10]。细胞群依据经典标记基因的表达作宽泛、暂定注释；未以单一标记作为细胞身份的充分证据。")
doc.add_heading("2.3 样本级pseudobulk差异表达",2)
body("每个组织内将质控后细胞的原始UMI计数按动物样本汇总至基因层面，以样本作为独立统计单位，使用PyDESeq2实现DESeq2负二项模型，设计式为~condition，对比noise与naive[9]。采用Wald检验及Benjamini–Hochberg方法校正，FDR<0.05定义为差异表达；未设额外log2FC阈值。整体组织差异可能同时反映细胞内表达变化和细胞比例变化。")
doc.add_heading("2.4 GSE168973探索性重分析",2)
body("TPM按基因符号汇总后转换为log2(TPM+1)。分别在Prestin富集与Sox2富集样本、IP/input分级及6 h/24 h时间点内，以各自未暴露对照为参照进行Welch t检验，并在每项比较的全基因范围内进行BH校正。该分析基于公开TPM而非原始计数，且部分比较每组仅2–3个样本，故定位为探索性分析。")
doc.add_heading("2.5 软件与统计",2)
body("单细胞处理使用Scanpy/AnnData，差异表达使用PyDESeq2，矩阵处理与统计汇总使用Python、SciPy、pandas及statsmodels。正式投稿前需在锁定环境中补录全部软件版本、运行环境文件和代码提交号。")
doc.add_heading("2.6 通路富集与预排序GSEA",2)
body("对GSE168041 pseudobulk差异表达结果分别按上调和下调基因进行过度代表分析（ORA），基因背景限定为该组织中baseMean>0的可检测基因。GO Biological Process、KEGG及Reactome基因集分别采用Fisher精确检验并在每个组织、方向和数据库范围内进行BH校正，FDR<0.05视为显著。另以DESeq2 Wald统计量对全部可检测基因排序，使用MSigDB Hallmark 2020进行预排序GSEA（1,000次置换），并以BH校正的FDR<0.05判定显著[11,12]。置换分辨率导致的数值0按FDR<0.001报告，不解释为真实概率为零。基因集版本、下载与分析参数记录于补充结果文件。")

doc.add_heading("3 结果",1)
doc.add_heading("3.1 单细胞质控与样本保留",2)
qc=[]
for tissue,label in [("Neurons","神经组织"),("Stria","外侧壁")]:
 d=pd.read_csv(RES/f"GSE168041_{tissue}_cell_qc.csv")
 for cond,cname in [("naive","未暴露"),("noise","噪声暴露")]:
  s=d[d.condition==cond]; qc.append([label,cname,"4",f"{int(s.cells_before.sum()):,}",f"{int(s.cells_after.sum()):,}",f"{100*s.cells_after.sum()/s.cells_before.sum():.1f}%"])
table(["组织","组别","样本数","质控前细胞","质控后细胞","保留比例"],qc)
caption("表2 | GSE168041单细胞矩阵的样本级质控汇总。保留阈值：检测基因数≥200、总UMI≥500、线粒体比例<20%。")
body("神经组织质控后保留32,440个细胞（原始34,776个，保留率93.3%）；外侧壁保留32,151个细胞（原始36,967个，保留率87.0%）。各样本均保留细胞，未按处理组别选择性删样。")
doc.add_heading("3.2 细胞聚类及标记基因支持的暂定注释",2)
body("神经组织整合矩阵识别出26个转录簇，外侧壁识别出22个转录簇。神经组织可见Nefh、Snap25、Syt2等神经元标记簇，以及Mpz/Plp1阳性胶质样簇、C1qa/Lyz2阳性免疫样簇、Pecam1/Cldn5阳性血管样簇和Col1a1/Dcn阳性间质样簇。外侧壁可见Dct/Tyr阳性色素/黑色素细胞样群、Kcnj10/Slc12a2相关离子转运上皮样群、Pecam1/Cldn5阳性血管群及C1qa/Lyz2阳性免疫样群。上述标注是基于当前聚类marker的宽泛注释，仍需与原始研究注释或独立标记核对。")
fig(FIG/"GSE168041_Neurons_UMAP.png","图1 | GSE168041神经组织细胞的UMAP。左：按处理组着色；右：按Leiden簇着色。细胞数为质控后32,440；点代表细胞，UMAP用于可视化，不作为独立统计重复。")
fig(FIG/"GSE168041_Stria_UMAP.png","图2 | GSE168041耳蜗外侧壁细胞的UMAP。左：按处理组着色；右：按Leiden簇着色。细胞数为质控后32,151；点代表细胞，UMAP用于可视化，不作为独立统计重复。")
fig(FIG/"GSE168041_Neurons_marker_dotplot.png","图3 | 神经组织聚类的标记基因表达。点大小表示表达该基因的细胞比例，颜色表示按基因标准化后的平均表达；簇级身份为暂定注释。")
fig(FIG/"GSE168041_Stria_marker_dotplot.png","图4 | 外侧壁聚类的标记基因表达。点大小表示表达该基因的细胞比例，颜色表示按基因标准化后的平均表达；簇级身份为暂定注释。")

doc.add_heading("3.3 样本级pseudobulk差异表达",2)
summary=[]
for t,label in [("Neurons","神经组织"),("Stria","外侧壁")]:
 d=pd.read_csv(RES/f"GSE168041_{t}_pseudobulk_deseq2.csv").dropna(subset=["padj"])
 n=int((d.padj<.05).sum()); up=int(((d.padj<.05)&(d.log2FoldChange>0)).sum()); down=int(((d.padj<.05)&(d.log2FoldChange<0)).sum())
 summary.append([label,"4 vs 4",f"{n:,}",f"{up:,}",f"{down:,}"])
table(["组织","噪声/对照样本数","FDR<0.05基因","上调","下调"],summary)
caption("表3 | GSE168041样本级pseudobulk差异表达结果。样本而非细胞作为统计单位；按BH校正后FDR<0.05计数。")
body("神经组织检出3,152个FDR<0.05基因（1,804个上调、1,348个下调）；外侧壁检出3,103个（1,583个上调、1,520个下调）。神经组织显著基因包括Ccl8、Col16a1、Tgfbi、Chac1与Vgf；外侧壁包括Cst6、Vim、Lgals1、Lgals3与Timp1。整体组织pseudobulk差异可能由转录状态变化、细胞比例变化或两者共同造成。")
doc.add_heading("3.4 突触与氧化还原候选基因呈组织差异",2)
selected={"Neurons":["Snap25","Syt2","Syn1","Synj1","Dnm1","Gpx1","Gpx2","Gpx4","Gclc","Hmox1","Prdx1","Sod1"],"Stria":["Gpx1","Gpx3","Gpx4","Sod1","Snap25","Synj1","Dnm1","Hmox1"]}
rows=[]
for t,label in [("Neurons","神经组织"),("Stria","外侧壁")]:
 d=pd.read_csv(RES/f"GSE168041_{t}_pseudobulk_deseq2.csv")
 for gene in selected[t]:
  r=d[d.gene==gene]
  if len(r):
   r=r.iloc[0]; rows.append([label,gene,f"{r.log2FoldChange:.3f}",f"{r.padj:.3g}" if pd.notna(r.padj) else "NA"])
table(["组织","候选基因","log2FC","FDR"],rows)
caption("表4 | 预设突触与氧化应激候选基因的pseudobulk结果。log2FC>0表示噪声组表达较高；NA表示校正值不可估计。")
body("神经组织中Snap25（log2FC=-0.327，FDR=0.037）、Syt2（-0.304，FDR=0.037）、Syn1（0.320，FDR=0.038）及Synj1（-0.266，FDR=0.035）达到FDR阈值，方向并不一致。氧化还原候选基因中Gpx2、Gpx4、Gpx1、Hmox1和Prdx1上调，Gclc下调；Sod1未达到FDR阈值。外侧壁中Gpx1上调（log2FC=0.717，FDR=3.78×10^-7），Gpx3下调（-0.570，FDR=0.0105）；Snap25、Synj1与Sod1未达到FDR阈值。")
fig(FIG/"GSE168041_pseudobulk_volcano.png","图5 | GSE168041样本级pseudobulk差异表达。每个组织噪声组与未暴露组各n=4个生物学样本；点为基因，横线为FDR=0.05。标注代表性候选基因；为改善可读性，-log10(FDR)>15的点在图中截断，完整统计量见结果表。")
doc.add_heading("3.5 通路富集提示神经突起与突触相关表达程序下调",2)
ora=pd.read_csv(RES/"GSE168041_pathway_ORA.csv")
gsea=pd.read_csv(RES/"GSE168041_pathway_GSEA.csv")
ora_terms=[("Neurons","down","GO_Biological_Process_2025","Axonogenesis (GO:0007409)"),
 ("Neurons","down","GO_Biological_Process_2025","Regulation of Synapse Assembly (GO:0051963)"),
 ("Neurons","down","Reactome_Pathways_2024","Protein-protein Interactions at Synapses"),
 ("Neurons","down","Reactome_Pathways_2024","Transmission Across Chemical Synapses"),
 ("Neurons","down","KEGG_2026","AXON GUIDANCE")]
orows=[]
for tissue,direction,lib,term in ora_terms:
 r=ora[(ora.tissue==tissue)&(ora.direction==direction)&(ora.library==lib)&(ora.Term==term)]
 if len(r):
  x=r.iloc[0]; orows.append([x.library.replace("GO_Biological_Process_2025","GO-BP").replace("Reactome_Pathways_2024","Reactome").replace("KEGG_2026","KEGG"),x.Term,x.Overlap,f"{x['Adjusted P-value']:.2g}"])
table(["数据库","下调基因富集条目","重叠基因/通路基因","FDR"],orows)
caption("表6 | 神经组织下调基因中代表性突触/轴突ORA条目。完整GO、KEGG及Reactome结果见补充结果文件。")
gsea_terms=[("Neurons","Reactive Oxygen Species Pathway"),("Neurons","Unfolded Protein Response"),("Neurons","Interferon Gamma Response"),("Neurons","TNF-alpha Signaling via NF-kB"),("Stria","Reactive Oxygen Species Pathway"),("Stria","Oxidative Phosphorylation"),("Stria","Interferon Alpha Response"),("Stria","Interferon Gamma Response")]
grows=[]
for tissue,term in gsea_terms:
 r=gsea[(gsea.tissue==tissue)&(gsea.Term==term)]
 if len(r):
  x=r.iloc[0]; q=float(x['FDR q-val']); grows.append(["神经组织" if tissue=="Neurons" else "外侧壁",term,f"{x.NES:.2f}","<0.001" if q==0 else f"{q:.3g}"])
table(["组织","Hallmark通路","NES","FDR"],grows)
caption("表7 | 预设相关Hallmark GSEA结果。ROS通路在两组织中均未达到FDR<0.05；NES正负分别表示基因集偏向排序前端或后端。")
body("ORA显示神经组织下调基因显著富集于轴突发生、轴突导向、突触组装调控及化学突触传递等条目（例如GO轴突发生FDR=1.17×10^-7，突触组装调控FDR=2.38×10^-4；Reactome突触蛋白互作FDR=8.53×10^-4）。相反方向的神经组织上调条目主要集中于翻译、核糖体及蛋白质加工；外侧壁上调条目也以翻译和干扰素相关信号为主。Hallmark GSEA显示神经组织未折叠蛋白反应及炎症/干扰素相关集合正向富集；外侧壁干扰素集合正向富集，而氧化磷酸化集合负向富集。两组织的Hallmark Reactive Oxygen Species Pathway均未达到FDR<0.05（神经组织FDR=0.154；外侧壁FDR=0.273），因此全基因集层面的GSEA不支持将ROS通路描述为显著富集。")
doc.add_heading("3.6 GSE168973分层后未复现大规模候选差异",2)
gd=pd.read_csv(RES/"GSE168973_DEG_summary_stratified.csv"); rows=[]
for _,r in gd.iterrows(): rows.append(["外毛细胞富集" if r.cell_type=="OHC_enriched" else "支持细胞富集",r.time,r.fraction,f"{int(r.n_noise)}/{int(r.n_control)}",int(r.sig_genes)])
table(["RiboTag类型","暴露后时间","分级","噪声/对照n","FDR<0.05基因"],rows)
caption("表5 | GSE168973按细胞类型、时间点与分级重做的探索性比较。采用log2(TPM+1)及Welch检验；每项比较单独进行BH校正。")
body("按Prestin（外毛细胞富集）与Sox2（支持细胞富集）分别比较后，8项比较中预设突触或氧化应激候选基因均未达到FDR<0.05。全基因范围内仅有单个比较出现一个非候选基因达到阈值。早期未分层分析中出现的101/13个差异基因不再作为结果引用；该比较混合了细胞类型，不能解释为噪声处理效应。")

doc.add_heading("4 讨论",1)
body("本研究以GSE168041的样本级pseudobulk分析为主要证据。神经组织下调基因在GO、KEGG与Reactome中一致指向轴突/神经突起及突触相关过程，为突触相关转录改变提供了比单基因列表更系统的支持。多个突触候选基因达到统计阈值，但方向并不一致，故不能概括为突触功能基因普遍下调。氧化还原候选基因呈现谷胱甘肽合成、过氧化物清除及应激响应相关的不同方向变化；然而Hallmark ROS集合在GSEA中未显著富集，提示基因层面的候选信号尚未形成一致的全通路证据。外侧壁中Gpx1与Gpx3方向相反，也不支持以单一“氧化应激增强”标签概括组织转录状态。")
body("这一结果与既往关于噪声性听力损伤中氧化还原稳态、突触退变和神经纤维改变的研究方向相符[2–5]，但转录组证据不能证明氧化应激在时间或因果上先于突触损伤。GSE168041神经样本并非纯化的螺旋神经节神经元；整体组织pseudobulk变化可能由转录状态变化、细胞比例变化或两者共同造成。下一步应在神经元/支持细胞等分群中按样本聚合计数，并以独立组织学和功能数据验证。")
body("GSE168973重新分层后的差异信号弱于早期快速分析，且候选基因未通过多重校正。该数据集样本量小，TPM上的逐基因Welch检验统计效能有限，故未复现不能视为不存在效应。其意义主要在于提示跨数据集整合必须依据GEO样本注释分开细胞类型与处理组，不能仅凭文件名前缀将其解释为噪声/对照。")
body("本研究外推范围受到模型差异限制。GSE168041使用高强度宽带声学创伤并在暴露后24 h取材，GSE168973亦为高强度噪声模型；二者并非原课题的脉冲噪声暴露或可逆性听阈改变模型。因此本文结论限定为公开数据支持的噪声性耳蜗损伤相关表达特征，不能声称解析了脉冲噪音致可逆性耳聋的分子机制。")
body("GSE167078每个条件仅有一个混合文库，即使单细胞数较多，也不能将细胞数视为独立生物学重复进行处理组推断。当前通路分析已完成，但仍需对原始基因集库、分析脚本与完整结果表作投稿归档；按细胞类型开展样本级pseudobulk复核，完成GSE167078 HTO标签核验和仅描述性注释，并由作者核实参考文献及全部声明。现有细胞注释为依据marker的暂定注释，且整体组织pseudobulk可能受细胞比例影响。缺少目标脉冲噪声模型的听阈、突触形态和氧化还原实验验证，是本研究对原申请主题外推的核心限制。")
doc.add_heading("5 结论",1)
body("公开单细胞转录组再分析显示，强声学噪声暴露后24 h的小鼠耳蜗神经组织与外侧壁出现组织依赖的转录变化，涉及突触相关基因及多种氧化还原应答基因。当前证据支持将突触功能和谷胱甘肽/过氧化物稳态作为后续验证方向，但不能据此建立因果机制，也不能直接外推至脉冲噪声或可逆性耳聋。")

doc.add_heading("数据与声明",1)
doc.add_heading("数据可用性",2)
body("本研究使用公开数据：GSE168041（https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE168041）、GSE168973（https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE168973）及用于设计评估的GSE167078（https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE167078）。数据访问日期为2026年9月27日。")
doc.add_heading("代码可用性",2)
body("本地分析脚本包括GSE168973分层重分析、GSE168041单细胞处理、pseudobulk差异分析及图件生成脚本。公开代码仓库地址、固定版本号、依赖锁定文件及全部源数据表需在投稿前归档并补充。")
doc.add_heading("伦理、利益冲突与基金",2)
body("本研究未新增动物实验，仅再分析公开数据。利益冲突声明需由全部作者核实后确认。基金来源及项目编号需由作者据实补充；若无特定基金支持，应按目标期刊要求声明。")
doc.add_heading("AI辅助声明",2)
body("稿件结构整理、文字润色、分析脚本辅助及图表排版过程中使用了AI工具。数据解释、统计分析选择和最终稿件内容应由作者核验并承担责任；AI工具不列为作者。")
doc.add_heading("参考文献",1)
refs=[
"[1] Milon B, Shulman ED, So KS, et al. A cell-type-specific atlas of the inner ear transcriptional response to acoustic trauma. Cell Reports. 2021;36(13):109758. doi:10.1016/j.celrep.2021.109758.",
"[2] Kujawa SG, Liberman MC. Adding insult to injury: cochlear nerve degeneration after temporary noise-induced hearing loss. J Neurosci. 2009;29(45):14077-14085. doi:10.1523/JNEUROSCI.2845-09.2009.",
"[3] Liberman MC, Kujawa SG. Cochlear synaptopathy in acquired sensorineural hearing loss: manifestations and mechanisms. Hear Res. 2017;349:138-147. doi:10.1016/j.heares.2017.01.003.",
"[4] Henderson D, Bielefeld EC, Harris KC, Hu BH. The role of oxidative stress in noise-induced hearing loss. Ear Hear. 2006;27(1):1-19. doi:10.1097/01.aud.0000191942.36672.f3.",
"[5] Fetoni AR, Paciello F, Rolesi R, Paludetti G, Troiani D. Targeting dysregulation of redox homeostasis in noise-induced hearing loss: oxidative stress and ROS signaling. Free Radic Biol Med. 2019;135:46-59. doi:10.1016/j.freeradbiomed.2019.02.022.",
"[6] GEO Series GSE168041. Transcriptional profiling of cochlear spiral ganglion neurons and lateral wall cells. NCBI Gene Expression Omnibus. https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE168041.",
"[7] GEO Series GSE168973. A cell type-specific atlas of the inner ear transcriptional response to acoustic trauma. NCBI Gene Expression Omnibus. https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE168973.",
"[8] GEO Series GSE167078. CD45+ immune cells from mouse cochlea. NCBI Gene Expression Omnibus. https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE167078.",
"[9] Love MI, Huber W, Anders S. Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. Genome Biol. 2014;15:550. doi:10.1186/s13059-014-0550-8.",
"[10] Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol. 2018;19:15. doi:10.1186/s13059-017-1382-0.",
"[11] Subramanian A, Tamayo P, Mootha VK, et al. Gene set enrichment analysis: a knowledge-based approach for interpreting genome-wide expression profiles. Proc Natl Acad Sci U S A. 2005;102(43):15545-15550. doi:10.1073/pnas.0506580102.",
"[12] Liberzon A, Birger C, Thorvaldsdottir H, Ghandi M, Mesirov JP, Tamayo P. The Molecular Signatures Database (MSigDB) hallmark gene set collection. Cell Syst. 2015;1(6):417-425. doi:10.1016/j.cels.2015.12.004.",
]
for ref in refs:
 p=doc.add_paragraph(ref); p.paragraph_format.left_indent=Cm(.75); p.paragraph_format.first_line_indent=Cm(-.75); p.paragraph_format.space_after=Pt(3)
doc.core_properties.title="公开单细胞与RiboTag转录组揭示噪声性耳蜗损伤中的突触与氧化还原表达特征"
doc.core_properties.subject="公开转录组数据再分析中文修订稿"; doc.core_properties.author=""
doc.save(OUT)
print(OUT.resolve())
