from pathlib import Path
import sys
import importlib
import pandas as pd
import gseapy as gp
import gseapy.utils as gseapy_utils
import gseapy.parser as gseapy_parser
gseapy_enrichr=importlib.import_module("gseapy.enrichr")

RES=Path("work/geo_reanalysis/results")
LIBDIR=Path("work/geo_reanalysis/gene_sets")
LIBDIR.mkdir(parents=True,exist_ok=True)
cache=LIBDIR/"cache"; cache.mkdir(parents=True,exist_ok=True)
for module in [gseapy_utils,gseapy_parser,gseapy_enrichr]: module.DEFAULT_CACHE_PATH=str(cache)
LIBRARIES=["GO_Biological_Process_2025","KEGG_2026","Reactome_Pathways_2024"]
GSEA_LIBRARY="MSigDB_Hallmark_2020"
ora_rows=[]; gsea_rows=[]

for lib in LIBRARIES:
    print(f"Downloading gene-set library: {lib}",flush=True)
    pathways=gp.get_library(name=lib,organism="Mouse")
    if not pathways: raise RuntimeError(f"Empty library: {lib}")
    with (LIBDIR/f"{lib}.gmt").open("w",encoding="utf-8") as f:
        for term,genes in pathways.items(): f.write("\t".join([term,"GSEpy_Enrichr",*genes])+"\n")
    print(f"{lib}: {len(pathways)} gene sets",flush=True)
    for tissue in ["Neurons","Stria"]:
        d=pd.read_csv(RES/f"GSE168041_{tissue}_pseudobulk_deseq2.csv")
        background=d.loc[d.baseMean.fillna(0)>0,"gene"].dropna().astype(str).unique().tolist()
        tested=d.dropna(subset=["padj","log2FoldChange"])
        for direction,mask in [("up",tested.padj.lt(.05)&tested.log2FoldChange.gt(0)),("down",tested.padj.lt(.05)&tested.log2FoldChange.lt(0))]:
            genes=tested.loc[mask,"gene"].astype(str).unique().tolist()
            if not genes: continue
            enr=gp.enrichr(gene_list=genes,gene_sets=pathways,background=background,organism="mouse",outdir=None,cutoff=1.0,verbose=False)
            if enr.results is not None and len(enr.results):
                x=enr.results.copy(); x["tissue"]=tissue; x["direction"]=direction; x["library"]=lib; x["n_query"]=len(genes); x["n_background"]=len(background)
                ora_rows.append(x)
        print(f"Completed {tissue} | {lib}",flush=True)

print(f"Downloading GSEA library: {GSEA_LIBRARY}",flush=True)
hallmark=gp.get_library(name=GSEA_LIBRARY,organism="Mouse")
with (LIBDIR/f"{GSEA_LIBRARY}.gmt").open("w",encoding="utf-8") as f:
    for term,genes in hallmark.items(): f.write("\t".join([term,"GSEpy_Enrichr",*genes])+"\n")
for tissue in ["Neurons","Stria"]:
    d=pd.read_csv(RES/f"GSE168041_{tissue}_pseudobulk_deseq2.csv")
    rank=d.dropna(subset=["stat"])[["gene","stat"]].drop_duplicates("gene").copy()
    # Stable tie-breaking changes only the order of identical Wald statistics.
    rank["stat"] += rank.gene.rank(method="first").to_numpy()*1e-12
    rank=rank.sort_values("stat",ascending=False)
    pre=gp.prerank(rnk=rank,gene_sets=hallmark,min_size=10,max_size=500,permutation_num=1000,threads=1,seed=2026,outdir=None,verbose=False)
    if pre.res2d is not None and len(pre.res2d):
        x=pre.res2d.copy(); x["tissue"]=tissue; x["library"]=GSEA_LIBRARY; x["n_ranked_genes"]=len(rank)
        gsea_rows.append(x)
    print(f"Completed Hallmark GSEA | {tissue}",flush=True)

if ora_rows:
    pd.concat(ora_rows,ignore_index=True).to_csv(RES/"GSE168041_pathway_ORA.csv",index=False,encoding="utf-8-sig")
if gsea_rows:
    pd.concat(gsea_rows,ignore_index=True).to_csv(RES/"GSE168041_pathway_GSEA.csv",index=False,encoding="utf-8-sig")
    g=pd.concat(gsea_rows,ignore_index=True)
    for c in ["FDR q-val","FDR q-val "]:
        if c in g.columns: g[c]=pd.to_numeric(g[c],errors="coerce")
    g.to_csv(RES/"GSE168041_pathway_GSEA.csv",index=False,encoding="utf-8-sig")
pd.DataFrame([{"analysis":"ORA","libraries":";".join(LIBRARIES),"background":"genes with baseMean>0","FDR":"BH","analysis_date":"2026-09-28"},
              {"analysis":"GSEA","libraries":GSEA_LIBRARY,"background":"all ranked genes with non-NA Wald statistic","FDR":"BH","permutations":1000,"seed":2026,"analysis_date":"2026-09-28"}]).to_csv(RES/"GSE168041_enrichment_parameters.csv",index=False,encoding="utf-8-sig")
print("ORA rows",sum(map(len,ora_rows)),"GSEA rows",sum(map(len,gsea_rows)),flush=True)
