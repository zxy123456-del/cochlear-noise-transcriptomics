"""Independent reaggregation from GEO Matrix Market inputs and frozen annotations.

Run from the repository root. The raw archive can be downloaded with --download.
This verifies every saved pseudobulk count, not only summary dimensions.
"""
from pathlib import Path
import argparse, gzip, json, hashlib, tarfile
import numpy as np
import pandas as pd
from scipy import io
import requests

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--download',action='store_true');args=parser.parse_args()
    root=Path('work/geo_reanalysis/extracted/GSE168041')
    if not list(root.glob('*_matrix.mtx.gz')):
        if not args.download: raise SystemExit('Missing GEO matrices. Run again with --download (607 MB archive).')
        archive=Path('work/geo_reanalysis/raw/GSE168041_RAW.tar');archive.parent.mkdir(parents=True,exist_ok=True)
        if not archive.exists():
            url='https://ftp.ncbi.nlm.nih.gov/geo/series/GSE168nnn/GSE168041/suppl/GSE168041_RAW.tar'
            with requests.get(url,stream=True,timeout=120) as response:
                response.raise_for_status()
                with archive.open('wb') as handle:
                    for chunk in response.iter_content(1024*1024):handle.write(chunk)
        root.mkdir(parents=True,exist_ok=True)
        with tarfile.open(archive) as tf:tf.extractall(root,filter='data')
    out=Path('work/genes');checks=[]
    for tissue in ['Neurons','Stria']:
        obs=pd.read_csv(out/'celltypes'/f'{tissue}_annotated_cells.csv.gz',index_col=0)
        obs.cluster=obs.cluster.astype(int)
        matrices={p.stem.removesuffix('.csv').removesuffix('_counts'):pd.read_csv(p,index_col=0) for p in (out/'celltypes').glob(f'{tissue}_*_counts.csv.gz')}
        for path in sorted(root.glob(f'*MouseCochlea{tissue}_*_matrix.mtx.gz')):
            sid=path.name.split('_')[0];base=str(path).replace('_matrix.mtx.gz','')
            with gzip.open(path,'rb') as f:X=io.mmread(f).T.tocsr()
            genes=pd.read_csv(base+'_genes.tsv.gz',sep='\t',header=None).iloc[:,1].astype(str)
            barcodes=pd.read_csv(base+'_barcodes.tsv.gz',sep='\t',header=None).iloc[:,0].astype(str)
            barcodes=pd.Index([sid+'_'+b for b in barcodes])
            for prefix,expected in matrices.items():
                if sid not in expected.columns:continue
                label=prefix.removeprefix(tissue+'_').rsplit('_',1)[0]
                mode=prefix.rsplit('_',1)[1]
                if label in ['SGN_Calb2_high','SGN_Lypd1_high','SGN_mixed']:
                    selected=obs.cluster.eq({'SGN_Calb2_high':4,'SGN_Lypd1_high':5,'SGN_mixed':13}[label])
                else:selected=obs.cell_type.eq(label)
                selected &= obs['strict_keep' if mode=='strict' else 'primary_keep'] & obs['sample'].eq(sid)
                ids=barcodes.get_indexer(obs.index[selected]);assert (ids>=0).all()
                sums=np.asarray(X[ids].sum(axis=0)).ravel()
                observed=pd.Series(sums,index=genes).groupby(level=0).sum().reindex(expected.index,fill_value=0)
                difference=np.abs(observed.to_numpy()-expected[sid].to_numpy())
                checks.append({'analysis':prefix,'sample':sid,'cells':len(ids),'genes':len(expected),'max_absolute_difference':float(difference.max()),'pass':bool((difference==0).all())})
            print('VERIFIED',sid,flush=True)
    df=pd.DataFrame(checks);df.to_csv(out/'raw_reaggregation_verification.csv',index=False)
    if not df['pass'].all():raise AssertionError('Raw count reaggregation mismatch')
    print('PASS',len(df),'sample-by-stratum count matrices',flush=True)

if __name__=='__main__':main()
