from pathlib import Path
import subprocess,sys,json
root=Path.home()/'.codex/skills/nature-figure/scripts'
qa=Path('work/genes/qa')
for p in sorted(Path('work/genes/figures').glob('*.pdf')):
    a=subprocess.run([sys.executable,'-X','utf8',str(root/'audit_figure_collisions.py'),str(p),'--json-out',str(qa/f'{p.stem}_collisions.json')],capture_output=True)
    b=subprocess.run([sys.executable,'-X','utf8',str(root/'audit_pdf_text.py'),str(p),'--min-pt','5','--json'],capture_output=True)
    (qa/f'{p.stem}_pdf_text.json').write_bytes(b.stdout)
    print(p.stem,'collision',a.returncode,'font',b.returncode,flush=True)
    if a.returncode or b.returncode:print(a.stdout.decode('utf8'),b.stdout.decode('utf8'))
