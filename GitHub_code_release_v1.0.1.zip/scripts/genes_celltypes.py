"""Animal-level cell-type pseudobulk analysis with explicit sample eligibility."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR',str(Path('work/mplconfig').resolve()))
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import sys, json
import numpy as np
import pandas as pd
import scanpy as sc
from pydeseq2.dds import DeseqDataSet
from pydeseq2.ds import DeseqStats
from scipy import sparse

ROOT=Path('work/genes')
OUT=ROOT/'celltypes'
OUT.mkdir(exist_ok=True)
MAP={
 'Neurons': {
  'SGN':[4,5,7,13], 'Glia':[3,10,23], 'Myeloid':[1,6],
  'Endothelial':[16], 'Stromal':[9,11,12,15,19,20],
  'Epithelial':[0,2,8,14,21,22], 'Mural':[18], 'Erythroid':[17],
  'Melanocyte_like':[25], 'Mixed_unassigned':[24]},
 'Stria': {
  'Intermediate_like':[0,1,2], 'Endothelial':[3], 'Epithelial':[7,13,19,21],
  'Stromal':[5,14,15,18,20], 'Marginal_like':[6,10], 'Basal_like':[4],
  'Myeloid':[9,17], 'Mural':[11], 'Erythroid':[12], 'Mixed_unassigned':[8,16]}
}

def differential(counts, meta, prefix):
    keep=(counts>=10).sum(axis=1)>=3
    counts=counts.loc[keep]
    print('DE',prefix,len(counts),meta.condition.value_counts().to_dict(),flush=True)
    dds=DeseqDataSet(counts=counts.T, metadata=meta, design='~condition',
                     refit_cooks=True,n_cpus=1,quiet=True,low_memory=True)
    dds.deseq2()
    stat=DeseqStats(dds,contrast=['condition','noise','naive'],n_cpus=1,
                    independent_filter=False,quiet=True,alpha=.05)
    stat.summary()
    res=stat.results_df.copy()
    res.index.name='gene'
    res['CI_low']=res.log2FoldChange-1.96*res.lfcSE
    res['CI_high']=res.log2FoldChange+1.96*res.lfcSE
    norm=pd.DataFrame(dds.layers['normed_counts'].T,index=counts.index,columns=counts.columns)
    # Effect-direction sensitivity only; omitted-sample estimates are not new P values.
    directions=[]
    noise=meta.condition.eq('noise')
    for omit in meta.index:
        a=norm.loc[:,meta.index[noise & (meta.index!=omit)]].mean(axis=1)
        b=norm.loc[:,meta.index[~noise & (meta.index!=omit)]].mean(axis=1)
        directions.append(np.sign(np.log2((a+1)/(b+1))).to_numpy())
    res['leave_one_out_direction_fraction']=(np.array(directions)==np.sign(res.log2FoldChange.to_numpy())[None,:]).mean(axis=0)
    res.to_csv(OUT/f'{prefix}_DE.csv')
    norm.to_csv(OUT/f'{prefix}_normalized.csv.gz')
    return res

def run(tissue):
    ad=sc.read_h5ad(f'work/geo_reanalysis/results/GSE168041_{tissue}_processed.h5ad')
    obs=pd.read_csv(ROOT/f'{tissue}_cells.csv.gz',index_col=0)
    assert list(ad.obs_names)==list(obs.index)
    obs['cluster']=obs.cluster.astype(int)
    cmap={int(c):k for k,cs in MAP[tissue].items() for c in cs}
    obs['cell_type']=obs.cluster.map(cmap)
    assert obs.cell_type.notna().all()
    obs.to_csv(OUT/f'{tissue}_annotated_cells.csv.gz')
    syms=ad.raw.var.gene_symbol.astype(str)
    genes=pd.Index(sorted(syms.unique()),name='gene')
    mapping=sparse.csr_matrix((np.ones(len(syms)),(np.arange(len(syms)),genes.get_indexer(syms))),shape=(len(syms),len(genes)))
    X=ad.raw.X
    subsets={k:obs.cell_type.eq(k).to_numpy() for k in MAP[tissue]}
    if tissue=='Neurons':
        for label,cluster in [('SGN_Calb2_high',4),('SGN_Lypd1_high',5),('SGN_mixed',13)]:
            subsets[label]=obs.cluster.eq(cluster).to_numpy()
    summaries=[]
    for label,subset in subsets.items():
        if label in ['Erythroid','Mixed_unassigned','Unassigned','Melanocyte_like']:
            continue
        modes=['strict']
        if label in ['SGN','Glia']:
            modes.append('liberal')
        for mode in modes:
            prefix=f'{tissue}_{label}_{mode}'
            included=subset & obs['strict_keep' if mode=='strict' else 'primary_keep'].to_numpy()
            arrays=[]; metadata=[]
            for sid in obs['sample'].unique():
                mask=included & obs['sample'].eq(sid).to_numpy()
                n=int(mask.sum())
                if n<25:
                    continue
                sums=np.asarray(X[mask].sum(axis=0)) @ mapping
                arrays.append(np.asarray(sums).ravel())
                metadata.append({'sample':sid,'condition':obs.loc[mask,'condition'].iloc[0],'cells':n})
            if not metadata:
                continue
            meta=pd.DataFrame(metadata).set_index('sample')
            counts=pd.DataFrame(np.array(arrays,dtype=np.int64).T,index=genes,columns=meta.index)
            counts.to_csv(OUT/f'{prefix}_counts.csv.gz')
            meta.to_csv(OUT/f'{prefix}_metadata.csv')
            n=meta.condition.value_counts()
            eligible=min(n.get('noise',0),n.get('naive',0))>=3
            record={'analysis':prefix,'tissue':tissue,'cell_type':label,'QC':mode,'n_naive':int(n.get('naive',0)),'n_noise':int(n.get('noise',0)),'cells':int(meta.cells.sum()),'eligible':bool(eligible)}
            if eligible:
                output=OUT/f'{prefix}_DE.csv'
                res=pd.read_csv(output,index_col=0) if output.exists() else differential(counts,meta,prefix)
                sig=res.padj.lt(.05)
                record.update(tested=int(res.pvalue.notna().sum()),DEG=int(sig.sum()),up=int((sig & res.log2FoldChange.gt(0)).sum()),down=int((sig & res.log2FoldChange.lt(0)).sum()))
            summaries.append(record)
            pd.DataFrame(summaries).to_csv(OUT/f'{tissue}_summary.csv',index=False)
    print('DONE',tissue,flush=True)

if __name__=='__main__':
    for tissue in sys.argv[1:] or ['Neurons','Stria']:
        run(tissue)
