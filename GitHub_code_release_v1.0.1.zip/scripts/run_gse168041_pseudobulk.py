from pathlib import Path
import numpy as np
import pandas as pd
import scanpy as sc

RES = Path("work/geo_reanalysis/results")


def main(tissue):
    ad = sc.read_h5ad(RES / f"GSE168041_{tissue}_processed.h5ad")
    raw = ad.raw.to_adata()
    sample_ids = list(pd.unique(raw.obs["sample"]))
    symbols = raw.var["gene_symbol"].astype(str).values
    symbol_order = pd.Index(pd.unique(symbols))
    bulk = []
    for sid in sample_ids:
        rows = np.flatnonzero(raw.obs["sample"].to_numpy() == sid)
        sums = np.asarray(raw.X[rows].sum(axis=0)).ravel()
        temp = pd.DataFrame({"gene": symbols, "count": sums}).groupby("gene", sort=False)["count"].sum()
        bulk.append(temp.reindex(symbol_order, fill_value=0).to_numpy())
    counts = pd.DataFrame(np.asarray(bulk, dtype=np.int64).T, index=symbol_order, columns=sample_ids)
    counts.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_counts.csv", encoding="utf-8-sig")
    meta = raw.obs.drop_duplicates("sample").set_index("sample")[["condition", "replicate"]].loc[sample_ids].copy()
    meta["condition"] = pd.Categorical(meta["condition"], categories=["naive", "noise"])
    meta.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_metadata.csv", encoding="utf-8-sig")
    from pydeseq2.dds import DeseqDataSet
    from pydeseq2.ds import DeseqStats
    dds = DeseqDataSet(counts=counts.T, metadata=meta, design="~condition", refit_cooks=True, n_cpus=1)
    dds.deseq2()
    result = DeseqStats(dds, contrast=("condition", "noise", "naive"), n_cpus=1)
    result.summary()
    out = result.results_df.reset_index().rename(columns={"index": "gene"})
    out.to_csv(RES / f"GSE168041_{tissue}_pseudobulk_deseq2.csv", index=False, encoding="utf-8-sig")
    print(tissue, "samples", len(sample_ids), "genes", len(out), "FDR<0.05", int((out.padj < .05).sum()), flush=True)
    print(out.nsmallest(15, "padj")[["gene", "log2FoldChange", "pvalue", "padj"]].to_string(index=False), flush=True)


if __name__ == "__main__":
    import sys
    for tissue_name in sys.argv[1:]:
        main(tissue_name)
