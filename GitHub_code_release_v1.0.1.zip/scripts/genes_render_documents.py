"""Invoke the packaged DOCX renderer with the installed Windows LibreOffice."""
from pathlib import Path
import os,runpy,sys
name=sys.argv[1]
runtime=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies'
os.environ['PATH']=os.pathsep.join([r'C:\Program Files\LibreOffice\program',str(runtime/'native/poppler/Library/bin'),os.environ['PATH']])
renderer=Path.home()/'.codex/plugins/cache/openai-primary-runtime/documents/26.923.10815/skills/documents/render_docx.py'
sys.argv=[str(renderer),str(Path('outputs')/name),'--output_dir',str(Path('work/genes_docx_qa')/Path(name).stem),'--emit_pdf']
runpy.run_path(str(renderer),run_name='__main__')
