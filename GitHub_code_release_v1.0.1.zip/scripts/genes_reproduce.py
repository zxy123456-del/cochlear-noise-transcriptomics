"""Portable reanalysis from supplied integer pseudobulk counts.

Never modifies the distributed results: copies the package into a new run root.
Use --smoke for the principal SGN model only. The full rerun is computationally
intensive and includes all 19 eligible primary/sensitivity DE models.
"""
from pathlib import Path
import argparse, os, shutil, subprocess, sys, json

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    source=Path(__file__).resolve().parents[2]
    target=args.output.resolve()
    if target.exists(): raise FileExistsError('Use a new output directory to preserve prior results')
    shutil.copytree(source/'work/genes',target/'work/genes',ignore=shutil.ignore_patterns('qa','figures'))
    shutil.copytree(source/'work/revision/sources',target/'work/revision/sources')
    os.chdir(target)
    import pandas as pd
    import genes_celltypes as ct
    summaries=pd.concat([pd.read_csv(ct.OUT/f'{t}_summary.csv') for t in ['Neurons','Stria']])
    if args.smoke: summaries=summaries[summaries.analysis.eq('Neurons_SGN_strict')]
    checks=[]
    for row in summaries.itertuples():
        if not row.eligible:continue
        name=row.analysis
        counts=pd.read_csv(ct.OUT/f'{name}_counts.csv.gz',index_col=0)
        meta=pd.read_csv(ct.OUT/f'{name}_metadata.csv',index_col=0)
        expected=pd.read_csv(ct.OUT/f'{name}_DE.csv',index_col=0)
        result=ct.differential(counts,meta,name)
        delta=(result.log2FoldChange-expected.log2FoldChange).abs().max()
        checks.append({'analysis':name,'max_log2FC_difference':float(delta),'same_genes':list(result.index)==list(expected.index)})
    (target/'rerun_checks.json').write_text(json.dumps(checks,indent=2))
    if not args.smoke:
        # Remove only derived enrichment caches in this new, isolated rerun folder.
        for pattern in ['*_ORA.csv.gz','*_GSEA.csv']:
            for p in (target/'work/genes/enrichment').glob(pattern):p.unlink()
        for script in ['genes_external.py','genes_enrichment.py','genes_figures.py']:
            subprocess.run([sys.executable,'-X','utf8',str(source/'work/scripts'/script)],check=True)
    print('Completed in',target,flush=True)

if __name__=='__main__':main()
