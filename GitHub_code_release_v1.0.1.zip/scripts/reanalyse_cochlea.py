"""Reanalysis v3. Run from the workspace root; original inputs are read-only."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS']:
    os.environ[k]='2'
from pathlib import Path
import json, gzip, gc, re, warnings
import numpy as np
import pandas as pd
from scipy import io, sparse, stats
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
threadpool_limits(2)
ROOT=Path('work/revision'); SRC=ROOT/'sources'; RES=ROOT/'results'; CACHE=ROOT/'cache'
for p in [RES,CACHE]: p.mkdir(parents=True,exist_ok=True)
EXT=Path('work/geo_reanalysis/extracted')
SEED=20260928

MARKERS={
 'SGN':['Tubb3','Nefl','Nefm','Snap25','Rbfox3'],
 'Schwann':['Mpz','Pmp22','Plp1','Sox10','Mbp'],
 'Satellite_glia':['Fabp7','Glul','Kcnj10','Sox10'],
 'Fibrocyte':['Coch','Col1a1','Col1a2','Dcn','Lum'],
 'Endothelial':['Pecam1','Cldn5','Kdr','Esam','Emcn'],
 'Pericyte':['Rgs5','Pdgfrb','Des','Acta2','Cspg4'],
 'Myeloid':['Csf1r','Lyz2','Aif1','C1qa','Tyrobp'],
 'T_NK':['Cd3d','Cd3e','Trbc2','Nkg7'],
 'B_cell':['Cd79a','Ms4a1','Cd79b'],
 'Marginal':['Kcnq1','Kcne1','Slc12a2','Bsnd'],
 'Intermediate':['Dct','Tyr','Tyrp1','Mitf'],
 'Basal':['Cldn11','Krt8','Krt18','Tjp1'],
 'Epithelial':['Epcam','Krt19','Krt7','Krt14'],
 'Hair_cell':['Myo7a','Pou4f3','Otof','Slc26a5'],
 'Neutrophil':['S100a8','S100a9','Retnlg','Ly6g'],
}

def bulk():
    rows=[]; matrices=[]
    for m in json.loads((SRC/'GSE168973_samples.json').read_text(encoding='utf-8')):
        p=next((EXT/'GSE168973').glob(m['gsm']+'*.gz'))
        d=pd.read_csv(p,sep='\t'); col=d.columns[-1]
        d['gene']=d['gene.symbol'].fillna(d['ensemble_ID'])
        # Sum gene-level abundances when more than one stable ID shares a symbol.
        matrices.append(d.groupby('gene')[col].sum().rename(m['gsm']))
        treatment=m['treatment']; condition='control' if treatment=='None' else m['time point'].split()[0]
        genotype='Prestin' if 'Prestin' in m['genotype'] else 'Sox2'
        rows.append({'sample':m['gsm'],'title':m['title'],'genotype':genotype,'condition':condition,
                     'fraction':m['title'].rsplit('_',1)[1],'age_weeks':10,'treatment':treatment,
                     'cell_type':m['cell type'],'biological_unit':m['title'].rsplit('_',1)[0]})
    meta=pd.DataFrame(rows).set_index('sample'); expr=pd.concat(matrices,axis=1).fillna(0)
    meta.to_csv(RES/'bulk_metadata_verified.csv'); expr.to_csv(RES/'bulk_TPM.csv.gz',compression='gzip')
    summaries=[]; all_de=[]
    for genotype in ['Prestin','Sox2']:
        for fraction in ['IP','input']:
            for time in ['6h','24h']:
                sub=meta[(meta.genotype==genotype)&(meta.fraction==fraction)&meta.condition.isin(['control',time])]
                xcols=sub.index[sub.condition==time]; ncols=sub.index[sub.condition=='control']
                keep=(expr[sub.index]>=1).sum(axis=1)>=min(len(xcols),len(ncols))
                log=np.log2(expr.loc[keep]+1); x=log[xcols].to_numpy(); n=log[ncols].to_numpy()
                test=stats.ttest_ind(x,n,axis=1,equal_var=False)
                p=np.nan_to_num(test.pvalue,nan=1.0); delta=x.mean(1)-n.mean(1)
                se=np.sqrt(x.var(1,ddof=1)/len(xcols)+n.var(1,ddof=1)/len(ncols))
                ci=stats.t.ppf(.975,test.df)*se
                de=pd.DataFrame({'gene':log.index,'contrast':f'{genotype}_{fraction}_{time}_vs_control',
                    'delta_log2TPM':delta,'stat':np.nan_to_num(test.statistic), 'pvalue':p,
                    'padj':multipletests(p,method='fdr_bh')[1], 'ci_low':delta-ci,'ci_high':delta+ci,
                    'n_noise':len(xcols),'n_control':len(ncols)})
                de['significant']=(de.padj<.05)&(de.delta_log2TPM.abs()>=np.log2(1.5))
                all_de.append(de)
                summaries.append({'contrast':de.contrast.iloc[0],'n_noise':len(xcols),'n_control':len(ncols),
                    'tested':len(de),'up':int(((de.significant)&(de.delta_log2TPM>0)).sum()),
                    'down':int(((de.significant)&(de.delta_log2TPM<0)).sum())})
    de=pd.concat(all_de,ignore_index=True); de['global_padj']=multipletests(de.pvalue,method='fdr_bh')[1]
    de.to_csv(RES/'bulk_DE_corrected.csv.gz',index=False,compression='gzip')
    pd.DataFrame(summaries).to_csv(RES/'bulk_DE_summary.csv',index=False)
    print('BULK COMPLETE',summaries,flush=True)

def read_sample(folder,prefix,feature_suffix='genes'):
    with gzip.open(folder/(prefix+'_matrix.mtx.gz'),'rb') as f:
        x=io.mmread(f).T.tocsr().astype(np.float32)
    f=pd.read_csv(folder/(prefix+'_'+feature_suffix+'.tsv.gz'),sep='\t',header=None)
    b=pd.read_csv(folder/(prefix+'_barcodes.tsv.gz'),sep='\t',header=None)[0].astype(str)
    return x,f,b

def sc_stage(tissue):
    import anndata as ad
    import scanpy as sc
    sc.settings.n_jobs=2
    qcs=[]; blocks=[]
    if tissue=='Immune':
        specs=[('GSM5092462','GSM5092462_RNA','pooled','GSE167078','features')]
    else:
        specs=[]
        for m in json.loads((SRC/'GSE168041_samples.json').read_text(encoding='utf-8')):
            is_neuron='neurons' in m['title']
            if (tissue=='Neurons')!=is_neuron: continue
            p=next((EXT/'GSE168041').glob(m['gsm']+'*matrix.mtx.gz'))
            specs.append((m['gsm'],p.name.removesuffix('_matrix.mtx.gz'),
                          'control' if m['treatment']=='None' else 'noise','GSE168041','genes'))
    for gsm,prefix,condition,ds,suffix in specs:
        print('LOAD',tissue,gsm,flush=True)
        x,features,barcodes=read_sample(EXT/ds,prefix,suffix)
        a=ad.AnnData(x,obs=pd.DataFrame(index=[gsm+'_'+b for b in barcodes]),
                     var=pd.DataFrame({'symbol':features[1].astype(str).values},index=features[0].values))
        a.var['mt']=a.var.symbol.str.lower().str.startswith('mt-')
        sc.pp.calculate_qc_metrics(a,qc_vars=['mt'],percent_top=None,log1p=False,inplace=True)
        keep=(a.obs.n_genes_by_counts>=300)&(a.obs.n_genes_by_counts<=6000)&(a.obs.total_counts>=500)&(a.obs.pct_counts_mt<=15)
        before=len(a); b=a[keep].copy(); del a,x
        sc.pp.scrublet(b,expected_doublet_rate=.06,threshold=.25,n_prin_comps=30,random_state=SEED,verbose=False)
        nd=int(b.obs.predicted_doublet.sum()); b=b[~b.obs.predicted_doublet].copy()
        b.obs['sample']=gsm; b.obs['condition']=condition; b.obs['tissue']=tissue
        qcs.append({'sample':gsm,'dataset':ds,'tissue':tissue,'condition':condition,'input_cells':before,
                    'qc_pass':int(keep.sum()),'doublets_removed':nd,'retained_cells':len(b),
                    'median_genes':float(b.obs.n_genes_by_counts.median()),
                    'median_UMI':float(b.obs.total_counts.median()),'median_mt_pct':float(b.obs.pct_counts_mt.median())})
        blocks.append(b); print('QC',qcs[-1],flush=True)
    a=ad.concat(blocks,join='inner',merge='first'); del blocks,b; gc.collect()
    a.layers['counts']=a.X.copy()
    sc.pp.normalize_total(a,target_sum=10000); sc.pp.log1p(a)
    sc.pp.highly_variable_genes(a,n_top_genes=2000,flavor='seurat',batch_key='sample' if tissue!='Immune' else None)
    sc.pp.pca(a,n_comps=30,mask_var='highly_variable',svd_solver='arpack',random_state=SEED)
    sc.pp.neighbors(a,n_neighbors=15,n_pcs=30,random_state=SEED)
    sc.tl.umap(a,random_state=SEED,maxiter=250,min_dist=.3)
    sc.tl.leiden(a,resolution=.7,random_state=SEED,flavor='igraph',n_iterations=2,directed=False)
    genes=a.var.symbol.tolist(); idx={g:i for i,g in enumerate(genes)}
    marker_rows=[]; score_rows=[]
    available=list(dict.fromkeys(g for gs in MARKERS.values() for g in gs if g in idx))
    arr=a[:,[a.var_names[idx[g]] for g in available]].X.toarray()
    # Cluster z-scores are annotation aids; final labels are reviewed separately.
    z=(arr-arr.mean(0))/np.maximum(arr.std(0),.01)
    for cl in a.obs.leiden.cat.categories:
        mask=np.asarray(a.obs.leiden==cl)
        for j,g in enumerate(available):
            marker_rows.append({'cluster':cl,'gene':g,'mean_log1p':float(arr[mask,j].mean()),
                                'pct_expressing':float((arr[mask,j]>0).mean()*100)})
        rec={'cluster':cl,'n_cells':int(mask.sum())}
        for typ,gs in MARKERS.items():
            jj=[available.index(g) for g in gs if g in available]
            rec[typ]=float(z[mask][:,jj].mean()) if jj else -100
        scores=sorted([(k,rec[k]) for k in MARKERS],key=lambda kv:kv[1],reverse=True)
        rec['suggested_label']=scores[0][0];rec['score_margin']=scores[0][1]-scores[1][1]
        score_rows.append(rec)
    pd.DataFrame(marker_rows).to_csv(RES/(tissue+'_cluster_markers.csv'),index=False)
    pd.DataFrame(score_rows).to_csv(RES/(tissue+'_cluster_scores.csv'),index=False)
    pd.DataFrame(qcs).to_csv(RES/(tissue+'_QC.csv'),index=False)
    pd.crosstab(a.obs.leiden,a.obs['sample']).to_csv(RES/(tissue+'_cluster_sample_counts.csv'))
    a.write_h5ad(CACHE/(tissue+'_clustered.h5ad'),compression='gzip')
    print('SINGLE CELL STAGE COMPLETE',tissue,a.shape,flush=True)

if __name__=='__main__':
    import sys
    if sys.argv[1]=='bulk': bulk()
    else: sc_stage(sys.argv[1])
