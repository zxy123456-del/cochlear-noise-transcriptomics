"""Preserve superseded generated enrichment caches before outlier-aware reranking."""
from pathlib import Path
import shutil
from genes_enrichment import main
root=Path('work/genes/enrichment').resolve()
archive=Path('work/genes_gsea_prior').resolve()
workspace=Path.cwd().resolve()
assert root.is_relative_to(workspace) and archive.is_relative_to(workspace)
archive.mkdir(exist_ok=True)
for p in root.glob('*_strict_GSEA.csv'):
    target=archive/p.name
    if target.exists():raise FileExistsError(target)
    shutil.move(str(p),str(target))
main()
