
from pathlib import Path
import gzip, re, json, math, warnings, os
os.environ.setdefault('MPLCONFIGDIR', str(Path('work/mplconfig').resolve()))
import numpy as np
import pandas as pd
from scipy import stats, sparse, io
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans
umap = None
import networkx as nx

ROOT=Path('work/geo_reanalysis')
EXT=ROOT/'extracted'
RES=ROOT/'results'
FIG=Path('outputs/figures')
RES.mkdir(parents=True, exist_ok=True); FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','Arial Unicode MS','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False

SYNAPSE=set('Snap25 Syt1 Syt2 Syn1 Syn2 Syn3 Dlg4 Dlg2 Shank1 Shank2 Shank3 Homer1 Gria1 Gria2 Grin1 Grin2a Grin2b Slc17a7 Slc17a8 Ctbp2 Rims1 Rims2 Bassoon Bsn Pclo Otof Cacna1d Cacna1b Cacna1a Cacna2d1 Rab3a Nrxn1 Nrxn2 Nrxn3 Nlgn1 Nlgn2 Nlgn3 Syp Synj1 Dnm1 Eps15 Cplx1 Cplx2'.split())
OX=set('Nfe2l2 Keap1 Hmox1 Hmox2 Nqo1 Sod1 Sod2 Sod3 Cat Gpx1 Gpx2 Gpx3 Gpx4 Gsr Txn1 Txn2 Txnrd1 Txnrd2 Prdx1 Prdx2 Prdx3 Prdx4 Prdx5 Prdx6 Sesn1 Sesn2 Srxn1 Gclc Gclm Gsta1 Gsta2 Gstp1 Cybb Ncf1 Ncf2 Nox1 Nox2 Nox3 Nox4 Duox1 Duox2 Nos1 Nos2 Nos3 Aifm1 Ucp2 Ucp3 Park7 Foxo3 Mapk8 Mapk14 Rela Il1b Tnf'.split())

# ---------- GSE168973 bulk/RiboTag TPM ----------
def read_tpm(path):
    df=pd.read_csv(path, sep='\t', compression='gzip')
    val=df.columns[-1]
    df=df[['ensemble_ID','gene.symbol',val]].rename(columns={'gene.symbol':'gene','ensemble_ID':'ensembl',val:path.stem.replace('.TPM.txt','')})
    df['gene']=df['gene'].fillna(df['ensembl'])
    return df

def meta_from_name(col):
    # GSM5173296_NN24h_1_IP.TPM.txt -> group=N/X by first character of code, time, rep, fraction
    m=re.search(r'_(?P<code>[NX]N?)(?P<time>6h|24h|10w)_(?P<rep>\d+)_(?P<fraction>IP|input)', col)
    if not m:
        return {'sample':col}
    d=m.groupdict(); d['sample']=col; d['condition']='noise_like_X' if d['code'].startswith('X') else 'control_like_N'
    return d

def analyze_gse168973():
    files=sorted((EXT/'GSE168973').glob('*.TPM.txt.gz'))
    dfs=[read_tpm(p) for p in files]
    base=dfs[0][['ensembl','gene']].copy()
    for df in dfs:
        base=base.merge(df, on=['ensembl','gene'], how='outer')
    sample_cols=[c for c in base.columns if c not in ['ensembl','gene']]
    expr=base.set_index('gene')[sample_cols].fillna(0)
    # collapse duplicated symbols by max mean TPM
    expr=expr.groupby(expr.index).mean()
    meta=pd.DataFrame([meta_from_name(c) for c in sample_cols])
    meta.to_csv(RES/'GSE168973_sample_metadata.csv', index=False, encoding='utf-8-sig')
    expr.to_csv(RES/'GSE168973_TPM_matrix_by_gene.csv', encoding='utf-8-sig')
    log=np.log2(expr+1)
    degs=[]
    for fraction in sorted(meta['fraction'].dropna().unique()):
        for time in sorted(meta['time'].dropna().unique(), key=lambda x:{'6h':0,'24h':1,'10w':2}[x]):
            sub=meta[(meta['fraction']==fraction)&(meta['time']==time)]
            xs=sub[sub['condition']=='noise_like_X']['sample'].tolist(); ns=sub[sub['condition']=='control_like_N']['sample'].tolist()
            if len(xs)<2 or len(ns)<2: continue
            x=log[xs]; n=log[ns]
            logfc=x.mean(axis=1)-n.mean(axis=1)
            p=[]
            for g in log.index:
                try: pv=stats.ttest_ind(x.loc[g].values,n.loc[g].values,equal_var=False,nan_policy='omit').pvalue
                except Exception: pv=np.nan
                if not np.isfinite(pv): pv=1.0
                p.append(pv)
            padj=multipletests(p, method='fdr_bh')[1]
            out=pd.DataFrame({'gene':log.index,'comparison':f'X_vs_N_{time}_{fraction}','time':time,'fraction':fraction,
                              'log2FC':logfc.values,'pvalue':p,'padj':padj,
                              'mean_X_log2TPM':x.mean(axis=1).values,'mean_N_log2TPM':n.mean(axis=1).values})
            out['sig']=((out['padj']<0.05)&(out['log2FC'].abs()>=0.585))
            degs.append(out)
    deg=pd.concat(degs, ignore_index=True)
    deg.to_csv(RES/'GSE168973_DEG_all_comparisons.csv', index=False, encoding='utf-8-sig')
    summary=deg.groupby('comparison').agg(n_genes=('gene','size'),sig_genes=('sig','sum'),up=('log2FC',lambda s:int(((deg.loc[s.index,'sig'])&(s>0)).sum())),down=('log2FC',lambda s:int(((deg.loc[s.index,'sig'])&(s<0)).sum()))).reset_index()
    summary.to_csv(RES/'GSE168973_DEG_summary.csv', index=False, encoding='utf-8-sig')
    # pathway gene candidates
    deg['gene_set']=deg['gene'].apply(lambda g: 'synapse' if g in SYNAPSE else ('oxidative_stress' if g in OX else ('synapse+oxidative' if g in (SYNAPSE&OX) else 'other')))
    candidates=deg[(deg['gene'].isin(SYNAPSE|OX))].sort_values(['padj','pvalue']).copy()
    candidates.to_csv(RES/'GSE168973_synapse_oxidative_candidates.csv', index=False, encoding='utf-8-sig')
    # top table
    top=deg.sort_values(['padj','pvalue']).groupby('comparison').head(20)
    top.to_csv(RES/'GSE168973_top20_each_comparison.csv', index=False, encoding='utf-8-sig')
    make_bulk_figs(expr, log, meta, deg, candidates)
    return summary, top, candidates, meta

def make_bulk_figs(expr, log, meta, deg, candidates):
    colors={'control_like_N':'#4677C7','noise_like_X':'#D64B40'}
    X=StandardScaler().fit_transform(log.T)
    pca=PCA(n_components=2, random_state=1).fit_transform(X)
    fig,ax=plt.subplots(figsize=(7,5), dpi=160)
    for cond,grp in meta.groupby('condition'):
        idx=[meta.index[meta['sample']==s][0] for s in grp['sample']]
        ax.scatter(pca[idx,0],pca[idx,1],label=cond,s=52,c=colors.get(cond))
    for i,row in meta.iterrows():
        ax.text(pca[i,0], pca[i,1], f"{row.get('time','')}-{row.get('fraction','')}", fontsize=6)
    ax.set_xlabel('PC1'); ax.set_ylabel('PC2'); ax.set_title('GSE168973 样本 PCA')
    ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(FIG/'Fig2A_GSE168973_PCA.png'); plt.close(fig)
    # volcano per main comparisons
    for comp in deg['comparison'].unique():
        d=deg[deg['comparison']==comp].copy()
        fig,ax=plt.subplots(figsize=(5.2,4.2), dpi=160)
        ax.scatter(d['log2FC'], -np.log10(d['padj'].clip(lower=1e-300)), s=4, c='#B8B8B8', alpha=.7)
        sig=d[d['sig']]
        ax.scatter(sig['log2FC'], -np.log10(sig['padj'].clip(lower=1e-300)), s=6, c=np.where(sig['log2FC']>0,'#D64B40','#4677C7'), alpha=.85)
        lab=sig.sort_values('padj').head(8)
        for _,r in lab.iterrows(): ax.text(r['log2FC'], -math.log10(max(r['padj'],1e-300)), r['gene'], fontsize=6)
        ax.axvline(.585,ls='--',lw=.8,c='k'); ax.axvline(-.585,ls='--',lw=.8,c='k'); ax.axhline(-math.log10(.05),ls='--',lw=.8,c='k')
        ax.set_title(comp); ax.set_xlabel('log2FC (X/N)'); ax.set_ylabel('-log10(FDR)')
        fig.tight_layout(); fig.savefig(FIG/f'Fig3_volcano_{comp}.png'); plt.close(fig)
    # heatmap candidate top variable
    genes=list(dict.fromkeys(candidates.sort_values('padj')['gene'].head(40).tolist()))
    if genes:
        z=log.loc[genes]
        z=(z.sub(z.mean(axis=1), axis=0)).div(z.std(axis=1).replace(0,1),axis=0)
        cg=sns.clustermap(z, cmap='vlag', figsize=(8,8), col_cluster=True, row_cluster=True, xticklabels=False, yticklabels=True)
        cg.fig.suptitle('突触/氧化应激候选基因表达热图', y=1.02)
        cg.savefig(FIG/'Fig4_candidate_gene_heatmap.png', dpi=180); plt.close(cg.fig)
    # dotplot selected markers
    markers=[g for g in ['Slc17a8','Otof','Ctbp2','Bsn','Snap25','Syt1','Nfe2l2','Hmox1','Nqo1','Sod1','Gpx1','Prdx1'] if g in log.index]
    if markers:
        avg=[]
        for _,mrow in meta.iterrows():
            for g in markers:
                avg.append({'sample':mrow['sample'],'label':f"{mrow['condition'].replace('_like','')} {mrow['time']} {mrow['fraction']}", 'gene':g, 'expr':log.loc[g,mrow['sample']]})
        dd=pd.DataFrame(avg)
        fig,ax=plt.subplots(figsize=(10,4.6), dpi=160)
        piv=dd.pivot_table(index='gene', columns='label', values='expr', aggfunc='mean')
        sns.heatmap(piv, cmap='mako', ax=ax, cbar_kws={'label':'log2(TPM+1)'})
        ax.set_title('突触与氧化应激标志基因表达')
        fig.tight_layout(); fig.savefig(FIG/'Fig2B_marker_heatmap_GSE168973.png'); plt.close(fig)
    # co-expression network candidate genes
    genes=list(dict.fromkeys(candidates[candidates['pvalue']<0.05]['gene'].tolist()))[:60]
    genes=[g for g in genes if g in log.index]
    if len(genes)>=5:
        corr=log.loc[genes].T.corr(method='spearman')
        G=nx.Graph()
        for g in genes: G.add_node(g, kind='synapse' if g in SYNAPSE else ('oxidative' if g in OX else 'other'))
        for i,g in enumerate(genes):
            for h in genes[i+1:]:
                r=corr.loc[g,h]
                if abs(r)>=0.65: G.add_edge(g,h,weight=abs(r))
        nx.write_graphml(G, RES/'candidate_coexpression_network.graphml')
        fig,ax=plt.subplots(figsize=(7,6), dpi=180)
        pos=nx.spring_layout(G, seed=4, k=.55)
        node_colors=[{'synapse':'#4C78A8','oxidative':'#F58518','other':'#777777'}[G.nodes[n]['kind']] for n in G.nodes]
        nx.draw_networkx_edges(G,pos,ax=ax,alpha=.25,width=.8)
        nx.draw_networkx_nodes(G,pos,ax=ax,node_size=120,node_color=node_colors,edgecolors='white',linewidths=.5)
        nx.draw_networkx_labels(G,pos,ax=ax,font_size=6)
        ax.set_axis_off(); ax.set_title('候选基因共表达网络 | Spearman |r|>=0.65')
        fig.tight_layout(); fig.savefig(FIG/'Fig6_candidate_network.png'); plt.close(fig)

# ---------- GSE167078 immune UMAP ----------
def read_10x(folder, prefix):
    X=io.mmread(folder/f'{prefix}_matrix.mtx.gz').tocsr().T
    features=pd.read_csv(folder/f'{prefix}_features.tsv.gz', sep='\t', header=None, compression='gzip')
    barcodes=pd.read_csv(folder/f'{prefix}_barcodes.tsv.gz', sep='\t', header=None, compression='gzip')[0].astype(str).tolist()
    genes=features[1].astype(str).tolist()
    return X, genes, barcodes

def analyze_gse167078():
    folder=EXT/'GSE167078'
    X,genes,barcodes=read_10x(folder,'GSM5092462_RNA')
    counts=np.asarray(X.sum(axis=1)).ravel(); n_genes=np.asarray((X>0).sum(axis=1)).ravel()
    qc=pd.DataFrame({'barcode':barcodes,'total_counts':counts,'n_genes':n_genes})
    keep=(counts>=500)&(n_genes>=200)
    X=X[keep]; qc=qc[keep].reset_index(drop=True)
    # normalize/log; select HVGs by variance over a coarse subset
    scale=np.asarray(X.sum(axis=1)).ravel(); scale[scale==0]=1
    Xn=X.multiply(1e4/scale[:,None]).tocsr(); Xlog=Xn.copy(); Xlog.data=np.log1p(Xlog.data)
    mean=np.asarray(Xlog.mean(axis=0)).ravel(); mean2=np.asarray(Xlog.power(2).mean(axis=0)).ravel(); var=mean2-mean**2
    hv=np.argsort(var)[-2000:]
    Xhv=Xlog[:,hv]
    svd=TruncatedSVD(n_components=25, random_state=2).fit_transform(Xhv)
    emb=PCA(n_components=2, random_state=2).fit_transform(svd)
    cl=KMeans(n_clusters=6, random_state=2, n_init=20).fit_predict(svd)
    cells=pd.DataFrame({'barcode':qc['barcode'],'UMAP1':emb[:,0],'UMAP2':emb[:,1],'cluster':cl,'total_counts':qc['total_counts'],'n_genes':qc['n_genes']})
    cells.to_csv(RES/'GSE167078_immune_cells_umap_clusters.csv', index=False, encoding='utf-8-sig')
    # marker expression
    gene_index={g:i for i,g in enumerate(genes)}
    markers=['Ptprc','Lyz2','Csf1r','C1qa','Cd3d','Cd3e','Nkg7','Ms4a1','Ly6g','Mki67','Il1b','Tnf','Nfe2l2','Hmox1']
    marker_data=[]
    for g in markers:
        if g in gene_index:
            vals=np.asarray(Xlog[:,gene_index[g]].todense()).ravel()
            cells[g]=vals
            for c in sorted(set(cl)):
                idx=cl==c
                marker_data.append({'cluster':c,'gene':g,'mean_log_norm':float(vals[idx].mean()),'pct_expr':float((vals[idx]>0).mean()*100)})
    pd.DataFrame(marker_data).to_csv(RES/'GSE167078_marker_dotplot_values.csv', index=False, encoding='utf-8-sig')
    # figures
    fig,ax=plt.subplots(figsize=(5.2,4.6), dpi=170)
    sc=ax.scatter(cells['UMAP1'],cells['UMAP2'],c=cells['cluster'],cmap='tab10',s=4,alpha=.8)
    ax.set_title('GSE167078 CD45+ 细胞二维降维图'); ax.set_xlabel('Component 1'); ax.set_ylabel('Component 2')
    fig.tight_layout(); fig.savefig(FIG/'Fig2C_GSE167078_immune_UMAP.png'); plt.close(fig)
    for g in ['Ptprc','Lyz2','C1qa','Cd3d','Nkg7','Il1b','Hmox1']:
        if g in cells:
            fig,ax=plt.subplots(figsize=(5.2,4.6), dpi=170)
            vals=cells[g]
            im=ax.scatter(cells['UMAP1'],cells['UMAP2'],c=vals,cmap='viridis',s=4,alpha=.85)
            ax.set_title(f'FeaturePlot: {g}'); ax.set_xlabel('UMAP1'); ax.set_ylabel('UMAP2')
            fig.colorbar(im,ax=ax,fraction=.046,pad=.04)
            fig.tight_layout(); fig.savefig(FIG/f'Fig2D_FeaturePlot_{g}.png'); plt.close(fig)
    if marker_data:
        dd=pd.DataFrame(marker_data)
        fig,ax=plt.subplots(figsize=(7,3.8), dpi=170)
        # scatter dotplot
        dd['cluster']=dd['cluster'].astype(str)
        size=dd['pct_expr']*2+5
        sc=ax.scatter(dd['cluster'], dd['gene'], s=size, c=dd['mean_log_norm'], cmap='rocket_r')
        ax.set_xlabel('Cluster'); ax.set_ylabel('Marker'); ax.set_title('GSE167078 marker DotPlot')
        fig.colorbar(sc, ax=ax, label='mean log-normalized expression')
        fig.tight_layout(); fig.savefig(FIG/'Fig2E_GSE167078_marker_DotPlot.png'); plt.close(fig)
    return cells

# simple ORA using built-in gene sets
def local_enrichment():
    deg=pd.read_csv(RES/'GSE168973_DEG_all_comparisons.csv')
    gene_sets={
        'Synaptic vesicle cycle': {'Snap25','Syt1','Syt2','Syn1','Syn2','Rab3a','Cplx1','Cplx2','Dnm1','Synj1'},
        'Ribbon synapse / IHC machinery': {'Slc17a8','Otof','Ctbp2','Bsn','Pclo','Cacna1d','Rims1','Rims2'},
        'Glutamatergic synapse': {'Slc17a7','Slc17a8','Gria1','Gria2','Grin1','Grin2a','Grin2b','Dlg4'},
        'Nrf2 antioxidant response': {'Nfe2l2','Keap1','Nqo1','Hmox1','Gclc','Gclm','Gsr','Srxn1'},
        'Peroxidase / thioredoxin system': {'Gpx1','Gpx3','Gpx4','Txn1','Txn2','Txnrd1','Prdx1','Prdx2','Prdx3','Prdx6'},
        'Superoxide metabolism': {'Sod1','Sod2','Sod3','Cat','Cybb','Ncf1','Ncf2','Nox3','Nox4'},
        'Inflammatory oxidative stress': {'Il1b','Tnf','Rela','Mapk8','Mapk14','Nos2','Ptgs2'},
    }
    universe=set(deg['gene'].unique()); M=len(universe); rows=[]
    for comp,d in deg.groupby('comparison'):
        selected=set(d[(d['pvalue']<0.05)&(d['log2FC'].abs()>=0.4)]['gene'])
        N=len(selected)
        for term,gs in gene_sets.items():
            gs=gs&universe; K=len(gs); k=len(selected&gs)
            p=stats.hypergeom.sf(k-1,M,K,N) if K and N else 1.0
            rows.append({'comparison':comp,'term':term,'overlap':k,'term_size':K,'selected_genes':N,'pvalue':p,'genes':';'.join(sorted(selected&gs))})
    enr=pd.DataFrame(rows); enr['padj']=multipletests(enr['pvalue'],method='fdr_bh')[1]
    enr.to_csv(RES/'local_synapse_oxidative_enrichment.csv',index=False,encoding='utf-8-sig')
    fig,ax=plt.subplots(figsize=(8,4.6), dpi=170)
    plot=enr[enr['overlap']>0].copy()
    if not plot.empty:
        plot['mlog10']=-np.log10(plot['pvalue'].clip(lower=1e-300))
        sc=ax.scatter(plot['comparison'], plot['term'], s=plot['overlap']*55, c=plot['mlog10'], cmap='viridis')
        ax.tick_params(axis='x', labelrotation=55, labelsize=7); ax.tick_params(axis='y', labelsize=8)
        fig.colorbar(sc,ax=ax,label='-log10(P)')
    ax.set_title('突触/氧化应激本地基因集富集气泡图')
    fig.tight_layout(); fig.savefig(FIG/'Fig5_local_enrichment_bubble.png'); plt.close(fig)
    return enr

# workflow schematic and mechanism sketch
def schematic_figures():
    fig,ax=plt.subplots(figsize=(8,2.8), dpi=180)
    ax.axis('off')
    steps=['GEO数据\nGSE168041/167078/168973','质控与标准化','差异表达\nX vs N','GO/KEGG/Reactome/GSEA\n及本地基因集','候选网络\n突触-氧化应激','机制模型\n投稿稿件']
    xs=np.linspace(.08,.92,len(steps))
    for i,(x,txt) in enumerate(zip(xs,steps)):
        ax.text(x,.55,txt,ha='center',va='center',fontsize=8,bbox=dict(boxstyle='round,pad=.35',fc='#F7F7F7',ec='#444',lw=.8))
        if i<len(steps)-1: ax.annotate('',xy=(xs[i+1]-.075,.55),xytext=(x+.075,.55),arrowprops=dict(arrowstyle='->',lw=1.2,color='#444'))
    fig.tight_layout(); fig.savefig(FIG/'Fig1_workflow.png'); plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4.2), dpi=180); ax.axis('off')
    nodes={'噪声暴露':(.1,.55),'ROS/抗氧化失衡':(.35,.72),'炎症应答':(.35,.38),'IHC突触囊泡/带状突触异常':(.65,.62),'SGN/免疫微环境改变':(.65,.32),'可逆性听阈改变与隐匿性听损伤风险':(.88,.48)}
    for n,(x,y) in nodes.items(): ax.text(x,y,n,ha='center',va='center',fontsize=9,bbox=dict(boxstyle='round,pad=.35',fc='#FFF',ec='#333'))
    arrows=[('噪声暴露','ROS/抗氧化失衡'),('噪声暴露','炎症应答'),('ROS/抗氧化失衡','IHC突触囊泡/带状突触异常'),('炎症应答','SGN/免疫微环境改变'),('IHC突触囊泡/带状突触异常','可逆性听阈改变与隐匿性听损伤风险'),('SGN/免疫微环境改变','可逆性听阈改变与隐匿性听损伤风险')]
    for a,b in arrows:
        ax.annotate('',xy=nodes[b],xytext=nodes[a],arrowprops=dict(arrowstyle='->',lw=1.3,color='#555'))
    fig.tight_layout(); fig.savefig(FIG/'Fig7_mechanism_model.png'); plt.close(fig)

if __name__=='__main__':
    s,t,c,m=analyze_gse168973()
    cells=analyze_gse167078()
    enr=local_enrichment()
    schematic_figures()
    report={'GSE168973_samples':len(m),'GSE168973_deg_rows':int(len(pd.read_csv(RES/'GSE168973_DEG_all_comparisons.csv'))),'GSE167078_cells_after_qc':int(len(cells)),'figures':len(list(FIG.glob('*.png')))}
    (RES/'analysis_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
