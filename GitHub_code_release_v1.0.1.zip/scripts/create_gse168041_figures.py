from pathlib import Path
import numpy as np
import pandas as pd
import scanpy as sc
import sys
sys.path.insert(0, r"C:\Users\宰雄跃\.codex\skills\nature-figure\scripts")
from audit_panel_alignment import require_matplotlib_panel_alignment
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import sparse

RES = Path("work/geo_reanalysis/results")
FIG = Path("outputs/figures")
FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "Arial", "font.size": 8, "axes.spines.top": False,
                     "axes.spines.right": False, "pdf.fonttype": 42, "svg.fonttype": "none"})

ANNOT = {
    "Neurons": {
        **{str(i): "Spiral ganglion neuron" for i in [4, 5, 7, 13]},
        **{str(i): "Immune / myeloid" for i in [1, 6]},
        **{str(i): "Glial / Schwann" for i in [3, 10, 23]},
        "16": "Endothelial", "18": "Mural / smooth muscle", "17": "Erythroid",
        **{str(i): "Stromal / fibroblast" for i in [9, 11, 12, 15, 19, 20]},
        **{str(i): "Epithelial / sensory-supporting" for i in [2, 8, 14, 21, 22, 25]},
        "0": "Other epithelial-like", "24": "Other epithelial-like",
    },
    "Stria": {
        **{str(i): "Pigment / strial melanocyte-like" for i in [0, 1, 2]},
        **{str(i): "Endothelial" for i in [3, 16]},
        **{str(i): "Epithelial" for i in [4, 7, 13, 21]},
        **{str(i): "Stromal / fibrocyte" for i in [5, 14, 15, 18, 20]},
        **{str(i): "Ion-transport epithelial-like" for i in [6, 8, 10]},
        **{str(i): "Immune / myeloid" for i in [9, 17]},
        "11": "Mural / pericyte", "12": "Erythroid",
    },
}

MARKERS = {
    "Neurons": ["Nefh", "Snap25", "Syt2", "Mpz", "Plp1", "C1qa", "Lyz2", "Pecam1", "Cldn5", "Col1a1", "Dcn", "Gjb2", "Otof", "Gpx2", "Hmox1"],
    "Stria": ["Dct", "Tyr", "Kcnj10", "Slc12a2", "Kcnq1", "Epcam", "Gjb2", "Pecam1", "Cldn5", "C1qa", "Lyz2", "Col1a1", "Dcn", "Rgs5", "Gpx3"],
}


def make_figs(tissue):
    ad = sc.read_h5ad(RES / f"GSE168041_{tissue}_processed.h5ad")
    obs = ad.obs.copy()
    obs["cluster"] = obs["cluster"].astype(str)
    obs["cell_class"] = obs.cluster.map(ANNOT[tissue]).fillna("Unassigned")
    pd.crosstab(obs.cluster, obs.cell_class).to_csv(RES / f"GSE168041_{tissue}_cluster_annotations.csv", encoding="utf-8-sig")
    pd.crosstab(obs.cell_class, obs.condition).to_csv(RES / f"GSE168041_{tissue}_cell_class_by_condition.csv", encoding="utf-8-sig")

    xy = ad.obsm["X_umap"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.2), constrained_layout=True)
    cond_colors = {"naive": "#2575A7", "noise": "#C85A54"}
    for ax, key, title in [(axes[0], "condition", "Condition"), (axes[1], "cluster", "Cluster")]:
        cats = list(pd.unique(obs[key]))
        colors = cond_colors if key == "condition" else {c: plt.get_cmap("tab20")(i % 20) for i, c in enumerate(sorted(cats, key=lambda x: int(x)))}
        for c in cats:
            mask = obs[key].to_numpy() == c
            ax.scatter(xy[mask, 0], xy[mask, 1], s=1.4, alpha=.72, c=[colors[c]], linewidths=0, rasterized=True)
        ax.set(title=title, xlabel="UMAP1", ylabel="UMAP2")
        ax.set_xticks([]); ax.set_yticks([])
        ax.spines[:].set_visible(False)
        if key == "condition":
            labels = ["Unexposed control" if c == "naive" else "Noise exposed" for c in cats]
        else:
            labels = [f"Cluster {c}" for c in sorted(cats, key=lambda x: int(x))]
        handles = [Line2D([0], [0], marker="o", linestyle="", color=colors[c], markersize=4, label=lab) for c, lab in zip(cats, labels)]
        ax.legend(handles=handles, frameon=False, fontsize=6, loc="center left", bbox_to_anchor=(1.01, .5), ncol=1)
    fig.suptitle(f"GSE168041 {tissue}: UMAP of QC-filtered cells", fontsize=10)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=FIG / f"GSE168041_{tissue}_UMAP.alignment.json",
                                       overlay_svg=FIG / f"GSE168041_{tissue}_UMAP.alignment.svg", strict=True)
    fig.savefig(FIG / f"GSE168041_{tissue}_UMAP.pdf", bbox_inches="tight")
    fig.savefig(FIG / f"GSE168041_{tissue}_UMAP.png", dpi=600, bbox_inches="tight")
    fig.savefig(FIG / f"GSE168041_{tissue}_UMAP.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)

    raw = ad.raw.to_adata()
    symbol = raw.var["gene_symbol"].astype(str)
    sym_to_idx = {}
    for idx, sym in enumerate(symbol):
        if sym and sym not in sym_to_idx: sym_to_idx[sym] = idx
    genes = [g for g in MARKERS[tissue] if g in sym_to_idx]
    counts = raw.X
    totals = np.asarray(counts.sum(axis=1)).ravel()
    norm = sparse.diags(1e4 / np.maximum(totals, 1)) @ counts
    norm.data = np.log1p(norm.data)
    clusters = sorted(pd.unique(obs.cluster), key=lambda x: int(x))
    mean, pct = [], []
    for cl in clusters:
        mask = obs.cluster.to_numpy() == cl
        block = norm[mask]
        mean.append(np.asarray(block[:, [sym_to_idx[g] for g in genes]].mean(axis=0)).ravel())
        pct.append(np.asarray((counts[mask][:, [sym_to_idx[g] for g in genes]] > 0).mean(axis=0)).ravel() * 100)
    mean, pct = np.asarray(mean), np.asarray(pct)
    z = (mean - mean.mean(axis=0)) / np.maximum(mean.std(axis=0), 1e-8)
    fig, ax = plt.subplots(figsize=(max(7.5, len(genes)*.38), max(3.8, len(clusters)*.19)), constrained_layout=True)
    for yi, cl in enumerate(clusters):
        for xi, gene in enumerate(genes):
            ax.scatter(xi, yi, s=8 + pct[yi, xi]*.35, c=[plt.cm.RdBu_r(np.clip((z[yi, xi]+2.5)/5, 0, 1))], edgecolors="none")
    ax.set_xticks(range(len(genes)), genes, rotation=60, rotation_mode="anchor", ha="right")
    ax.set_yticks(range(len(clusters)), [f"{cl}: {ANNOT[tissue].get(cl, 'Unassigned')}" for cl in clusters])
    ax.invert_yaxis(); ax.set_xlim(-.6, len(genes)-.4); ax.set_ylim(len(clusters)-.5, -.5)
    ax.set_xlabel("Marker genes"); ax.set_ylabel("Marker-supported cluster label")
    ax.set_title(f"GSE168041 {tissue}: marker expression by cluster")
    fig.savefig(FIG / f"GSE168041_{tissue}_marker_dotplot.pdf", bbox_inches="tight")
    fig.savefig(FIG / f"GSE168041_{tissue}_marker_dotplot.png", dpi=600, bbox_inches="tight")
    fig.savefig(FIG / f"GSE168041_{tissue}_marker_dotplot.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    for t in ["Neurons", "Stria"]: make_figs(t)
