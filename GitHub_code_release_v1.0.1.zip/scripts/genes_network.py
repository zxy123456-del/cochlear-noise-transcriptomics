"""Retrieve documented STRING functional associations for the fixed intersection."""
from pathlib import Path
import json, hashlib
import pandas as pd
import requests

ROOT=Path('work/genes')
OUT=ROOT/'network'
OUT.mkdir(exist_ok=True)
def gmt(name):
    return {p[0]:set(p[2:]) for p in (line.strip().split('\t') for line in Path('work/revision/sources',name).read_text().splitlines())}
inter=gmt('GO_CC_mouse_2025.1.gmt')['GOCC_SYNAPSE'] & gmt('GO_BP_mouse_2025.1.gmt')['GOBP_RESPONSE_TO_OXIDATIVE_STRESS']
de=pd.read_csv(ROOT/'celltypes/Neurons_SGN_strict_DE.csv')
nodes=de[de.gene.isin(inter)&de.padj.lt(.05)].copy()
nodes.to_csv(OUT/'nodes.csv',index=False)
url='https://version-12-0.string-db.org/api/tsv/network'
params={'identifiers':'\r'.join(nodes.gene),'species':10090,'required_score':700,'network_type':'functional','add_nodes':0,'caller_identity':'cochlear_public_data_reanalysis'}
r=requests.post(url,data=params,timeout=90)
r.raise_for_status()
(OUT/'STRING12_functional.tsv').write_text(r.text,encoding='utf8')
(OUT/'provenance.json').write_text(json.dumps({'url':url,'version':'12.0','date':'2026-09-28','parameters':params,'sha256':hashlib.sha256(r.content).hexdigest(),'interpretation':'database functional association; not experimental protein interaction in this study; isolated queried nodes retained'},indent=2))
print('nodes',len(nodes),'response bytes',len(r.content))
