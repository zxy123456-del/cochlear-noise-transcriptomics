from pathlib import Path
import json, urllib.request, urllib.parse, time
from lxml import etree
OUT=Path('work/revision/sources/references');OUT.mkdir(parents=True,exist_ok=True)
DOIS={
 'Kujawa2009':'10.1523/JNEUROSCI.2845-09.2009',
 'Furman2013':'10.1152/jn.00164.2013',
 'Fernandez2015':'10.1523/JNEUROSCI.5138-14.2015',
 'Liberman2017':'10.1016/j.heares.2017.01.003',
 'Fetoni2019':'10.1016/j.freeradbiomed.2019.02.022',
 'Honkura2016':'10.1038/srep19329',
 'Milon2021':'10.1016/j.celrep.2021.109758',
 'Shrestha2018':'10.1016/j.cell.2018.07.007',
 'Sun2018':'10.1016/j.cell.2018.07.008',
 'Squair2021':'10.1038/s41467-021-25960-2',
 'GEO2002':'10.1093/nar/30.1.207',
 'Sanz2009':'10.1073/pnas.0907143106',
 'Scanpy2018':'10.1186/s13059-017-1382-0',
 'Scrublet2019':'10.1016/j.cels.2018.11.005',
 'Leiden2019':'10.1038/s41598-019-41695-z',
 'DESeq22014':'10.1186/s13059-014-0550-8',
 'PyDESeq22023':'10.1093/bioinformatics/btad547',
 'BH1995':'10.1111/j.2517-6161.1995.tb02031.x',
 'GO2000':'10.1038/75556',
 'KEGG2000':'10.1093/nar/28.1.27',
 'Reactome2022':'10.1093/nar/gkab1028',
 'GSEA2005':'10.1073/pnas.0506580102',
 'GSEApy2023':'10.1093/bioinformatics/btac757',
 'STRING2023':'10.1093/nar/gkac1000',
 'Jong2020':'10.1016/j.celrep.2020.108431',
 'vanDenBrink2017':'10.1038/nmeth.4437',
 'Ryan2016':'10.1097/MAO.0000000000001071',
 'Castanza2023':'10.1038/s41592-023-02014-7',
}
results={}
for key,doi in DOIS.items():
    try:
        p=OUT/(key+'.json')
        if not p.exists():
            url='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
            req=urllib.request.Request(url,headers={'User-Agent':'ResearchCitationVerification/1.0'})
            with urllib.request.urlopen(req,timeout=25) as r: p.write_bytes(r.read())
        obj=json.loads(p.read_text(encoding='utf-8'))['message']
        results[key]=obj
        print(key,obj['title'][0],flush=True)
    except Exception as e: print('FAILED',key,repr(e),flush=True)
    time.sleep(.15)
(OUT/'verified.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
