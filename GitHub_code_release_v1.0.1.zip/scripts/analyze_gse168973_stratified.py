from pathlib import Path
import re

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path("work/geo_reanalysis/results")
FIG = Path("outputs/figures")
FIG.mkdir(parents=True, exist_ok=True)

synapse = set("Snap25 Syt1 Syt2 Syn1 Syn2 Syn3 Dlg4 Dlg2 Shank1 Shank2 Shank3 Homer1 Gria1 Gria2 Grin1 Grin2a Grin2b Slc17a7 Slc17a8 Ctbp2 Rims1 Rims2 Bsn Pclo Otof Cacna1d Cacna1b Cacna1a Cacna2d1 Rab3a Nrxn1 Nrxn2 Nrxn3 Nlgn1 Nlgn2 Nlgn3 Syp Synj1 Dnm1 Eps15 Cplx1 Cplx2".split())
oxidative = set("Nfe2l2 Keap1 Hmox1 Hmox2 Nqo1 Sod1 Sod2 Sod3 Cat Gpx1 Gpx2 Gpx3 Gpx4 Gsr Txn1 Txn2 Txnrd1 Txnrd2 Prdx1 Prdx2 Prdx3 Prdx4 Prdx5 Prdx6 Sesn1 Sesn2 Srxn1 Gclc Gclm Gsta1 Gsta2 Gstp1 Cybb Ncf1 Ncf2 Nox1 Nox2 Nox3 Nox4 Duox1 Duox2 Nos1 Nos2 Nos3 Aifm1 Ucp2 Ucp3 Park7 Foxo3 Mapk8 Mapk14 Rela Il1b Tnf".split())


def metadata(sample):
    match = re.search(r"_(?P<code>[NX]{1,2})(?P<stage>6h|24h|10w)_(?P<rep>\d+)_(?P<fraction>IP|input)$", sample)
    if not match:
        raise ValueError(f"Cannot parse sample name: {sample}")
    d = match.groupdict()
    d["rep"] = int(d["rep"])
    d["cell_type"] = "OHC_enriched" if d["code"].startswith("N") else "Supporting_enriched"
    d["condition"] = "Noise" if len(d["code"]) == 2 else "Control"
    d["time"] = d["stage"] if d["condition"] == "Noise" else "baseline"
    return d


def main():
    expr = pd.read_csv(ROOT / "GSE168973_TPM_matrix_by_gene.csv", index_col=0)
    meta = pd.DataFrame([metadata(s) for s in expr.columns], index=expr.columns)
    meta.index.name = "sample"
    meta.reset_index().to_csv(ROOT / "GSE168973_sample_metadata_corrected.csv", index=False, encoding="utf-8-sig")
    log = np.log2(expr.astype(float) + 1)
    records = []
    for cell_type in ["OHC_enriched", "Supporting_enriched"]:
        for time in ["6h", "24h"]:
            for fraction in ["IP", "input"]:
                sub = meta[(meta.cell_type == cell_type) & (meta.fraction == fraction)]
                exposed = sub[(sub.condition == "Noise") & (sub.time == time)].index.tolist()
                control = sub[sub.condition == "Control"].index.tolist()
                if len(exposed) < 2 or len(control) < 2:
                    continue
                x, c = log[exposed], log[control]
                lfc = x.mean(axis=1) - c.mean(axis=1)
                p = stats.ttest_ind(x.to_numpy(), c.to_numpy(), axis=1, equal_var=False, nan_policy="omit").pvalue
                p = np.nan_to_num(p, nan=1.0, posinf=1.0, neginf=1.0)
                fdr = multipletests(p, method="fdr_bh")[1]
                out = pd.DataFrame({
                    "gene": expr.index, "cell_type": cell_type, "time": time, "fraction": fraction,
                    "n_noise": len(exposed), "n_control": len(control), "log2FC": lfc.values,
                    "pvalue": p, "padj": fdr, "mean_noise_log2TPM": x.mean(axis=1).values,
                    "mean_control_log2TPM": c.mean(axis=1).values,
                })
                out["gene_set"] = ["synapse+oxidative" if g in synapse and g in oxidative else "synapse" if g in synapse else "oxidative_stress" if g in oxidative else "other" for g in out.gene]
                records.append(out)
    deg = pd.concat(records, ignore_index=True)
    deg["significant"] = (deg.padj < 0.05) & (deg.log2FC.abs() >= np.log2(1.5))
    deg.to_csv(ROOT / "GSE168973_DEG_stratified.csv", index=False, encoding="utf-8-sig")
    summary = deg.groupby(["cell_type", "time", "fraction"], as_index=False).agg(
        n_genes=("gene", "size"), n_noise=("n_noise", "first"), n_control=("n_control", "first"),
        sig_genes=("significant", "sum"))
    summary["up"] = [int(((g.padj < .05) & (g.log2FC >= np.log2(1.5))).sum()) for _, g in deg.groupby(["cell_type", "time", "fraction"], sort=False)]
    summary["down"] = [int(((g.padj < .05) & (g.log2FC <= -np.log2(1.5))).sum()) for _, g in deg.groupby(["cell_type", "time", "fraction"], sort=False)]
    summary.to_csv(ROOT / "GSE168973_DEG_summary_stratified.csv", index=False, encoding="utf-8-sig")
    candidates = deg[deg.gene.isin(synapse | oxidative)].copy().sort_values(["cell_type", "time", "fraction", "padj"])
    candidates.to_csv(ROOT / "GSE168973_synapse_oxidative_candidates_stratified.csv", index=False, encoding="utf-8-sig")
    deg[deg.significant].to_csv(ROOT / "GSE168973_DEG_significant_stratified.csv", index=False, encoding="utf-8-sig")

    for cell_type in ["OHC_enriched", "Supporting_enriched"]:
        for fraction in ["IP", "input"]:
            d = deg[(deg.cell_type == cell_type) & (deg.fraction == fraction)]
            if d.empty: continue
            fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), constrained_layout=True)
            for ax, time in zip(axes, ["6h", "24h"]):
                z = d[d.time == time]
                ax.scatter(z.log2FC, -np.log10(z.pvalue.clip(lower=1e-300)), s=5, alpha=.35, c="#637381", linewidths=0)
                sig = z[z.significant]
                ax.scatter(sig.log2FC, -np.log10(sig.pvalue.clip(lower=1e-300)), s=9, c="#c74b50", linewidths=0)
                ax.axvline(np.log2(1.5), color="#7b8794", lw=.7, ls="--")
                ax.axvline(-np.log2(1.5), color="#7b8794", lw=.7, ls="--")
                ax.axhline(-np.log10(.05), color="#7b8794", lw=.7, ls=":")
                ax.set(title=f"{time}: noise vs control", xlabel="log2 fold change", ylabel="-log10 nominal P")
            fig.suptitle(f"{cell_type.replace('_', ' ')} | {fraction}", fontsize=11)
            stem = f"GSE168973_{cell_type}_{fraction}_stratified_volcano"
            fig.savefig(FIG / f"{stem}.png", dpi=300)
            fig.savefig(FIG / f"{stem}.pdf")
            plt.close(fig)

    print(summary.to_string(index=False))
    print("Candidate significant rows:")
    print(deg[(deg.gene.isin(synapse | oxidative)) & deg.significant][["gene", "cell_type", "time", "fraction", "log2FC", "padj"]].to_string(index=False))


if __name__ == "__main__":
    main()
