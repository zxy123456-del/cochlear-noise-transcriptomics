"""Data-driven figures for the Genes manuscript. No simulated observations."""
from pathlib import Path
import os, sys, textwrap
os.environ.setdefault('MPLCONFIGDIR',str(Path('work/mplconfig').resolve()))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch
import scanpy as sc
import networkx as nx
from genes_celltypes import MAP
try:
    from audit_panel_alignment import require_matplotlib_panel_alignment
except ImportError:
    sys.path.insert(0,str(Path.home()/'.codex/skills/nature-figure/scripts'))
    from audit_panel_alignment import require_matplotlib_panel_alignment

ROOT=Path('work/genes'); FIG=ROOT/'figures'; QA=ROOT/'qa'
FIG.mkdir(exist_ok=True); QA.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':9,'axes.labelsize':8,
 'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
PALETTE={'SGN':'#1675a9','Glia':'#e69f00','Myeloid':'#cc6677','Endothelial':'#009e73','Stromal':'#882255','Epithelial':'#56b4e9','Mural':'#8c6d31','Intermediate_like':'#aa4499','Marginal_like':'#44aa99','Basal_like':'#ddcc77','Erythroid':'#888888','Mixed_unassigned':'#bbbbbb','Melanocyte_like':'#332288'}
def disp(name):
    return name.replace('Neurons_','Neural / ').replace('Stria_','Lateral wall / ').replace('_strict','').replace('_',' ')
def save(fig,name,exclude=None):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,json_out=str(QA/f'{name}_alignment.json'),tolerance_pt=1.5,strict=True,exclude_axes=exclude or [])
    fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight')
    fig.savefig(FIG/f'{name}.png',dpi=600,bbox_inches='tight')
    fig.savefig(QA/f'{name}_preview.png',dpi=130,bbox_inches='tight')
    plt.close(fig)

def cell_panels():
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.9))
    fig.subplots_adjust(left=.03,right=.98,top=.9,bottom=.32,wspace=.12)
    marker_rows=[]
    markers={'Neurons':['Snap25','Nefh','Calb2','Lypd1','Mpz','Plp1','C1qa','Lyz2','Cldn5','Dcn','Epcam','Gjb2'],
             'Stria':['Dct','Kcnj10','Kcne1','Kcnq1','Slc12a2','Cldn11','Cldn5','Lyz2','Dcn','Epcam','Rgs5','Gpx3']}
    for ax,tissue,letter in zip(axes,['Neurons','Stria'],['a','b']):
        obs=pd.read_csv(ROOT/'celltypes'/f'{tissue}_annotated_cells.csv.gz',index_col=0)
        xy=np.load(ROOT/f'{tissue}_umap.npy')
        keep=obs.strict_keep.to_numpy()
        for ct in MAP[tissue]:
            m=keep & obs.cell_type.eq(ct).to_numpy()
            if m.any(): ax.scatter(xy[m,0],xy[m,1],s=.3,c=PALETTE.get(ct,'#aaaaaa'),rasterized=True,linewidths=0,label=ct.replace('_',' '))
        ax.set_title(('Neural-enriched' if tissue=='Neurons' else 'Lateral wall')+f'  n = {keep.sum():,} cells')
        ax.set_xticks([]);ax.set_yticks([]);ax.spines[:].set_visible(False)
        ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(0,12),textcoords='offset points',weight='bold',fontsize=10)
        ax.legend(loc='upper center',bbox_to_anchor=(.5,-.05),ncol=2,markerscale=8,fontsize=6.5,columnspacing=.8,handletextpad=.3)
        cache=ROOT/f'{tissue}_dotplot_source.csv'
        if cache.exists():
            marker_rows.append(pd.read_csv(cache));continue
        ad=sc.read_h5ad(f'work/geo_reanalysis/results/GSE168041_{tissue}_processed.h5ad')
        idx=[np.flatnonzero(ad.raw.var.gene_symbol.to_numpy()==g)[0] for g in markers[tissue]]
        X=ad.raw.X[:,idx].toarray()
        norm=np.log1p(X/np.asarray(ad.raw.X.sum(axis=1))*10000)
        rows=[]
        for ct in MAP[tissue]:
            m=keep & obs.cell_type.eq(ct).to_numpy()
            if m.sum()==0:continue
            for j,g in enumerate(markers[tissue]):
                rows.append({'tissue':tissue,'cell_type':ct,'gene':g,'fraction':float((X[m,j]>0).mean()),'mean_log1p':float(norm[m,j].mean())})
        f=pd.DataFrame(rows);f.to_csv(cache,index=False);marker_rows.append(f)
    save(fig,'Figure2_cell_atlas')
    fig,axes=plt.subplots(2,1,figsize=(7.2,6.8))
    fig.subplots_adjust(left=.25,right=.9,top=.96,bottom=.16,hspace=.5)
    for ax,df,letter in zip(axes,marker_rows,['a','b']):
        gs=list(df.gene.unique());cts=list(df.cell_type.unique())
        maxes=df.groupby('gene').mean_log1p.max()
        color=df.mean_log1p / df.gene.map(maxes)
        sca=ax.scatter(df.gene.map({v:i for i,v in enumerate(gs)}),df.cell_type.map({v:i for i,v in enumerate(cts)}),s=df.fraction*48,c=color,cmap='viridis',vmin=0,vmax=1,linewidths=0)
        ax.set_xticks(range(len(gs)),gs,rotation=45,ha='right',rotation_mode='anchor')
        ax.set_yticks(range(len(cts)),[c.replace('_',' ') for c in cts],fontsize=7)
        ax.invert_yaxis();ax.set_xlim(-.7,len(gs)-.3);ax.set_ylim(len(cts)-.3,-.7)
        ax.set_title('Neural-enriched' if df.tissue.iloc[0]=='Neurons' else 'Lateral wall')
        ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-20,10),textcoords='offset points',weight='bold',fontsize=10)
    cbax=fig.add_axes([.93,.23,.015,.5]);fig.colorbar(sca,cax=cbax,label='Mean expression / gene maximum')
    fig.text(.25,.025,'Dot area: expressing-cell fraction (0 to 100%). Descriptive, not replicate-level tests.',fontsize=7)
    save(fig,'FigureS1_annotation',exclude=[cbax])

def overview():
    d=pd.read_csv(ROOT/'enrichment/all_celltype_DE_globalFDR.csv.gz')
    genes=['Snap25','Syt2','Syn1','Gpx2','Gpx4','Hmox1','Gclc','Nfe2l2','Ptprn','Park7','Casp3','Cryab']
    order=[x for x in d.analysis.unique() if not any(s in x for s in ['SGN_Calb2','SGN_Lypd1','SGN_mixed'])]
    sub=d[d.gene.isin(genes)&d.analysis.isin(order)].copy()
    fig,ax=plt.subplots(figsize=(7.2,5.2));fig.subplots_adjust(left=.35,right=.88,bottom=.15,top=.94)
    x=sub.gene.map({g:i for i,g in enumerate(genes)});y=sub.analysis.map({s:i for i,s in enumerate(order)})
    sig=sub.padj_global.lt(.05)
    s=ax.scatter(x,y,c=sub.log2FoldChange.clip(-1.5,1.5),s=np.where(sig,48,12),cmap='RdBu_r',vmin=-1.5,vmax=1.5,linewidths=.2,edgecolors='#333333')
    ax.set_xticks(range(len(genes)),genes,rotation=45,ha='right',rotation_mode='anchor')
    ax.set_yticks(range(len(order)),[disp(t) for t in order],fontsize=7)
    ax.set_ylim(len(order)-.5,-.5);ax.set_xlim(-.5,len(genes)-.5)
    ax.set_title('Selected synaptic and redox transcripts by cell type')
    cbax=fig.add_axes([.91,.3,.018,.45]);fig.colorbar(s,cax=cbax,label='Noise vs control log2 fold change')
    fig.text(.35,.015,'Large dots: global BH FDR < 0.05. Small dots: not significant. Blank: not tested.',fontsize=6.5)
    save(fig,'Figure3_celltype_effects',exclude=[cbax])

def enrichment():
    d=pd.read_csv(ROOT/'enrichment/all_focus_GSEA.csv')
    order=list(d.analysis.unique());terms=list(d.Term.unique())
    fig,ax=plt.subplots(figsize=(7.2,6));fig.subplots_adjust(left=.37,right=.85,top=.95,bottom=.2)
    sizes=np.clip(-np.log10(d.BH_across_focus_tests.clip(lower=1e-4)),.1,4)*28
    s=ax.scatter(d.Term.map({g:i for i,g in enumerate(terms)}),d.analysis.map({g:i for i,g in enumerate(order)}),c=d.NES,s=sizes,cmap='RdBu_r',vmin=-3,vmax=3)
    ax.set_xticks(range(len(terms)),['Synapse\norganization' if 'ORGANIZATION' in t else 'Synaptic\nvesicle cycle' if 'VESICLE' in t else 'Oxidative stress\nresponse' for t in terms],fontsize=7)
    ax.set_yticks(range(len(order)),[disp(x) for x in order],fontsize=7)
    ax.set_xlim(-.5,2.5);ax.set_ylim(len(order)-.5,-.5)
    ax.set_title('Focused gene set enrichment')
    cbax=fig.add_axes([.9,.3,.018,.45]);fig.colorbar(s,cax=cbax,label='Normalized enrichment score')
    fig.text(.37,.08,'Dot area: -log10 BH-adjusted nominal P\nAll 51 focus tests form one correction family.\nGene-set permutations; not animal-label permutations.',fontsize=7,linespacing=1.4)
    save(fig,'Figure4_focus_enrichment',exclude=[cbax])

def validation():
    a=pd.read_csv(ROOT/'celltypes/Neurons_SGN_strict_DE.csv').set_index('gene')
    b=pd.read_csv(ROOT/'external/DE_8h.csv').set_index('gene')
    common=a.index.intersection(b.index);m=a.loc[common].join(b.loc[common],rsuffix='_external')
    genes=['Snap25','Syt2','Syn1','Gpx2','Gpx4','Hmox1']
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.2));fig.subplots_adjust(left=.1,right=.99,bottom=.22,top=.88,wspace=.5)
    ax=axes[0];ax.scatter(m.log2FoldChange,m.log2_difference,s=2,c='#aaaaaa',alpha=.35,rasterized=True,linewidths=0)
    ax.axhline(0,color='#777777',lw=.5);ax.axvline(0,color='#777777',lw=.5)
    ax.set(xlabel='SGN at 24 h: log2 fold change',ylabel='Independent bulk at 8 h:\nlog2 expression difference',title='All shared genes')
    ax=axes[1]
    for i,g in enumerate(genes):
        for row,shift,color in [(a.loc[g],-.13,'#1675a9'),(b.loc[g],.13,'#cc6677')]:
            effect=row.get('log2FoldChange',row.get('log2_difference'))
            ax.errorbar(effect,i+shift,xerr=[[effect-row.CI_low],[row.CI_high-effect]],fmt='o',ms=3,color=color,lw=.8,capsize=2)
    ax.axvline(0,color='#777777',lw=.5);ax.set_yticks(range(len(genes)),genes);ax.invert_yaxis()
    ax.set(xlabel='Effect and 95% confidence interval',title='Selected illustrative genes')
    ax.legend(handles=[Line2D([],[],marker='o',ls='',color='#1675a9',label='Discovery SGN'),Line2D([],[],marker='o',ls='',color='#cc6677',label='Independent bulk')],loc='lower center',bbox_to_anchor=(.5,-.43),ncol=2,fontsize=6.5)
    for ax,letter in zip(axes,['a','b']):ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-14,10),textcoords='offset points',weight='bold',fontsize=10)
    save(fig,'Figure5_independent_validation')

def volcano_heatmap():
    d=pd.read_csv(ROOT/'celltypes/Neurons_SGN_strict_DE.csv')
    fig,ax=plt.subplots(figsize=(6,4));sig=d.padj.lt(.05)
    ax.scatter(d.log2FoldChange,-np.log10(d.padj.clip(lower=1e-100)),c=np.where(sig,np.where(d.log2FoldChange>0,'#cc6677','#1675a9'),'#cccccc'),s=4,linewidths=0,rasterized=True)
    ax.set(xlabel='Noise vs control log2 fold change',ylabel='-log10 BH-adjusted P',title='Spiral ganglion neuron pseudobulk')
    fig.tight_layout();save(fig,'FigureS2_SGN_volcano')
    x=pd.read_csv(ROOT/'celltypes/Neurons_SGN_strict_normalized.csv.gz',index_col=0)
    genes=d[d.padj.lt(.05)].sort_values('padj').head(24).gene
    z=np.log2(x.loc[genes]+1);z=z.sub(z.mean(axis=1),axis=0).div(z.std(axis=1),axis=0)
    fig,ax=plt.subplots(figsize=(6,6));fig.subplots_adjust(left=.25,right=.85,bottom=.18,top=.94)
    im=ax.imshow(z,aspect='auto',cmap='RdBu_r',vmin=-2,vmax=2,interpolation='nearest')
    ax.set_yticks(range(len(genes)),genes,fontsize=7);ax.set_xticks(range(8),['C1','C2','C3','C4','N1','N2','N3','N4'])
    ax.set_title('Top 24 SGN differentially expressed genes');ax.set_xlabel('Independent animal samples')
    cax=fig.add_axes([.9,.3,.02,.45]);fig.colorbar(im,cax=cax,label='Row z score of log2 normalized counts')
    save(fig,'FigureS3_SGN_heatmap',exclude=[cax])

def network():
    nodes=pd.read_csv(ROOT/'network/nodes.csv').set_index('gene');edges=pd.read_csv(ROOT/'network/STRING12_functional.tsv',sep='\t')
    G=nx.Graph();G.add_nodes_from(nodes.index)
    for _,e in edges.iterrows():
        if e.preferredName_A in G and e.preferredName_B in G: G.add_edge(e.preferredName_A,e.preferredName_B,weight=e.score)
    pos=nx.circular_layout(G)
    fig,ax=plt.subplots(figsize=(6.3,6.3));ax.set_aspect('equal');ax.set_xlim(-1.5,1.5);ax.set_ylim(-1.5,1.5);ax.axis('off')
    nx.draw_networkx_edges(G,pos,ax=ax,edge_color='#bbbbbb',width=1)
    nx.draw_networkx_nodes(G,pos,ax=ax,node_size=120,node_color=nodes.loc[list(G),'log2FoldChange'].clip(-1.5,1.5),cmap=plt.cm.RdBu_r,vmin=-1.5,vmax=1.5,linewidths=.3,edgecolors='#333333')
    for g,(x,y) in pos.items():ax.text(x*1.22,y*1.22,g,ha='center',va='center',fontsize=8)
    ax.set_title(f'STRING functional associations\n{len(G)} queried proteins; {G.number_of_edges()} undirected edges',pad=12)
    fig.text(.5,.02,'Score >= 0.700. Blue: lower expression; red: higher expression.\nIsolated nodes retained. Associations do not establish causation.',ha='center',fontsize=7)
    save(fig,'FigureS4_functional_network')

def diagrams():
    fig,ax=plt.subplots(figsize=(7.2,4.1));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off')
    boxes=[(2.5,5,'Discovery\nGSE168041\n16 libraries, 4 mice per condition/tissue'),(7.5,5,'Independent assessment\nGSE312476\n12 libraries, 3 mice per group'),(2.5,3,'Cell QC and annotation\nSample-level pseudobulk\nCell types and SGN strata'),(7.5,3,'Deposited continuous expression\n0, 4 and 8 h contrasts\n8 h primary external comparison'),(5,1,'Synaptic and oxidative-stress gene sets\nMultiple-testing control and sensitivity analyses\nConcordance, nonreplication and evidence boundaries')]
    for x,y,t in boxes:
        width=7 if y==1 else 4.5
        ax.add_patch(FancyBboxPatch((x-width/2,y-.65),width,1.3,boxstyle='round,pad=0.05,rounding_size=0.05',facecolor='#f1f4f5',edgecolor='#71818a',lw=.8))
        ax.text(x,y,t,ha='center',va='center',fontsize=8,linespacing=1.4)
    for a,b in [((2.5,4.3),(2.5,3.7)),((7.5,4.3),(7.5,3.7)),((2.5,2.3),(4,1.7)),((7.5,2.3),(6,1.7))]:ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#71818a','lw':1})
    save(fig,'Figure1_workflow')
    fig,ax=plt.subplots(figsize=(7.2,3.6));ax.axis('off');ax.set_xlim(0,10);ax.set_ylim(0,5)
    ax.text(5,4.5,'Transcript-level evidence after noise exposure',ha='center',fontsize=12,weight='bold')
    ax.text(2.5,3,'SGN synaptic transcripts\nSnap25 and Syt2 lower\nSyn1 higher',ha='center',va='center',fontsize=10,linespacing=1.6,color='#1675a9')
    ax.text(7.5,3,'SGN redox-associated transcripts\nGpx2, Gpx4 and Hmox1 higher\nGene-set results require qualification',ha='center',va='center',fontsize=10,linespacing=1.6,color='#9e4263')
    ax.text(5,1.4,'Association, not a demonstrated causal pathway\nNo new synapse counts, ROS assays or rescue experiments',ha='center',va='center',fontsize=9,linespacing=1.6)
    ax.text(5,.35,'Independent 8 h bulk data did not confirm the selected genes at genome-wide FDR < 0.05',ha='center',fontsize=8)
    save(fig,'Figure6_evidence_summary')

if __name__=='__main__':
    diagrams();cell_panels();overview();enrichment();validation();volcano_heatmap();network()
