"""Audit cached single-cell counts without changing existing analysis files."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', str(Path('work/mplconfig').resolve()))
import json
import numpy as np
import pandas as pd
import scanpy as sc

OUT = Path('work/genes')
OUT.mkdir(exist_ok=True)
MARKERS = {
    'SGN': ['Tubb3','Snap25','Syt1','Nefl','Nefm','Prph','Calb2','Calb1','Lypd1','Pou4f1','Isl1'],
    'Glia': ['Sox10','Plp1','Mpz','Pmp22','S100b','Fabp7'],
    'Myeloid': ['Ptprc','Lyz2','Csf1r','C1qa','Tyrobp','Aif1'],
    'Endothelial': ['Pecam1','Cldn5','Kdr','Emcn'],
    'Mural': ['Rgs5','Pdgfrb','Acta2','Myh11'],
    'Stromal': ['Col1a1','Col1a2','Dcn','Pdgfra','Otos','Coch','Col2a1'],
    'Epithelial': ['Epcam','Krt8','Krt18','Krt19','Gjb2','Gjb6','Sox2','Tecta','Otog','Slc26a5','Myo7a'],
    'Marginal': ['Kcnq1','Kcne1','Slc12a2','Bsnd','Atp1b2'],
    'Intermediate': ['Kcnj10','Dct','Tyr','Tyrp1','Mlana','Mitf'],
    'Basal': ['Cldn11','Tjp1','Krt5','Krt14'],
    'Erythroid': ['Hba-a1','Hba-a2','Hbb-bs','Hbb-bt','Alas2'],
}

def prepare(tissue):
    print('READ', tissue, flush=True)
    ad = sc.read_h5ad(f'work/geo_reanalysis/results/GSE168041_{tissue}_processed.h5ad')
    raw = ad.raw.to_adata()
    symbols = raw.var.gene_symbol.astype(str).to_numpy()
    assert np.all(raw.X.data >= 0) and np.allclose(raw.X.data, np.round(raw.X.data))
    obs = ad.obs.copy()
    obs['cluster'] = obs.cluster.astype(str)
    obs['scrublet_score'] = np.nan
    obs['predicted_doublet'] = False
    for sample in obs['sample'].unique():
        print('SCRUBLET', sample, flush=True)
        m = obs['sample'].eq(sample).to_numpy()
        single = raw[m].copy()
        sc.pp.scrublet(single, expected_doublet_rate=0.06, random_state=2026, verbose=False)
        obs.loc[m, 'scrublet_score'] = single.obs.doublet_score.to_numpy()
        obs.loc[m, 'predicted_doublet'] = single.obs.predicted_doublet.to_numpy()
    hb = np.char.startswith(symbols.astype(str), 'Hba-') | np.char.startswith(symbols.astype(str), 'Hbb-')
    obs['hemoglobin_pct'] = np.asarray(raw.X[:,hb].sum(axis=1)).ravel() / np.asarray(raw.X.sum(axis=1)).ravel() * 100
    obs['primary_keep'] = ~obs.predicted_doublet
    obs['strict_keep'] = obs.primary_keep & obs.hemoglobin_pct.lt(1) & obs.pct_counts_mt.lt(10 if tissue=='Neurons' else 20)
    raw.obs = obs
    sc.pp.normalize_total(raw, target_sum=10000)
    sc.pp.log1p(raw)
    rows, top = [], []
    allmean = np.asarray(raw.X.mean(axis=0)).ravel()
    for cluster in sorted(obs.cluster.unique(), key=int):
        m = obs.cluster.eq(cluster).to_numpy() & obs.primary_keep.to_numpy()
        mean = np.asarray(raw.X[m].mean(axis=0)).ravel()
        fraction = np.asarray((raw.X[m] > 0).mean(axis=0)).ravel()
        delta = mean - allmean
        for j in np.argsort(delta)[-40:][::-1]:
            top.append({'cluster':cluster,'gene':symbols[j],'mean_log1p':mean[j], 'mean_difference':delta[j], 'fraction':fraction[j]})
        for group, genes in MARKERS.items():
            for gene in genes:
                idx = np.flatnonzero(symbols==gene)
                if len(idx):
                    rows.append({'cluster':cluster,'marker_group':group,'gene':gene,'mean_log1p':mean[idx].sum(),'fraction':fraction[idx].max(),'cells':m.sum()})
    pd.DataFrame(rows).to_csv(OUT/f'{tissue}_marker_audit.csv',index=False)
    pd.DataFrame(top).to_csv(OUT/f'{tissue}_top_markers.csv',index=False)
    obs.to_csv(OUT/f'{tissue}_cells.csv.gz')
    pd.crosstab(obs.cluster,obs['sample']).to_csv(OUT/f'{tissue}_cluster_samples.csv')
    obs.groupby('sample',observed=True).agg(condition=('condition','first'),cells=('sample','size'),doublets=('predicted_doublet','sum'),primary=('primary_keep','sum'),strict=('strict_keep','sum')).to_csv(OUT/f'{tissue}_QC.csv')
    np.save(OUT/f'{tissue}_umap.npy', ad.obsm['X_umap'])
    print('DONE', tissue, flush=True)

if __name__=='__main__':
    for tissue in ['Neurons','Stria']:
        prepare(tissue)
